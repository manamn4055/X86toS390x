"""x86-64 -> s390x 翻译器的 ELF 处理。

两个职责：

1. **读 x86-64 ``.o``**（gcc -c 产出）：提取 ``.text`` 字节、符号表
   （函数名 + 地址 + 大小）、重定位（用于把 RIP 相对引用解析成符号名）。

2. **生成 s390x 静态可执行文件**：把翻译后的汇编用
   ``s390x-linux-gnu-as`` 汇编，再用一个调用 ``main`` 并 ``svc`` 退出的
   小 ``_start`` 桩链接。

翻译器发出的占位符（``CALL 0x<addr>``、``RIP_ld64 ...``）由本模块改写成
引用正确符号的真实 s390x 指令。
"""

import os
import struct
import subprocess
import tempfile


def _byte_swap_le_to_be(raw, total_size):
    """小端数据转大端。

    标量（1/2/4/8 字节）整体反转。
    大小是 4 的倍数且 > 8 的，按 4 字节 int 元素逐个交换。
    其它（如长度 15 的字符串、字节数组）保持不变——字节数组无字节序。
    """
    if total_size in (1, 2, 4, 8):
        # 标量：整体反转
        return bytes(reversed(raw))
    if total_size > 8 and total_size % 4 == 0:
        # 看起来是 int[]：按 4 字节块交换
        out = bytearray()
        for i in range(0, len(raw), 4):
            chunk = raw[i:i + 4]
            out.extend(reversed(chunk))
        return bytes(out)
    # 字节数组 / 字符串 / 填充结构体：原样
    return bytes(raw)


# ---------------------------------------------------------------------------
# x86-64 .o 解析
# ---------------------------------------------------------------------------

class X86Symbol:
    __slots__ = ("name", "value", "size", "section", "is_func", "is_global")

    def __init__(self, name, value, size, section, is_func, is_global):
        self.name = name
        self.value = value
        self.size = size
        self.section = section
        self.is_func = is_func
        self.is_global = is_global

    def __repr__(self):
        return "<%s value=0x%x size=%d func=%s>" % (
            self.name, self.value, self.size, self.is_func)


class X86Reloc:
    __slots__ = ("offset", "type", "symbol", "addend", "section_idx")

    def __init__(self, offset, rtype, symbol, addend, section_idx=-1):
        self.offset = offset      # 节内偏移
        self.type = rtype         # R_X86_64_* 类型号
        self.symbol = symbol      # 符号名（字符串）
        self.addend = addend
        self.section_idx = section_idx  # 引用符号所在节索引

    def __repr__(self):
        return "<Reloc off=0x%x type=%d sym=%s addend=%d sec=%d>" % (
            self.offset, self.type, self.symbol, self.addend, self.section_idx)


class X86ObjectFile:
    """x86-64 ELF64 可重定位对象的最小解析器。"""

    def __init__(self, path):
        self.path = path
        with open(path, "rb") as f:
            self.data = f.read()
        self.symbols = []        # X86Symbol 列表
        self.text_bytes = b""
        self.text_addr = 0       # .o 里通常为 0
        self.relocs = []         # .text 内的 X86Reloc 列表
        self.data_relocs = {}   # 节名 -> [X86Reloc]，数据段的重定位
        self._parse()

    def _parse(self):
        d = self.data
        if d[:4] != b"\x7fELF":
            raise ValueError("not an ELF file: %s" % self.path)
        if d[4] != 2:
            raise ValueError("only ELF64 supported")
        # 节头表
        e_shoff = struct.unpack_from("<Q", d, 0x28)[0]
        e_shentsize = struct.unpack_from("<H", d, 0x3a)[0]
        e_shnum = struct.unpack_from("<H", d, 0x3c)[0]
        e_shstrndx = struct.unpack_from("<H", d, 0x3e)[0]
        sections = []
        for i in range(e_shnum):
            off = e_shoff + i * e_shentsize
            sh_name = struct.unpack_from("<I", d, off)[0]
            sh_type = struct.unpack_from("<I", d, off + 4)[0]
            sh_flags = struct.unpack_from("<Q", d, off + 8)[0]
            sh_addr = struct.unpack_from("<Q", d, off + 0x10)[0]
            sh_offset = struct.unpack_from("<Q", d, off + 0x18)[0]
            sh_size = struct.unpack_from("<Q", d, off + 0x20)[0]
            sh_link = struct.unpack_from("<I", d, off + 0x28)[0]
            sh_info = struct.unpack_from("<I", d, off + 0x2c)[0]
            sh_entsize = struct.unpack_from("<Q", d, off + 0x38)[0]
            sections.append({
                "name_off": sh_name, "type": sh_type, "flags": sh_flags,
                "addr": sh_addr, "offset": sh_offset, "size": sh_size,
                "link": sh_link, "info": sh_info, "entsize": sh_entsize,
            })
        # 节名字符串表
        shstr = sections[e_shstrndx]
        shstr_data = d[shstr["offset"]:shstr["offset"] + shstr["size"]]
        for s in sections:
            end = shstr_data.index(b"\x00", s["name_off"])
            s["name"] = shstr_data[s["name_off"]:end].decode()
        # 找 .text、.symtab、.strtab、.rela.*
        text_sec = None
        symtab_sec = None
        strtab_sec = None
        rela_sections = {}  # 节名 -> sec_info
        for s in sections:
            if s["name"] == ".text":
                text_sec = s
            elif s["name"] == ".symtab":
                symtab_sec = s
            elif s["name"] == ".strtab":
                strtab_sec = s
            elif s["name"].startswith(".rela"):
                rela_sections[s["name"]] = s
        if text_sec is None:
            raise ValueError("no .text section")
        self.text_bytes = d[text_sec["offset"]:text_sec["offset"] + text_sec["size"]]
        self.text_addr = text_sec["addr"]
        # 符号
        if symtab_sec and strtab_sec:
            strtab = d[strtab_sec["offset"]:strtab_sec["offset"] + strtab_sec["size"]]
            n = symtab_sec["size"] // 24
            for i in range(n):
                off = symtab_sec["offset"] + i * 24
                st_name = struct.unpack_from("<I", d, off)[0]
                st_info = d[off + 4]
                st_other = d[off + 5]
                st_shndx = struct.unpack_from("<H", d, off + 6)[0]
                st_value = struct.unpack_from("<Q", d, off + 8)[0]
                st_size = struct.unpack_from("<Q", d, off + 16)[0]
                if st_name == 0:
                    name = ""
                else:
                    end = strtab.index(b"\x00", st_name)
                    name = strtab[st_name:end].decode()
                is_func = (st_info & 0xF) == 2  # STT_FUNC
                is_global = (st_info >> 4) == 1  # STB_GLOBAL
                # st_shndx：符号所在节索引。0xfff1 = SHN_ABS
                self.symbols.append(X86Symbol(name, st_value, st_size,
                                              st_shndx, is_func, is_global))
        # 所有 .rela.* 的重定位（RELA）
        for rela_name, rela_sec in rela_sections.items():
            symtab = self.symbols
            n = rela_sec["size"] // 24
            relocs = []
            for i in range(n):
                off = rela_sec["offset"] + i * 24
                r_offset = struct.unpack_from("<Q", d, off)[0]
                r_info = struct.unpack_from("<Q", d, off + 8)[0]
                r_addend = struct.unpack_from("<q", d, off + 16)[0]
                sym_idx = r_info >> 32
                rtype = r_info & 0xFFFFFFFF
                sym_name = symtab[sym_idx].name if sym_idx < len(symtab) else ""
                sym_sec = symtab[sym_idx].section if sym_idx < len(symtab) else -1
                relocs.append(X86Reloc(r_offset, rtype, sym_name, r_addend, sym_sec))
            if rela_name == ".rela.text":
                self.relocs = relocs
            else:
                self.data_relocs[rela_name] = relocs

    def functions(self):
        """返回函数符号列表（按地址排序）。"""
        funcs = [s for s in self.symbols if s.is_func and s.size > 0
                 and s.name and not s.name.startswith("_")]
        funcs.sort(key=lambda s: s.value)
        return funcs

    def globals_data(self):
        """返回全局数据的 (name, value, size, is_bss, relocs) 元组。

        已初始化全局变量来自 ``.data`` / ``.rodata``（带原始字节）。
        零初始化全局变量在 ``.bss``（无文件字节；我们发 ``.space``）。
        ``is_bss=True`` 标记这类。
        ``relocs`` 是 [(offset, resolved_name), ...] 列表，用于 R_X86_64_64 重定位。
        """
        d = self.data
        e_shoff = struct.unpack_from("<Q", d, 0x28)[0]
        e_shentsize = struct.unpack_from("<H", d, 0x3a)[0]
        e_shnum = struct.unpack_from("<H", d, 0x3c)[0]
        e_shstrndx = struct.unpack_from("<H", d, 0x3e)[0]
        sections = []
        for i in range(e_shnum):
            off = e_shoff + i * e_shentsize
            s = {
                "name_off": struct.unpack_from("<I", d, off)[0],
                "type": struct.unpack_from("<I", d, off + 4)[0],
                "offset": struct.unpack_from("<Q", d, off + 0x18)[0],
                "size": struct.unpack_from("<Q", d, off + 0x20)[0],
                "addr": struct.unpack_from("<Q", d, off + 0x10)[0],
            }
            sections.append(s)
        shstr = sections[e_shstrndx]
        shstr_data = d[shstr["offset"]:shstr["offset"] + shstr["size"]]
        for s in sections:
            end = shstr_data.index(b"\x00", s["name_off"])
            s["name"] = shstr_data[s["name_off"]:end].decode()
        out = []
        # 收集所有数据重定位，按节名索引
        R_X86_64_64 = 1
        all_data_relocs = {}  # section_name -> [(offset, reloc), ...]
        for rela_name, relocs in self.data_relocs.items():
            # .rela.data -> ".data"
            sec_name = rela_name[5:]  # strip ".rela"
            if sec_name not in all_data_relocs:
                all_data_relocs[sec_name] = []
            all_data_relocs[sec_name].extend(relocs)
        for sym in self.symbols:
            if not sym.name or sym.size == 0:
                continue
            if sym.section < 0 or sym.section >= len(sections):
                continue
            sec = sections[sym.section]
            if sec["name"] in (".data", ".rodata") or sec["name"].startswith(".data.rel"):
                data_off = sec["offset"] + sym.value
                raw = d[data_off:data_off + sym.size]
                # 解析该符号内的重定位
                sym_relocs = []
                for reloc in all_data_relocs.get(sec["name"], []):
                    if reloc.type == R_X86_64_64:
                        if sym.value <= reloc.offset < sym.value + sym.size:
                            rel_off = reloc.offset - sym.value
                            # 解析重定位目标
                            resolved = self._resolve_sym_by_reloc(
                                reloc.symbol, reloc.addend, reloc.section_idx)
                            sym_relocs.append((rel_off, resolved))
                out.append((sym.name, raw, sym.size, False, sym_relocs))
            elif sec["name"] == ".bss":
                out.append((sym.name, b"", sym.size, True, []))
        return out

    def _resolve_sym_by_reloc(self, sym_name, addend, sec_idx=-1):
        """将 section+offset 的引用解析为实际符号名。"""
        if not sym_name and sec_idx >= 0:
            sym_name = self._section_name_by_idx(sec_idx)
        if sym_name and (not sym_name.startswith(".") or sym_name.startswith(".L")):
            return sym_name
        for s in self.symbols:
            if s.size == 0 or s.section < 0:
                continue
            if s.value == addend and s.name:
                if sym_name:
                    sname = self._section_name_by_idx(s.section)
                    if sname != sym_name:
                        continue
                return s.name
        if sym_name:
            for s in self.symbols:
                if s.size == 0 or s.section < 0:
                    continue
                sname = self._section_name_by_idx(s.section)
                if sname == sym_name and s.value <= addend <= s.value + s.size:
                    return s.name
            safe = sym_name.replace(".", "_")
            return "__sec_%s" % safe
        return "__anon_0x%x" % addend

    def _section_name_by_idx(self, sec_idx):
        """获取节索引对应的节名。"""
        d = self.data
        e_shoff = struct.unpack_from("<Q", d, 0x28)[0]
        e_shentsize = struct.unpack_from("<H", d, 0x3a)[0]
        e_shnum = struct.unpack_from("<H", d, 0x3c)[0]
        e_shstrndx = struct.unpack_from("<H", d, 0x3e)[0]
        shstr_off = e_shoff + e_shstrndx * e_shentsize
        shstr_offset = struct.unpack_from("<Q", d, shstr_off + 0x18)[0]
        shstr_size = struct.unpack_from("<Q", d, shstr_off + 0x20)[0]
        shstr_data = d[shstr_offset:shstr_offset + shstr_size]
        sec_off = e_shoff + sec_idx * e_shentsize
        name_off = struct.unpack_from("<I", d, sec_off)[0]
        end = shstr_data.index(b"\x00", name_off)
        return shstr_data[name_off:end].decode()

    def _section_name(self, sec_idx):
        """获取节索引对应的节名。"""
        d = self.data
        e_shoff = struct.unpack_from("<Q", d, 0x28)[0]
        e_shentsize = struct.unpack_from("<H", d, 0x3a)[0]
        e_shstrndx = struct.unpack_from("<H", d, 0x3e)[0]
        shstr_off = e_shoff + e_shstrndx * e_shentsize
        shstr_offset = struct.unpack_from("<Q", d, shstr_off + 0x18)[0]
        shstr_size = struct.unpack_from("<Q", d, shstr_off + 0x20)[0]
        shstr_data = d[shstr_offset:shstr_offset + shstr_size]
        sec_off = e_shoff + sec_idx * e_shentsize
        name_off = struct.unpack_from("<I", d, sec_off)[0]
        end = shstr_data.index(b"\x00", name_off)
        return shstr_data[name_off:end].decode()

    def rodata_sections(self):
        """返回所有 rodata 节的数据，格式为 [(section_name, data_bytes, symbols), ...]。
        symbols 是 [(symbol_name, offset), ...] 列表，用于为每个本地符号发标签。
        """
        d = self.data
        e_shoff = struct.unpack_from("<Q", d, 0x28)[0]
        e_shentsize = struct.unpack_from("<H", d, 0x3a)[0]
        e_shnum = struct.unpack_from("<H", d, 0x3c)[0]
        e_shstrndx = struct.unpack_from("<H", d, 0x3e)[0]
        sections = []
        for i in range(e_shnum):
            off = e_shoff + i * e_shentsize
            s = {
                "name_off": struct.unpack_from("<I", d, off)[0],
                "name": "",
                "offset": struct.unpack_from("<Q", d, off + 0x18)[0],
                "size": struct.unpack_from("<Q", d, off + 0x20)[0],
            }
            sections.append(s)
        shstr = sections[e_shstrndx]
        shstr_data = d[shstr["offset"]:shstr["offset"] + shstr["size"]]
        for s in sections:
            end = shstr_data.index(b"\x00", s["name_off"])
            s["name"] = shstr_data[s["name_off"]:end].decode()
        out = []
        for s_idx, s in enumerate(sections):
            if s["name"].startswith(".rodata") and s["size"] > 0:
                data = d[s["offset"]:s["offset"] + s["size"]]
                # 收集该节内的符号
                syms = []
                for sym in self.symbols:
                    if sym.section == s_idx and sym.name and sym.name.startswith(".L"):
                        syms.append((sym.name, sym.value))
                # 按偏移排序并去重
                syms.sort(key=lambda x: x[1])
                out.append((s["name"], data, syms))
        return out


# ---------------------------------------------------------------------------
# s390x ELF 生成
# ---------------------------------------------------------------------------

# RIP 相对 x86 地址（指令末尾 + disp）-> 引用符号 的映射。
# 由调用方用对象文件的重定位构建，传入 rewrite_placeholders()。


def rewrite_placeholders(asm_lines, x86_obj, text_base_addr):
    """把 CALL / RIP_* 占位符行改写成真实 s390x 指令。

    占位符编码包含重定位字段的 .o 文本偏移范围：
      * ``CALL 0x<off>`` -- off 是 call 的 rel32 字段偏移
        （即 call 指令地址 + 1）。
      * ``RIP_<kind>\t<reg>\t0x<insn_addr>\t0x<insn_len>`` -- disp32 字段
        在 ``[insn_addr, insn_addr + insn_len)`` 内某处。

    扫描重定位表找落在此范围的重定位，再发引用该符号的真实 s390x 指令。

    子字加载（RIP_zld8 / RIP_zld16 / RIP_sld8 / RIP_sld16）按**符号真实大小**
    选加载宽度，保证大端字节位置正确：
      * ``char``（size=1）用 ``llgc``（偏移 0 处 1 字节）。
      * ``int``（size=4）当字节读时用 ``l``（4 字节），再用 ``llgcr``
        提取低位（寄存器操作）。
    """
    relocs = x86_obj.relocs

    # R_X86_64_PC32 = 2: the addend is NOT the target offset within the section.
    # The actual target offset = addend + insn_end - reloc_offset.
    # For other types (R_X86_64_32S=11, R_X86_64_32=10), the addend IS the target offset.
    _R_X86_64_PC32 = 2

    def _compute_target_offset(r, insn_addr, insn_len):
        """Compute the actual target offset within the section for a relocation.
        
        For R_X86_64_PC32: target = addend + insn_end - reloc_offset
        For others: target = addend (raw addend is the absolute/offset value)
        """
        if r.type == _R_X86_64_PC32:
            return r.addend + insn_addr + insn_len - r.offset
        return r.addend

    def _find_sym_in_range(insn_addr, insn_len):
        """找重定位偏移在 [insn_addr, insn_addr + insn_len) 内的符号。
        返回 (resolved_name, addend) 或 None。"""
        for r in relocs:
            if insn_addr <= r.offset < insn_addr + insn_len:
                target = _compute_target_offset(r, insn_addr, insn_len)
                return _resolve_section_sym(r.symbol, target, r.section_idx), target
        return None

    def _find_sym_exact(off):
        """找重定位偏移正好等于 off 的符号。返回 (resolved_name, addend) 或 None。"""
        for r in relocs:
            if r.offset == off:
                # CALL relocations use PC32; compute actual target offset
                # insn_addr = off - 1 (since CALL reloc is at offset of rel32, one byte into instr)
                # insn_len = 5
                target = _compute_target_offset(r, off - 1, 5)
                return _resolve_section_sym(r.symbol, target, r.section_idx), target
        return None

    def _resolve_section_sym(sym_name, addend, sec_idx=-1):
        """将 section+offset 的引用解析为实际符号名。
        
        若 sym_name 是节名（如 .bss、.rodata）或空字符串，查符号表中哪个符号
        在该节内并包含该偏移，返回符号名。若找不到，生成合成标签。
        """
        # 若 sym_name 为空，通过 sec_idx 获取节名
        if not sym_name and sec_idx >= 0:
            sym_name = _section_name(sec_idx)
        # .L 前缀的符号（如 .LC0, .LC1）是编译器生成的本地标签，不是节名
        if sym_name and (not sym_name.startswith(".") or sym_name.startswith(".L")):
            return sym_name
        # 节名或空名：查符号表按 addend 匹配
        for s in x86_obj.symbols:
            if s.size == 0 or s.section < 0:
                continue
            if s.value == addend and s.name:
                # 若指定了节名，还需验证节名匹配
                if sym_name:
                    sec_name = _section_name(s.section)
                    if sec_name != sym_name:
                        continue
                return s.name
        # 如果有节名，按节名+偏移范围匹配
        if sym_name:
            for s in x86_obj.symbols:
                if s.size == 0 or s.section < 0:
                    continue
                sec_name = _section_name(s.section)
                if sec_name == sym_name and s.value <= addend <= s.value + s.size:
                    return s.name
        # 生成合成标签 — 对于 rodata 节，返回节基标签（调用方负责加偏移）
        if sym_name:
            safe = sym_name.replace(".", "_")
            # rodata 节返回基标签，让调用方通过 larl base+offset 引用
            return "__sec_%s" % safe
        else:
            return "__anon_0x%x" % addend

    def _section_name(sec_idx):
        """获取节索引对应的节名。"""
        d = x86_obj.data
        e_shoff = struct.unpack_from("<Q", d, 0x28)[0]
        e_shentsize = struct.unpack_from("<H", d, 0x3a)[0]
        e_shnum = struct.unpack_from("<H", d, 0x3c)[0]
        e_shstrndx = struct.unpack_from("<H", d, 0x3e)[0]
        shstr_off = e_shoff + e_shstrndx * e_shentsize
        shstr_offset = struct.unpack_from("<Q", d, shstr_off + 0x18)[0]
        shstr_size = struct.unpack_from("<Q", d, shstr_off + 0x20)[0]
        shstr_data = d[shstr_offset:shstr_offset + shstr_size]
        sec_off = e_shoff + sec_idx * e_shentsize
        name_off = struct.unpack_from("<I", d, sec_off)[0]
        end = shstr_data.index(b"\x00", name_off)
        return shstr_data[name_off:end].decode()

    def _find_sym_size(sym_name):
        """从符号表查符号大小。"""
        for s in x86_obj.symbols:
            if s.name == sym_name:
                return s.size
        return 0

    def _find_sym_value(sym_name):
        """从符号表查符号值（节内偏移）。"""
        for s in x86_obj.symbols:
            if s.name == sym_name:
                return s.value
        return 0

    def _find_func_at_addr(addr):
        """在符号表中查找地址为 addr 的函数符号。"""
        for s in x86_obj.symbols:
            if s.is_func and s.value == addr:
                return s.name
        return None

    out = []
    for line in asm_lines:
        if line.startswith("CALL\t"):
            parts = line.split("\t")
            off = int(parts[1], 16)
            result = _find_sym_exact(off)
            if result is None:
                # 内部调用（无重定位）：用目标 x86 地址查符号表
                target = int(parts[2], 16)
                sym = _find_func_at_addr(target)
                if sym is None:
                    raise ValueError("cannot resolve call at .text+0x%x (target=0x%x)" % (off, target))
            else:
                sym = result[0]
            out.append("\tbrasl\t%%r14,%s" % sym)
            continue
        if line.startswith("CMP_IMM32\t"):
            # cmp $imm32, %reg，可能带重定位。
            # 格式：CMP_IMM32\t%rN\t<insn_addr>\t<insn_len>\t<imm_val>\t<is64>
            parts = line.split("\t")
            reg_target = parts[1]                  # %rN
            insn_addr = int(parts[2], 16)
            insn_len = int(parts[3], 16)
            imm_val = int(parts[4])
            is64 = int(parts[5])
            result = _find_sym_in_range(insn_addr, insn_len)
            if result is not None:
                sym = result[0]
                addend = result[1]
                # 加载符号地址到 r1，加上 addend 偏移
                out.append("\tlarl\t%%r1,%s" % sym)
                if addend != 0:
                    out.append("\taghi\t%%r1,%d" % addend)
                # 比较
                out.append((("\tcgr\t%s,%%r1" if is64 else "\tcr\t%s,%%r1") % reg_target))
            else:
                # 无重定位：直接用立即数比较
                out.append((("\tcgfi\t%s,%d" if is64 else "\tcfi\t%s,%d") % (reg_target, imm_val)))
            continue
        if line.startswith("SUB_IMM32\t"):
            # sub $imm32, %reg，可能带重定位。
            # 格式：SUB_IMM32\t%rN\t<insn_addr>\t<insn_len>\t<imm_val>\t<is64>
            parts = line.split("\t")
            reg_target = parts[1]                  # %rN
            insn_addr = int(parts[2], 16)
            insn_len = int(parts[3], 16)
            imm_val = int(parts[4])
            is64 = int(parts[5])
            result = _find_sym_in_range(insn_addr, insn_len)
            if result is not None:
                sym = result[0]
                addend = result[1]
                # 计算符号内的偏移量：addend 是重定位目标在节内的偏移，
                # sym_value 是符号在节内的偏移。差值即为符号内偏移。
                sym_value = _find_sym_value(sym)
                sym_offset = addend - sym_value
                # 加载符号地址到 r1，加上符号内偏移
                out.append("\tlarl\t%%r1,%s" % sym)
                if sym_offset != 0:
                    out.append("\taghi\t%%r1,%d" % sym_offset)
                # 减法
                out.append((("\tsgr\t%s,%%r1" if is64 else "\tsr\t%s,%%r1") % reg_target))
            else:
                # 无重定位：直接用立即数做减法
                imm_val = -imm_val  # sub $x = add $-x
                if -0x8000 <= imm_val <= 0x7FFF:
                    out.append((("\taghi\t%s,%d" if is64 else "\tahi\t%s,%d") % (reg_target, imm_val)))
                else:
                    out.append((("\tsgfi\t%s,%d" if is64 else "\tsfi\t%s,%d") % (reg_target, -imm_val)))
            continue
        if line.startswith("MOV_IMM32\t"):
            # mov $imm32, %reg，可能带 R_X86_64_32 重定位。
            # 范围内有重定位则发 larl 加载符号地址；否则发立即数值。
            # 注意：larl 指令只能寻址偶地址（偏移量左移 1 位），
            # 因此对于奇数偏移，先 larl 加载基址再 aghi 加上偏移。
            parts = line.split("\t")
            reg_target = parts[1]                  # %rN
            insn_addr = int(parts[2], 16)
            insn_len = int(parts[3], 16)
            imm_val = int(parts[4])
            result = _find_sym_in_range(insn_addr, insn_len)
            if result is not None:
                sym = result[0]
                addend = result[1]
                out.append("\tlarl\t%s,%s" % (reg_target, sym))
                if addend != 0:
                    out.append("\taghi\t%s,%d" % (reg_target, addend))
            else:
                # 无重定位：加载 32 位立即数
                if -0x8000 <= imm_val <= 0x7FFF:
                    out.append("\tlghi\t%s,%d" % (reg_target, imm_val))
                elif -0x80000000 <= imm_val <= 0x7FFFFFFF:
                    out.append("\tlgfi\t%s,%d" % (reg_target, imm_val))
                else:
                    out.append("\tllilf\t%s,%d" % (reg_target, imm_val & 0xFFFFFFFF))
            continue
        if line.startswith("RIP_IDX_"):
            parts = line.split("\t")
            kind = parts[0]  # RIP_IDX_ld64 / RIP_IDX_st64 / RIP_IDX_lea / ...
            base_kind = kind[8:]  # strip "RIP_IDX_"
            reg_target = parts[1]            # %rN
            insn_addr = int(parts[2], 16)
            insn_len = int(parts[3], 16)
            idx_reg = parts[4]               # %rN (scaled index)
            result = _find_sym_in_range(insn_addr, insn_len)
            if result is None:
                raise ValueError("cannot resolve RIP_IDX reloc at .text+0x%x"
                                 % insn_addr)
            sym = result[0]
            # 存储操作：reg_target 持有要写入的值，但 larl 会覆写它。
            # 先把值存到栈上，算完地址再恢复。
            is_store = base_kind.startswith("st")
            if is_store and reg_target == "%r0":
                out.append("\taghi\t%r15,-8")
                out.append("\tstg\t%s,0(%%r15)" % reg_target)
            # larl -> r0, algr idx_reg, r0 -> idx_reg = base + scaled_index
            out.append("\tlarl\t%%r0,%s" % sym)
            out.append("\talgr\t%s,%%r0" % idx_reg)
            if is_store and reg_target == "%r0":
                out.append("\tlg\t%r0,0(%r15)")
                out.append("\taghi\t%r15,8")
            if base_kind == "lea":
                if reg_target != idx_reg:
                    out.append("\tlgr\t%s,%s" % (reg_target, idx_reg))
            elif base_kind == "ld64":
                out.append("\tlg\t%s,0(%s)" % (reg_target, idx_reg))
            elif base_kind == "st64":
                out.append("\tstg\t%s,0(%s)" % (reg_target, idx_reg))
            elif base_kind == "ld32":
                # 32-bit load: 若符号是 8 字节，大端下低 32 位在偏移 4
                sym_sz = _find_sym_size(sym)
                off = 4 if sym_sz == 8 else 0
                out.append("\tl\t%s,%d(%s)" % (reg_target, off, idx_reg))
            elif base_kind == "st32":
                # 32-bit store: 若符号是 8 字节，大端下低 32 位在偏移 4
                sym_sz = _find_sym_size(sym)
                off = 4 if sym_sz == 8 else 0
                out.append("\tst\t%s,%d(%s)" % (reg_target, off, idx_reg))
            elif base_kind == "ld8":
                out.append("\tllgc\t%s,0(%s)" % (reg_target, idx_reg))
            elif base_kind == "st8":
                out.append("\tstc\t%s,0(%s)" % (reg_target, idx_reg))
            elif base_kind == "ld16":
                out.append("\tllgh\t%s,0(%s)" % (reg_target, idx_reg))
            elif base_kind == "st16":
                out.append("\tsth\t%s,0(%s)" % (reg_target, idx_reg))
            else:
                raise ValueError("unknown RIP_IDX kind: %s" % kind)
            continue
        if line.startswith("ABS_IDX_"):
            # ABS_IDX_<ld/st><size>\t<reg>\t<insn_addr>\t<insn_len>\t<idx_reg>
            parts = line.split("\t")
            kind = parts[0]  # ABS_IDX_ld64 / ABS_IDX_st64 / ABS_IDX_lea / ...
            base_kind = kind[8:]  # strip "ABS_IDX_"
            reg_target = parts[1]            # %rN
            insn_addr = int(parts[2], 16)
            insn_len = int(parts[3], 16)
            idx_reg = parts[4]               # %rN (scaled index)
            result = _find_sym_in_range(insn_addr, insn_len)
            if result is None:
                raise ValueError("cannot resolve ABS_IDX reloc at .text+0x%x"
                                 % insn_addr)
            sym = result[0]
            # larl 会覆写 r0。若 r0 持有需要保留的值（循环变量等），
            # 先存到栈上，算完地址再恢复。
            # 例外：ld* 操作把结果加载到 r0，此时不恢复（x86 语义下 r0 已更新）。
            is_store = base_kind.startswith("st")
            is_load_to_r0 = (not is_store) and reg_target == "%r0" and base_kind != "lea"
            need_save_r0 = not is_load_to_r0
            if need_save_r0:
                out.append("\taghi\t%r15,-8")
                out.append("\tstg\t%r0,0(%r15)")
            # larl -> r0, algr idx_reg, r0 -> idx_reg = base + scaled_index
            out.append("\tlarl\t%%r0,%s" % sym)
            out.append("\talgr\t%s,%%r0" % idx_reg)
            if need_save_r0:
                out.append("\tlg\t%r0,0(%r15)")
                out.append("\taghi\t%r15,8")
            if base_kind == "lea":
                if reg_target != idx_reg:
                    out.append("\tlgr\t%s,%s" % (reg_target, idx_reg))
            elif base_kind == "ld64":
                out.append("\tlg\t%s,0(%s)" % (reg_target, idx_reg))
            elif base_kind == "st64":
                out.append("\tstg\t%s,0(%s)" % (reg_target, idx_reg))
            elif base_kind == "ld32":
                # 32-bit load: 若符号是 8 字节，大端下低 32 位在偏移 4
                sym_sz = _find_sym_size(sym)
                off = 4 if sym_sz == 8 else 0
                out.append("\tl\t%s,%d(%s)" % (reg_target, off, idx_reg))
            elif base_kind == "st32":
                # 32-bit store: 若符号是 8 字节，大端下低 32 位在偏移 4
                sym_sz = _find_sym_size(sym)
                off = 4 if sym_sz == 8 else 0
                out.append("\tst\t%s,%d(%s)" % (reg_target, off, idx_reg))
            elif base_kind == "ld8":
                out.append("\tllgc\t%s,0(%s)" % (reg_target, idx_reg))
            elif base_kind == "st8":
                out.append("\tstc\t%s,0(%s)" % (reg_target, idx_reg))
            elif base_kind == "ld16":
                out.append("\tllgh\t%s,0(%s)" % (reg_target, idx_reg))
            elif base_kind == "st16":
                out.append("\tsth\t%s,0(%s)" % (reg_target, idx_reg))
            else:
                raise ValueError("unknown ABS_IDX kind: %s" % kind)
            continue
        if line.startswith("ABS_BASE_"):
            # ABS_BASE_<ld/st><size>\t<reg>\t<insn_addr>\t<insn_len>\t<base_reg>\t<disp>
            parts = line.split("\t")
            kind = parts[0]  # ABS_BASE_ld64 / ABS_BASE_st64 / ABS_BASE_lea / ...
            base_kind = kind[9:]  # strip "ABS_BASE_"
            reg_target = parts[1]            # %rN
            insn_addr = int(parts[2], 16)
            insn_len = int(parts[3], 16)
            base_reg = parts[4]               # %rN (base register)
            disp = int(parts[5])              # original displacement
            result = _find_sym_in_range(insn_addr, insn_len)
            if result is None:
                # No relocation found; use the literal displacement
                raise ValueError("cannot resolve ABS_BASE reloc at .text+0x%x"
                                 % insn_addr)
            sym = result[0]
            addend = result[1]
            # 计算符号内的偏移量：addend 是重定位目标在节内的偏移，
            # sym_value 是符号在节内的偏移。差值即为符号内偏移。
            sym_value = _find_sym_value(sym)
            sym_offset = addend - sym_value
            # larl would clobber r0; save/restore if needed
            is_store = base_kind.startswith("st")
            is_load_to_r0 = (not is_store) and reg_target == "%r0" and base_kind != "lea"
            need_save_r0 = not is_load_to_r0
            if need_save_r0:
                out.append("\taghi\t%r15,-8")
                out.append("\tstg\t%r0,0(%r15)")
            # larl -> r0, r1 = base_reg, algr r1, r0 -> r1 = base + symbol_addr
            # Use r1 as scratch to avoid modifying base_reg, preserving it
            # for subsequent instructions that use the same base register value
            # (e.g., consecutive stores to proc_regs[i][0], proc_regs[i][1], ...).
            out.append("\tlarl\t%%r0,%s" % sym)
            out.append("\tlgr\t%%r1,%s" % base_reg)
            out.append("\talgr\t%r1,%r0")
            # 加上符号内偏移（如 proc_regs[i][1] = proc_regs + i*16 + 4）
            if sym_offset != 0:
                out.append("\taghi\t%%r1,%d" % sym_offset)
            if need_save_r0:
                out.append("\tlg\t%r0,0(%r15)")
                out.append("\taghi\t%r15,8")
            if base_kind == "lea":
                if reg_target != "%r1":
                    out.append("\tlgr\t%s,%%r1" % reg_target)
            elif base_kind == "ld64":
                out.append("\tlg\t%s,0(%%r1)" % reg_target)
            elif base_kind == "st64":
                out.append("\tstg\t%s,0(%%r1)" % reg_target)
            elif base_kind == "ld32":
                # 32-bit load: 若符号是 8 字节，大端下低 32 位在偏移 4
                sym_sz = _find_sym_size(sym)
                off = 4 if sym_sz == 8 else 0
                out.append("\tl\t%s,%d(%%r1)" % (reg_target, off))
            elif base_kind == "st32":
                # 32-bit store: 若符号是 8 字节，大端下低 32 位在偏移 4
                sym_sz = _find_sym_size(sym)
                off = 4 if sym_sz == 8 else 0
                out.append("\tst\t%s,%d(%%r1)" % (reg_target, off))
            elif base_kind == "ld8":
                out.append("\tllgc\t%s,0(%%r1)" % reg_target)
            elif base_kind == "st8":
                out.append("\tstc\t%s,0(%%r1)" % reg_target)
            elif base_kind == "ld16":
                out.append("\tllgh\t%s,0(%%r1)" % reg_target)
            elif base_kind == "st16":
                out.append("\tsth\t%s,0(%%r1)" % reg_target)
            else:
                raise ValueError("unknown ABS_BASE kind: %s" % kind)
            continue
        if line.startswith("RIP_"):
            parts = line.split("\t")
            kind = parts[0]  # RIP_ld64 / RIP_st64 / ...
            reg_target = parts[1]            # %rN
            insn_addr = int(parts[2], 16)    # 指令起始的 .o 文本偏移
            insn_len = int(parts[3], 16)     # 指令长度
            result = _find_sym_in_range(insn_addr, insn_len)
            if result is None:
                raise ValueError("cannot resolve RIP reloc at .text+0x%x (range +0x%x)"
                                 % (insn_addr, insn_len))
            sym = result[0]

            # 子字加载：按符号真实大小选加载指令，保证大端字节位置正确
            if kind in ("RIP_zld8", "RIP_sld8", "RIP_zld16", "RIP_sld16"):
                sz = _find_sym_size(sym)
                out.append("\tlarl\t%%r1,%s" % sym)
                if kind == "RIP_zld8":
                    # 字节零扩展加载（movzbl）
                    if sz <= 1:
                        out.append("\tllgc\t%s,0(%%r1)" % reg_target)
                    elif sz == 2:
                        out.append("\tllgh\t%s,0(%%r1)" % reg_target)
                        out.append("\tllgcr\t%s,%s" % (reg_target, reg_target))
                    elif sz == 4:
                        out.append("\tl\t%s,0(%%r1)" % reg_target)
                        out.append("\tllgcr\t%s,%s" % (reg_target, reg_target))
                    else:  # 8
                        out.append("\tlg\t%s,0(%%r1)" % reg_target)
                        out.append("\tllgcr\t%s,%s" % (reg_target, reg_target))
                elif kind == "RIP_sld8":
                    # 字节符号扩展加载（movsbl）
                    if sz <= 1:
                        out.append("\tllgc\t%s,0(%%r1)" % reg_target)
                    elif sz == 2:
                        out.append("\tllgh\t%s,0(%%r1)" % reg_target)
                    elif sz == 4:
                        out.append("\tl\t%s,0(%%r1)" % reg_target)
                    else:
                        out.append("\tlg\t%s,0(%%r1)" % reg_target)
                    out.append("\tlgbr\t%s,%s" % (reg_target, reg_target))
                elif kind == "RIP_zld16":
                    # 半字零扩展加载（movzwl）
                    if sz <= 2:
                        out.append("\tllgh\t%s,0(%%r1)" % reg_target)
                    elif sz == 4:
                        out.append("\tl\t%s,0(%%r1)" % reg_target)
                        out.append("\tllghr\t%s,%s" % (reg_target, reg_target))
                    else:
                        out.append("\tlg\t%s,0(%%r1)" % reg_target)
                        out.append("\tllghr\t%s,%s" % (reg_target, reg_target))
                elif kind == "RIP_sld16":
                    # 半字符号扩展加载（movswl）
                    if sz <= 2:
                        out.append("\tllgh\t%s,0(%%r1)" % reg_target)
                    elif sz == 4:
                        out.append("\tl\t%s,0(%%r1)" % reg_target)
                    else:
                        out.append("\tlg\t%s,0(%%r1)" % reg_target)
                    out.append("\tlghr\t%s,%s" % (reg_target, reg_target))
                continue

            if kind == "RIP_lea":
                out.append("\tlarl\t%s,%s" % (reg_target, sym))
            elif kind == "RIP_ld64":
                out.append("\tlarl\t%%r1,%s" % sym)
                out.append("\tlg\t%s,0(%%r1)" % reg_target)
            elif kind == "RIP_st64":
                out.append("\tlarl\t%%r1,%s" % sym)
                out.append("\tstg\t%s,0(%%r1)" % reg_target)
            elif kind == "RIP_ld32":
                # 32-bit load: 若符号是 8 字节（指针/长整型），大端下低 32 位在偏移 4
                sym_sz = _find_sym_size(sym)
                off = 4 if sym_sz == 8 else 0
                out.append("\tlarl\t%%r1,%s" % sym)
                out.append("\tl\t%s,%d(%%r1)" % (reg_target, off))
            elif kind == "RIP_st32":
                # 32-bit store: 若符号是 8 字节，大端下低 32 位在偏移 4
                sym_sz = _find_sym_size(sym)
                off = 4 if sym_sz == 8 else 0
                out.append("\tlarl\t%%r1,%s" % sym)
                out.append("\tst\t%s,%d(%%r1)" % (reg_target, off))
            elif kind == "RIP_ld8":
                out.append("\tlarl\t%%r1,%s" % sym)
                out.append("\tllgc\t%s,0(%%r1)" % reg_target)
            elif kind == "RIP_st8":
                out.append("\tlarl\t%%r1,%s" % sym)
                out.append("\tstc\t%s,0(%%r1)" % reg_target)
            elif kind == "RIP_ld16":
                out.append("\tlarl\t%%r1,%s" % sym)
                out.append("\tllgh\t%s,0(%%r1)" % reg_target)
            elif kind == "RIP_st16":
                out.append("\tlarl\t%%r1,%s" % sym)
                out.append("\tsth\t%s,0(%%r1)" % reg_target)
            else:
                raise ValueError("unknown RIP kind: %s" % kind)
            continue
        out.append(line)
    return out


def _emit_rodata_sections(rodata_sections):
    """生成 rodata 节的汇编文本，包含基标签和原始数据。
    
    rodata_sections 是 [(section_name, data_bytes, symbols), ...] 列表，
    symbols 是 [(symbol_name, offset), ...] 列表。
    
    为每个符号单独发标签，确保 larl 能正确寻址（larl 只能寻址偶地址）。
    """
    if not rodata_sections:
        return ""
    lines = []
    for entry in rodata_sections:
        sec_name = entry[0]
        data = entry[1]
        symbols = entry[2] if len(entry) > 2 else []
        safe = sec_name.replace(".", "_")
        base_label = "__sec_%s" % safe
        lines.append("\n\t.section .rodata")
        lines.append("\t.globl %s" % base_label)
        lines.append("\t.balign 8")
        lines.append("%s:" % base_label)
        # 按偏移排序符号，在符号边界处发标签
        # 重要：s390x larl 指令只能寻址偶地址，因此每个符号标签前
        # 插入 .balign 2 确保符号地址是偶数。
        symbols.sort(key=lambda x: x[1])
        pos = 0
        sym_idx = 0
        while pos < len(data):
            # 在符号边界处发标签，确保偶数对齐
            while sym_idx < len(symbols) and symbols[sym_idx][1] == pos:
                sym_name = symbols[sym_idx][0]
                lines.append("\t.balign 2")
                lines.append("%s:" % sym_name)
                sym_idx += 1
            # 找到下一个符号边界或数据末尾
            next_pos = symbols[sym_idx][1] if sym_idx < len(symbols) else len(data)
            chunk = data[pos:next_pos]
            if chunk:
                lines.append("\t.byte " + ", ".join(str(b) for b in chunk))
            pos = next_pos
        lines.append("")
    return "\n".join(lines)


def build_executable(asm_text, globals_data, output_path, as_path="s390x-linux-gnu-as",
                     ld_path="s390x-linux-gnu-ld", with_glibc=False,
                     cc_path="s390x-linux-gnu-gcc", rodata_sections=None):
    """汇编 + 链接一个静态 s390x ELF 可执行文件。

    ``asm_text`` 是完整 s390x 汇编源（字符串）。``globals_data`` 是已初始化
    全局变量的 (name, bytes, size) 列表，据此发 ``.data`` 节。

    若 ``with_glibc=True``：用 s390x-linux-gnu-gcc 静态链接 glibc，
    支持 printf、malloc 等标准 C 函数。否则用裸 _start 桩。
    """
    if rodata_sections is None:
        rodata_sections = []
    if with_glibc:
        return _build_with_glibc(asm_text, globals_data, output_path,
                                 as_path, ld_path, cc_path, rodata_sections)

    # _start 桩：s390x Linux 上内核设 r2 = argc, r3 = argv。
    # 我们忽略参数，调用 main，再 exit(r2)。
    # s390x 系统调用 ABI：调用号在 r1，参数在 r2-r7，返回值在 r2。
    # SYS_exit = 1。
    stub = """
\t.text
\t.globl _start
_start:
\t# 建栈帧（s390x ABI 要求 r15 对齐 8，且被调用方需 160 字节保存区）
\taghi\t%r15,-160
\t# main() 返回 int 在 r2；掩到 8 位作退出码
\tbrasl\t%r14,main
\tnill\t%r2,255
\t# exit(r2)：调用号 1 放 r1，参数（退出码）留在 r2
\tlghi\t%r1,1
\tsvc\t0
"""
    # 已初始化全局放 .data，零初始化放 BSS。
    # x86-64 小端；s390x 大端。标量全局数据做字节交换。
    # 数组按元素交换（假定 4 字节 int 元素，常见情况）。
    data_section = "\n\t.data\n\t.globl __sec__data\n__sec__data:\n"
    bss_section = "\n\t.bss\n\t.globl __sec__bss\n__sec__bss:\n"
    has_data = False
    has_bss = False
    for entry in globals_data:
        name, raw, size = entry[0], entry[1], entry[2]
        is_bss = entry[3] if len(entry) > 3 else False
        sym_relocs = entry[4] if len(entry) > 4 else []
        if is_bss:
            bss_section += "\t.globl %s\n" % name
            bss_section += "\t.balign 8\n"
            bss_section += "%s:\n" % name
            bss_section += "\t.space %d\n" % size
            has_bss = True
        else:
            data_section += "\t.globl %s\n" % name
            data_section += "\t.balign 8\n"
            data_section += "%s:\n" % name
            if sym_relocs:
                # 有重定位：按 8 字节对齐，逐项发射 .quad
                sym_relocs.sort(key=lambda x: x[0])
                reloc_map = {off: resolved for off, resolved in sym_relocs}
                pos = 0
                while pos < size:
                    if pos in reloc_map:
                        data_section += "\t.quad %s\n" % reloc_map[pos]
                        pos += 8
                    else:
                        # 非重定位字节：从 raw 字节读取
                        remaining = size - pos
                        chunk = raw[pos:pos + min(remaining, 8)]
                        if chunk:
                            swapped = _byte_swap_le_to_be(chunk, len(chunk))
                            data_section += "\t.byte " + ", ".join(str(b) for b in swapped) + "\n"
                            pos += len(chunk)
                        else:
                            pos += 8
            elif raw:
                swapped = _byte_swap_le_to_be(raw, size)
                data_section += "\t.byte " + ", ".join(str(b) for b in swapped) + "\n"
            else:
                data_section += "\t.space %d\n" % size
            has_data = True
    sections_text = ""
    if has_data:
        sections_text += data_section
    if has_bss:
        sections_text += bss_section
    rodata_text = _emit_rodata_sections(rodata_sections)
    full = stub + "\n" + asm_text + sections_text + rodata_text + "\n"

    # DEBUG: save full assembly
    with open("/workspace/probe/full_asm.s", "w") as f:
        f.write(full)

    with tempfile.TemporaryDirectory() as td:
        asm_path = os.path.join(td, "out.s")
        obj_path = os.path.join(td, "out.o")
        with open(asm_path, "w") as f:
            f.write(full)
        # 汇编
        r = subprocess.run([as_path, "-m64", "-o", obj_path, asm_path],
                           capture_output=True, text=True)
        if r.returncode != 0:
            raise RuntimeError("s390x-as failed:\n%s\n--- source ---\n%s"
                               % (r.stderr, full))
        # 链接为静态可执行文件
        ld_args = [ld_path, "-m", "elf64_s390", "-o", output_path, obj_path]
        r = subprocess.run(ld_args, capture_output=True, text=True)
        if r.returncode != 0:
            raise RuntimeError("s390x-ld failed:\n%s" % r.stderr)
    return output_path


def _build_with_glibc(asm_text, globals_data, output_path, as_path, ld_path, cc_path, rodata_sections=None):
    """用 s390x-linux-gnu-gcc 静态链接 glibc 构建 ELF。

    这样翻译后的代码可以调用 printf、malloc、memcpy 等标准 C 函数。
    生成一个小的 C 包装器提供 _start，调用 __libc_start_main 初始化 glibc，
    然后调用翻译后的 main()。
    """
    if rodata_sections is None:
        rodata_sections = []
    # 数据段（与裸构建相同）
    data_section = "\n\t.data\n\t.globl __sec__data\n__sec__data:\n"
    bss_section = "\n\t.bss\n\t.globl __sec__bss\n__sec__bss:\n"
    has_data = False
    has_bss = False
    for entry in globals_data:
        name, raw, size = entry[0], entry[1], entry[2]
        is_bss = entry[3] if len(entry) > 3 else False
        sym_relocs = entry[4] if len(entry) > 4 else []
        if is_bss:
            bss_section += "\t.globl %s\n" % name
            bss_section += "\t.balign 8\n"
            bss_section += "%s:\n" % name
            bss_section += "\t.space %d\n" % size
            has_bss = True
        else:
            data_section += "\t.globl %s\n" % name
            data_section += "\t.balign 8\n"
            data_section += "%s:\n" % name
            if sym_relocs:
                # 有重定位：按 8 字节对齐，逐项发射 .quad
                sym_relocs.sort(key=lambda x: x[0])
                reloc_map = {off: resolved for off, resolved in sym_relocs}
                pos = 0
                while pos < size:
                    if pos in reloc_map:
                        data_section += "\t.quad %s\n" % reloc_map[pos]
                        pos += 8
                    else:
                        # 非重定位字节：从 raw 字节读取
                        remaining = size - pos
                        chunk = raw[pos:pos + min(remaining, 8)]
                        if chunk:
                            swapped = _byte_swap_le_to_be(chunk, len(chunk))
                            data_section += "\t.byte " + ", ".join(str(b) for b in swapped) + "\n"
                            pos += len(chunk)
                        else:
                            pos += 8
            elif raw:
                swapped = _byte_swap_le_to_be(raw, size)
                data_section += "\t.byte " + ", ".join(str(b) for b in swapped) + "\n"
            else:
                data_section += "\t.space %d\n" % size
            has_data = True
    sections_text = ""
    if has_data:
        sections_text += data_section
    if has_bss:
        sections_text += bss_section

    rodata_text = _emit_rodata_sections(rodata_sections)

    # 汇编源：翻译后的函数 + 数据
    asm_full = asm_text + sections_text + rodata_text + "\n"

    with tempfile.TemporaryDirectory() as td:
        # 汇编翻译后的代码
        asm_path = os.path.join(td, "trans.s")
        obj_path = os.path.join(td, "trans.o")
        with open(asm_path, "w") as f:
            f.write(asm_full)
        r = subprocess.run([as_path, "-m64", "-o", obj_path, asm_path],
                           capture_output=True, text=True)
        if r.returncode != 0:
            raise RuntimeError("s390x-as failed:\n%s\n--- source ---\n%s"
                               % (r.stderr, asm_full))

        # 写一个极小的 C 启动文件，提供 _start 并委托给 glibc
        c_start = os.path.join(td, "start.c")
        with open(c_start, "w") as f:
            f.write("""
/* 翻译后的 s390x 程序的启动桩 */
extern int main(int argc, char **argv);

/* glibc 需要的桩函数 */
void _init(void) {}
void _fini(void) {}

/* 直接调用 main，绕过 __libc_start_main 以避免 glibc 初始化问题 */
void __attribute__((noreturn)) _start(void) {
    long ret = main(0, 0);
    /* exit(ret) */
    __asm__ volatile("lghi %%r1,1\\n\\tsvc 0" : : "r"(ret) : "r1");
    __builtin_unreachable();
}
""")
        # 编译 C 启动文件
        c_obj = os.path.join(td, "start.o")
        r = subprocess.run(
            [cc_path, "-static", "-no-pie", "-O0", "-c", "-o", c_obj, c_start],
            capture_output=True, text=True)
        if r.returncode != 0:
            raise RuntimeError("s390x-gcc (start) failed:\n%s" % r.stderr)

        # 用 gcc 静态链接所有文件（-nostartfiles 避免与 crt1.o 的 _start 冲突）
        r = subprocess.run(
            [cc_path, "-static", "-no-pie", "-nostartfiles", "-o", output_path, c_obj, obj_path],
            capture_output=True, text=True)
        if r.returncode != 0:
            raise RuntimeError("s390x-gcc (link) failed:\n%s" % r.stderr)
    return output_path
