#!/usr/bin/env python3
"""x86tos390x -- 便携式 x86-64 -> s390x 静态二进制翻译器。

把 x86-64 机器码（裸字节或 gcc 产出的 ``.o`` 对象）翻译成 s390x 机器码，
生成可在 ``qemu-s390x`` 下运行的静态 ELF 可执行文件。

用法
----
翻译 x86-64 十六进制字节串并打印 s390x 汇编：

    ./x86tos390x.py --hex "48 b8 05 00 00 00 00 00 00 00 48 83 c0 03 c3" --list

把 gcc 对象文件翻译成 QEMU 可运行的 s390x ELF：

    gcc -O1 -c prog.c -o prog.o
    ./x86tos390x.py --obj prog.o --elf prog.s390x

    qemu-s390x prog.s390x ; echo "exit=$?"
"""
import argparse
import os
import re
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from src.x86 import decoder as x86dec
from src.translator import translate, TranslateError
from src import elf as elfmod


def _parse_hex(text):
    text = text.strip()
    text = text.replace(",", " ").replace("{", " ").replace("}", " ")
    text = text.replace("0x", " ").replace("\\x", " ")
    tokens = re.findall(r"[0-9A-Fa-f]{1,2}", text)
    return bytes(int(t, 16) for t in tokens)


def _hexdump(b):
    return " ".join("%02x" % x for x in b)


def translate_object(obj_path, list_asm=False):
    """把 x86-64 .o 文件翻译成 s390x 汇编文本。

    返回 ``(asm_text, globals_data, rodata_sections)``：asm_text 是完整 s390x 汇编源，
    globals_data 是要发到 .data 的已初始化全局符号列表，
    rodata_sections 是 [(section_name, data_bytes), ...] 只读数据节列表。
    """
    obj = elfmod.X86ObjectFile(obj_path)
    funcs = obj.functions()
    if not funcs:
        raise TranslateError("no functions found in %s" % obj_path)

    all_asm = []
    # 每个函数作为全局符号，带翻译后的函数体
    for sym in funcs:
        if list_asm:
            print("# function %s @0x%x size=%d" % (sym.name, sym.value, sym.size))
        func_bytes = obj.text_bytes[sym.value:sym.value + sym.size]
        insns = x86dec.decode(func_bytes, base_addr=sym.value)
        body = translate(insns, base_addr=sym.value)
        # 把占位符（CALL / RIP_*）改写成真实指令
        body = elfmod.rewrite_placeholders(body, obj, obj.text_addr)
        all_asm.append("\t.globl\t%s" % sym.name)
        all_asm.append("\t.type\t%s,@function" % sym.name)
        all_asm.append("%s:" % sym.name)
        for line in body:
            # 指令行缩进，标签顶格
            stripped = line.strip()
            if stripped.endswith(":") and not stripped.startswith("#"):
                all_asm.append(line)
            elif stripped.startswith("#"):
                all_asm.append(line)
            else:
                all_asm.append("\t" + line if not line.startswith("\t") else line)
        all_asm.append("")
        if list_asm:
            for line in body:
                print("  " + line)
    globals_data = obj.globals_data()
    rodata_sections = obj.rodata_sections()
    return "\n".join(all_asm) + "\n", globals_data, rodata_sections


def main(argv=None):
    p = argparse.ArgumentParser(
        prog="x86tos390x",
        description="Translate x86-64 machine code to s390x machine code.")
    g = p.add_mutually_exclusive_group(required=True)
    g.add_argument("--hex", help="x86-64 bytes as hex (e.g. \"48 89 c8 c3\")")
    g.add_argument("--in-file", help="raw x86-64 binary blob to translate")
    g.add_argument("--obj", help="gcc-produced x86-64 .o object file")
    p.add_argument("--out", help="write raw s390x assembly to this file")
    p.add_argument("--elf", help="write a QEMU-runnable s390x ELF to this file")
    p.add_argument("--list", action="store_true",
                   help="print a side-by-side x86 / s390x listing")
    p.add_argument("--glibc", action="store_true",
                   help="link with glibc (supports printf, malloc, etc.)")
    p.add_argument("--base-addr", type=lambda x: int(x, 0), default=0,
                   help="base address for listing/diagnostics (default 0)")
    args = p.parse_args(argv)

    if args.obj:
        # 对象文件模式：翻译每个函数，发 s390x 汇编，构建 ELF
        try:
            asm_text, globals_data, rodata_sections = translate_object(args.obj,
                                                      list_asm=args.list)
        except (TranslateError, x86dec.DecodeError, ValueError) as e:
            sys.exit("translation error: %s" % e)
        if args.out:
            with open(args.out, "w") as f:
                f.write(asm_text)
            print("wrote s390x assembly: %s" % args.out)
        if args.elf:
            try:
                elfmod.build_executable(asm_text, globals_data, args.elf,
                                        with_glibc=args.glibc,
                                        rodata_sections=rodata_sections)
            except RuntimeError as e:
                sys.exit(str(e))
            print("wrote s390x ELF: %s" % args.elf)
            print("  run with: qemu-s390x %s ; echo \"exit=$?\"" % args.elf)
        if not args.out and not args.elf:
            print(asm_text)
        return 0

    # 裸字节模式：翻译单个 blob，打印汇编
    if args.in_file:
        with open(args.in_file, "rb") as f:
            x86_bytes = f.read()
    else:
        x86_bytes = _parse_hex(args.hex)

    try:
        insns = x86dec.decode(x86_bytes, base_addr=args.base_addr)
        asm_lines = translate(insns, base_addr=args.base_addr)
    except (x86dec.DecodeError, TranslateError) as e:
        sys.exit("translation error: %s" % e)

    print("x86-64 (%d bytes): %s" % (len(x86_bytes), _hexdump(x86_bytes)))
    print()
    for line in asm_lines:
        print(line)

    if args.out:
        with open(args.out, "w") as f:
            f.write("\n".join(asm_lines))
        print("\nwrote s390x assembly: %s" % args.out)

    return 0


if __name__ == "__main__":
    sys.exit(main())
