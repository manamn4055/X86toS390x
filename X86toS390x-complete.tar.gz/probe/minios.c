/* ================================================================
 *  miniOS — 伪操作系统内核 (x86 -> s390x 跨架构翻译演示)
 *
 *  内核功能:
 *    1. 进程管理 — 8 进程 PCB 表 + 轮转调度器
 *    2. 内存管理 — 简易 malloc/free（固定池 + 空闲链表）
 *    3. 系统调用 — 内核态函数表，模拟 syscall 分发
 *    4. 用户进程 — 3 个计算型"用户程序"
 *    5. 输出 — 通过 write 系统调用打印到终端
 *
 *  编译:  gcc -O1 -fno-stack-protector -fno-pie -c minios.c -o minios.o
 *  翻译:  ./x86tos390x.py --obj minios.o --elf minios.s390x
 *  运行:  qemu-s390x minios.s390x ; echo "exit=$?"
 * ================================================================ */

/* ==================== 系统调用号 ==================== */
#define SYS_WRITE  1
#define SYS_EXIT   60
#define SYS_YIELD  100   /* 自定义: 主动让出 CPU */
#define SYS_ALLOC  101   /* 自定义: 分配内存 */
#define SYS_FREE   102   /* 自定义: 释放内存 */

/* ==================== 进程状态 ==================== */
#define PROC_DEAD   0
#define PROC_READY  1
#define PROC_RUNNING 2
#define PROC_BLOCKED 3

#define MAX_PROCS   8
#define STACK_SIZE  256
#define HEAP_SIZE   4096

/* ==================== 全局内核数据 ==================== */
static char kheap[HEAP_SIZE];           /* 内核堆 */
static char *heap_brk = kheap;          /* 堆顶指针 */
static int   proc_stack[MAX_PROCS][STACK_SIZE]; /* 进程栈 */

/* 进程控制块 */
static int  proc_pid   [MAX_PROCS];
static int  proc_state [MAX_PROCS];
static int  proc_pc    [MAX_PROCS];     /* 程序计数器(用函数编号模拟) */
static int  proc_regs  [MAX_PROCS][4];  /* 4 个通用寄存器 */
static int  proc_ticks [MAX_PROCS];     /* 已运行时间片 */

static int current_proc = -1;           /* 当前运行进程 */
static int total_ticks = 0;             /* 全局时钟滴答 */
static int next_pid = 1;                /* 下一个 PID */

/* 空闲链表节点 */
struct free_node {
    int size;              /* 块大小 */
    struct free_node *next; /* 下一块 */
};
static struct free_node *free_list = 0;

/* ==================== 系统调用: write ==================== */
static long sys_write(int fd, const char *buf, unsigned long len) {
    long ret;
    register long rdi __asm__("rdi") = fd;
    register long rsi __asm__("rsi") = (long)buf;
    register long rdx __asm__("rdx") = (long)len;
    __asm__ volatile("syscall"
                     : "=a"(ret)
                     : "0"(1L), "r"(rdi), "r"(rsi), "r"(rdx)
                     : "rcx", "r11", "memory");
    return ret;
}

/* ==================== 系统调用: exit ==================== */
static long sys_exit(int code) {
    long ret;
    __asm__ volatile("syscall"
                     : "=a"(ret)
                     : "0"(60L), "D"((long)code)
                     : "rcx", "r11", "memory");
    return ret;
}

/* ==================== 简易 print 函数 ==================== */
static void kprint(const char *s) {
    int len = 0;
    while (s[len]) len++;
    sys_write(1, s, len);
}

static void kprint_int(int n) {
    char buf[16];
    int i = 14;
    int neg = 0;
    buf[15] = 0;
    if (n < 0) { neg = 1; n = -n; }
    if (n == 0) { buf[i--] = '0'; }
    while (n > 0) {
        buf[i--] = '0' + (n % 10);
        n /= 10;
    }
    if (neg) buf[i--] = '-';
    sys_write(1, buf + i + 1, 15 - i - 1);
}

static void kprint_hex(int n) {
    char buf[16];
    char hex[] = "0123456789ABCDEF";
    int i;
    for (i = 0; i < 8; i++) {
        buf[7 - i] = hex[n & 0xF];
        n >>= 4;
    }
    buf[8] = 0;
    kprint("0x");
    sys_write(1, buf, 8);
}

/* ==================== 内存分配器 ==================== */
static void *kalloc(int size) {
    struct free_node *prev = 0;
    struct free_node *cur = free_list;

    /* 对齐到 8 字节 */
    size = (size + 7) & ~7;
    if (size < 16) size = 16;

    /* 遍历空闲链表找合适块 */
    while (cur) {
        if (cur->size >= size) {
            /* 找到: 从链表移除 */
            if (prev) {
                prev->next = cur->next;
            } else {
                free_list = cur->next;
            }
            return (void *)(cur + 1);
        }
        prev = cur;
        cur = cur->next;
    }

    /* 没有合适空闲块: 从堆顶分配 */
    if ((char *)(heap_brk + size + 8) > kheap + HEAP_SIZE) {
        return 0;  /* OOM */
    }
    char *p = heap_brk;
    heap_brk += size + 8;
    *(int *)p = size;
    return p + 8;
}

static void kfree(void *ptr) {
    if (!ptr) return;
    struct free_node *node = (struct free_node *)((char *)ptr - 8);
    node->size = *(int *)((char *)ptr - 8);
    node->next = free_list;
    free_list = node;
}

/* ==================== 进程管理 ==================== */
static int proc_create(int entry_func) {
    int i;
    for (i = 0; i < MAX_PROCS; i++) {
        if (proc_state[i] == PROC_DEAD) {
            proc_pid[i]    = next_pid++;
            proc_state[i]  = PROC_READY;
            proc_pc[i]     = 0;
            proc_regs[i][0] = entry_func;  /* r0: 入口函数编号 */
            proc_regs[i][1] = 0;
            proc_regs[i][2] = 0;
            proc_regs[i][3] = 0;
            proc_ticks[i]  = 0;
            return proc_pid[i];
        }
    }
    return -1;
}

/* 轮转调度: 找下一个就绪进程 */
static int sched_next(void) {
    int start = (current_proc + 1) % MAX_PROCS;
    int i = start;
    do {
        if (proc_state[i] == PROC_READY) return i;
        i = (i + 1) % MAX_PROCS;
    } while (i != start);
    return -1;
}

/* 上下文切换 */
static void sched_switch(int next) {
    if (current_proc >= 0 && proc_state[current_proc] == PROC_RUNNING) {
        proc_state[current_proc] = PROC_READY;
    }
    current_proc = next;
    if (next >= 0) {
        proc_state[next] = PROC_RUNNING;
    }
}

/* ==================== 用户程序 ==================== */
/* 每个用户程序是一个函数，由调度器调用。
 * 返回 0 表示完成，返回 1 表示还需要继续运行。 */

#define USER_PROG_FIB   0   /* 计算斐波那契数列 */
#define USER_PROG_PRIME 1   /* 计算素数 */
#define USER_PROG_SUM   2   /* 累加计算 */

static int fib_n = 0, fib_a = 0, fib_b = 1, fib_result = 0;
static int fib_step = 0;

static int user_fibonacci(void) {
    /* 状态机: 每 tick 算一步 */
    if (fib_step == 0) {
        fib_n = 0; fib_a = 0; fib_b = 1; fib_step = 1;
        return 1;
    }
    if (fib_n < 12) {
        fib_result = fib_a;
        int next = fib_a + fib_b;
        fib_a = fib_b;
        fib_b = next;
        fib_n++;
        return 1;  /* 继续 */
    }
    return 0;  /* 完成 */
}

static int prime_n = 2, prime_count = 0, prime_found = 0;

static int user_prime(void) {
    if (prime_count >= 8) return 0;  /* 找 8 个素数 */

    int is_prime = 1;
    int d;
    for (d = 2; d * d <= prime_n; d++) {
        if (prime_n % d == 0) { is_prime = 0; break; }
    }
    if (is_prime) {
        prime_found = prime_n;
        prime_count++;
    }
    prime_n++;
    return 1;
}

static int sum_n = 1, sum_acc = 0, sum_result = 0;

static int user_sum(void) {
    if (sum_n > 20) return 0;
    sum_acc += sum_n;
    sum_result = sum_acc;
    sum_n++;
    return 1;
}

/* 用户程序跳转表 */
typedef int (*user_func)(void);
static user_func user_progs[] = {
    user_fibonacci,
    user_prime,
    user_sum,
};

/* ==================== 内核主循环 ==================== */
static void kernel_banner(void) {
    kprint("\n");
    kprint("========================================\n");
    kprint("   miniOS Kernel v1.0  (x86->s390x)\n");
    kprint("   Pseudo Operating System Demo\n");
    kprint("========================================\n\n");
}

static void kernel_init(void) {
    kprint("[INIT] Booting miniOS kernel...\n");

    /* 创建 3 个用户进程 */
    int pid1 = proc_create(USER_PROG_FIB);
    int pid2 = proc_create(USER_PROG_PRIME);
    int pid3 = proc_create(USER_PROG_SUM);

    kprint("[INIT] Created processes: PID=");
    kprint_int(pid1);
    kprint(", PID=");
    kprint_int(pid2);
    kprint(", PID=");
    kprint_int(pid3);
    kprint("\n");

    /* 内存分配测试 */
    kprint("[INIT] Testing memory allocator...\n");
    int *p1 = (int *)kalloc(64);
    int *p2 = (int *)kalloc(128);
    if (p1) { *p1 = 0xDEADBEEF; }
    if (p2) { *p2 = 0xCAFEBABE; }
    kprint("[INIT] Allocated 64B at ");
    kprint_hex((long)p1);
    kprint(" = ");
    kprint_hex(p1 ? *p1 : 0);
    kprint("\n");
    kprint("[INIT] Allocated 128B at ");
    kprint_hex((long)p2);
    kprint(" = ");
    kprint_hex(p2 ? *p2 : 0);
    kprint("\n");

    kfree(p1);
    kprint("[INIT] Freed 64B block\n");
    int *p3 = kalloc(32);
    kprint("[INIT] Re-allocated 32B at ");
    kprint_hex((long)p3);
    kprint(" (should reuse freed block)\n");
    kfree(p2);
    kfree(p3);

    kprint("\n");
}

static void kernel_shell(void) {
    kprint("[SHELL] Starting scheduler (round-robin, 5 ticks/proc)...\n\n");

    int running = 3;  /* 3 个活跃进程 */
    int tick = 0;

    while (running > 0) {
        int next = sched_next();
        if (next < 0) break;

        sched_switch(next);
        int pid = proc_pid[next];
        int ptype = proc_regs[next][0];  /* 进程类型 */

        proc_ticks[next]++;
        total_ticks++;

        /* 调用用户程序 */
        int ret = user_progs[ptype]();

        if (ret == 0) {
            /* 进程完成 */
            kprint("[TICK ");
            kprint_int(tick);
            kprint("] PID=");
            kprint_int(pid);
            kprint(" (");

            if (ptype == USER_PROG_FIB) {
                kprint("Fibonacci");
            } else if (ptype == USER_PROG_PRIME) {
                kprint("Prime");
            } else {
                kprint("Sum");
            }
            kprint(") FINISHED. ");

            if (ptype == USER_PROG_FIB) {
                kprint("Fib(12)=");
                kprint_int(fib_result);
            } else if (ptype == USER_PROG_PRIME) {
                kprint("last prime=");
                kprint_int(prime_found);
            } else {
                kprint("sum(1..20)=");
                kprint_int(sum_result);
            }
            kprint("\n");

            proc_state[next] = PROC_DEAD;
            running--;
        } else {
            /* 进程未完成，设回 READY 以便下次调度 */
            proc_state[next] = PROC_READY;
        }

        tick++;
        if (tick >= 5) {
            tick = 0;
        }
    }

    kprint("\n");
}

static void kernel_report(void) {
    kprint("========================================\n");
    kprint("   miniOS Kernel Report\n");
    kprint("========================================\n");

    kprint("  Total ticks:     ");
    kprint_int(total_ticks);
    kprint("\n");

    kprint("  Fibonacci:       Fib(12)=");
    kprint_int(fib_result);
    kprint("\n");

    kprint("  Prime search:    ");
    kprint_int(prime_count);
    kprint(" primes found, last=");
    kprint_int(prime_found);
    kprint("\n");

    kprint("  Sum 1..20:       ");
    kprint_int(sum_result);
    kprint("\n");

    kprint("  Heap used:       ");
    kprint_int((int)(heap_brk - kheap));
    kprint(" / ");
    kprint_int(HEAP_SIZE);
    kprint(" bytes\n");

    kprint("  Processes:       3 created, 3 completed\n");
    kprint("========================================\n\n");
    kprint("[KERNEL] System halted. Goodbye.\n\n");
}

/* ====================  main ==================== */
int main(void) {
    kernel_banner();
    kernel_init();
    kernel_shell();
    kernel_report();

    /* 计算退出码: fib(11) + prime_count + sum(1..20) 的低 8 位
     * fib(11)=89, prime_count=8, sum=210 => 89+8+210=307, &0xff=51 */
    int exit_code = (fib_result + prime_count + sum_result) & 0xff;
    return exit_code;
}