
	.text
	.globl _start
_start:
	# 建栈帧（s390x ABI 要求 r15 对齐 8，且被调用方需 160 字节保存区）
	aghi	%r15,-160
	# main() 返回 int 在 r2；掩到 8 位作退出码
	brasl	%r14,main
	nill	%r2,255
	# exit(r2)：调用号 1 放 r1，参数（退出码）留在 r2
	lghi	%r1,1
	svc	0

	.globl	kprint
	.type	kprint,@function
kprint:
L0:
# x86 @0x0: 48 89 fe
	lgr	%r3,%r2
L3:
# x86 @0x3: 80 3f 00
	llgc	%r1,0(%r2)
	cfi	%r1,0
L6:
# x86 @0x6: 74 23
	je	L2b
L8:
# x86 @0x8: b8 01 00 00 00
	lghi	%r0,1
Ld:
# x86 @0xd: 48 89 c2
	lgr	%r4,%r0
L10:
# x86 @0x10: 48 83 c0 01
	aghi	%r0,1
L14:
# x86 @0x14: 80 7c 06 ff 00
	lgr	%r1,%r0
	lay	%r1,-1(%r3,%r1)
	llgc	%r1,0(%r1)
	cfi	%r1,0
L19:
# x86 @0x19: 75 f2
	jne	Ld
L1b:
# x86 @0x1b: bf 01 00 00 00
	lghi	%r2,1
L20:
# x86 @0x20: 48 63 d2
	lgfr	%r4,%r4
L23:
# x86 @0x23: b8 01 00 00 00
	lghi	%r0,1
L28:
# x86 @0x28: 0f 05
# syscall: 映射 x86 系统调用号 (r0) -> s390x (r1)
	chi	%r0,1
	jne	.Lsc1_28
	lghi	%r1,4
	j	.Lsc_done_28
.Lsc1_28:
	chi	%r0,60
	jne	.Lsc2_28
	lghi	%r1,1
	j	.Lsc_done_28
.Lsc2_28:
	chi	%r0,231
	jne	.Lsc3_28
	lghi	%r1,1
	j	.Lsc_done_28
.Lsc3_28:
	chi	%r0,0
	jne	.Lsc4_28
	lghi	%r1,3
	j	.Lsc_done_28
.Lsc4_28:
	chi	%r0,2
	jne	.Lsc5_28
	lghi	%r1,5
	j	.Lsc_done_28
.Lsc5_28:
	chi	%r0,3
	jne	.Lsc6_28
	lghi	%r1,6
	j	.Lsc_done_28
.Lsc6_28:
	chi	%r0,9
	jne	.Lsc7_28
	lghi	%r1,90
	j	.Lsc_done_28
.Lsc7_28:
	chi	%r0,12
	jne	.Lsc8_28
	lghi	%r1,45
	j	.Lsc_done_28
.Lsc8_28:
	chi	%r0,5
	jne	.Lsc9_28
	lghi	%r1,8
	j	.Lsc_done_28
.Lsc9_28:
	chi	%r0,8
	jne	.Lsc10_28
	lghi	%r1,19
	j	.Lsc_done_28
.Lsc10_28:
	chi	%r0,10
	jne	.Lsc11_28
	lghi	%r1,125
	j	.Lsc_done_28
.Lsc11_28:
	chi	%r0,11
	jne	.Lsc12_28
	lghi	%r1,91
	j	.Lsc_done_28
.Lsc12_28:
	lgr	%r1,%r0
.Lsc_done_28:
	svc	0
	lgr	%r0,%r2
L2a:
# x86 @0x2a: c3
	lgr	%r2,%r0
	br	%r14
L2b:
# x86 @0x2b: ba 00 00 00 00
	lghi	%r4,0
L30:
# x86 @0x30: eb e9
	j	L1b

	.globl	kalloc
	.type	kalloc,@function
kalloc:
L32:
# x86 @0x32: 48 8b 05 00 00 00 00
	larl	%r1,free_list
	lg	%r0,0(%r1)
L39:
# x86 @0x39: 83 c7 07
	ahi	%r2,7
L3c:
# x86 @0x3c: 83 e7 f8
	nilf	%r2,4294967288
L3f:
# x86 @0x3f: ba 10 00 00 00
	lghi	%r4,16
L44:
# x86 @0x44: 39 d7
	cr	%r2,%r4
L46:
# x86 @0x46: 0f 4c fa
	locgr	%r2,%r4,4
L49:
# x86 @0x49: 48 85 c0
	ltgr	%r1,%r0
L4c:
# x86 @0x4c: 74 1a
	je	L68
L4e:
# x86 @0x4e: b9 00 00 00 00
	lghi	%r5,0
L53:
# x86 @0x53: eb 03
	j	L58
L55:
# x86 @0x55: 48 89 d0
	lgr	%r0,%r4
L58:
# x86 @0x58: 39 38
	lgr	%r1,%r0
	l	%r13,0(%r1)
	cr	%r13,%r2
L5a:
# x86 @0x5a: 7d 32
	jnl	L8e
L5c:
# x86 @0x5c: 48 8b 50 08
	lgr	%r1,%r0
	lg	%r4,8(%r1)
L60:
# x86 @0x60: 48 89 c1
	lgr	%r5,%r0
L63:
# x86 @0x63: 48 85 d2
	ltgr	%r1,%r4
L66:
# x86 @0x66: 75 ed
	jne	L55
L68:
# x86 @0x68: 48 8b 05 00 00 00 00
	larl	%r1,heap_brk
	lg	%r0,0(%r1)
L6f:
# x86 @0x6f: 48 63 d7
	lgfr	%r4,%r2
L72:
# x86 @0x72: 48 8d 54 10 08
	lgr	%r1,%r0
	la	%r1,8(%r1,%r4)
	lgr	%r4,%r1
L77:
# x86 @0x77: 48 81 fa 00 00 00 00
	larl	%r1,kheap
	aghi	%r1,4384
	cgr	%r4,%r1
L7e:
# x86 @0x7e: 77 2d
	jh	Lad
L80:
# x86 @0x80: 48 89 15 00 00 00 00
	larl	%r1,heap_brk
	stg	%r4,0(%r1)
L87:
# x86 @0x87: 89 38
	lgr	%r1,%r0
	st	%r2,0(%r1)
L89:
# x86 @0x89: 48 83 c0 08
	aghi	%r0,8
L8d:
# x86 @0x8d: c3
	lgr	%r2,%r0
	br	%r14
L8e:
# x86 @0x8e: 48 85 c9
	ltgr	%r1,%r5
L91:
# x86 @0x91: 74 0d
	je	La0
L93:
# x86 @0x93: 48 8b 50 08
	lgr	%r1,%r0
	lg	%r4,8(%r1)
L97:
# x86 @0x97: 48 89 51 08
	stg	%r4,8(%r5)
L9b:
# x86 @0x9b: 48 83 c0 10
	aghi	%r0,16
L9f:
# x86 @0x9f: c3
	lgr	%r2,%r0
	br	%r14
La0:
# x86 @0xa0: 48 8b 50 08
	lgr	%r1,%r0
	lg	%r4,8(%r1)
La4:
# x86 @0xa4: 48 89 15 00 00 00 00
	larl	%r1,free_list
	stg	%r4,0(%r1)
Lab:
# x86 @0xab: eb ee
	j	L9b
Lad:
# x86 @0xad: b8 00 00 00 00
	lghi	%r0,0
Lb2:
# x86 @0xb2: c3
	lgr	%r2,%r0
	br	%r14

	.globl	kfree
	.type	kfree,@function
kfree:
Lb3:
# x86 @0xb3: 48 85 ff
	ltgr	%r1,%r2
Lb6:
# x86 @0xb6: 74 15
	je	Lcd
Lb8:
# x86 @0xb8: 48 8b 05 00 00 00 00
	larl	%r1,free_list
	lg	%r0,0(%r1)
Lbf:
# x86 @0xbf: 48 89 07
	stg	%r0,0(%r2)
Lc2:
# x86 @0xc2: 48 83 ef 08
	aghi	%r2,-8
Lc6:
# x86 @0xc6: 48 89 3d 00 00 00 00
	larl	%r1,free_list
	stg	%r2,0(%r1)
Lcd:
# x86 @0xcd: c3
	lgr	%r2,%r0
	br	%r14

	.globl	proc_create
	.type	proc_create,@function
proc_create:
Lce:
# x86 @0xce: b8 00 00 00 00
	lghi	%r0,0
Ld3:
# x86 @0xd3: 83 3c 85 00 00 00 00 00
	lgr	%r1,%r0
	sllg	%r1,%r1,2
	aghi	%r15,-8
	stg	%r0,0(%r15)
	larl	%r0,proc_state
	algr	%r1,%r0
	lg	%r0,0(%r15)
	aghi	%r15,8
	l	%r1,0(%r1)
	cfi	%r1,0
Ldb:
# x86 @0xdb: 74 12
	je	Lef
Ldd:
# x86 @0xdd: 48 83 c0 01
	aghi	%r0,1
Le1:
# x86 @0xe1: 48 83 f8 08
	cgfi	%r0,8
Le5:
# x86 @0xe5: 75 ec
	jne	Ld3
Le7:
# x86 @0xe7: ba ff ff ff ff
	llilf	%r4,4294967295
Lec:
# x86 @0xec: 89 d0
	lgr	%r0,%r4
Lee:
# x86 @0xee: c3
	lgr	%r2,%r0
	br	%r14
Lef:
# x86 @0xef: 8b 15 00 00 00 00
	larl	%r1,next_pid
	l	%r4,0(%r1)
Lf5:
# x86 @0xf5: 8d 4a 01
	la	%r5,1(%r4)
Lf8:
# x86 @0xf8: 89 0d 00 00 00 00
	larl	%r1,next_pid
	st	%r5,0(%r1)
Lfe:
# x86 @0xfe: 48 98
	lgfr	%r0,%r0
L100:
# x86 @0x100: 89 14 85 00 00 00 00
	lgr	%r1,%r0
	sllg	%r1,%r1,2
	aghi	%r15,-8
	stg	%r0,0(%r15)
	larl	%r0,proc_pid
	algr	%r1,%r0
	lg	%r0,0(%r15)
	aghi	%r15,8
	st	%r4,0(%r1)
L107:
# x86 @0x107: c7 04 85 00 00 00 00 01 00 00 00
	lgr	%r1,%r0
	sllg	%r1,%r1,2
	aghi	%r15,-8
	stg	%r0,0(%r15)
	lghi	%r13,1
	aghi	%r15,-8
	stg	%r0,0(%r15)
	larl	%r0,proc_state
	algr	%r1,%r0
	lg	%r0,0(%r15)
	aghi	%r15,8
	st	%r13,0(%r1)
	lg	%r0,0(%r15)
	aghi	%r15,8
L112:
# x86 @0x112: 48 89 c6
	lgr	%r3,%r0
L115:
# x86 @0x115: 48 c1 e6 04
	sllg	%r3,%r3,4
L119:
# x86 @0x119: 89 be 00 00 00 00
	aghi	%r15,-8
	stg	%r0,0(%r15)
	larl	%r0,proc_regs
	lgr	%r1,%r3
	algr	%r1,%r0
	lg	%r0,0(%r15)
	aghi	%r15,8
	st	%r2,0(%r1)
L11f:
# x86 @0x11f: c7 86 00 00 00 00 00 00 00 00
	aghi	%r15,-8
	stg	%r0,0(%r15)
	lghi	%r13,0
	aghi	%r15,-8
	stg	%r0,0(%r15)
	larl	%r0,proc_regs
	lgr	%r1,%r3
	algr	%r1,%r0
	aghi	%r1,4
	lg	%r0,0(%r15)
	aghi	%r15,8
	st	%r13,0(%r1)
	lg	%r0,0(%r15)
	aghi	%r15,8
L129:
# x86 @0x129: c7 86 00 00 00 00 00 00 00 00
	aghi	%r15,-8
	stg	%r0,0(%r15)
	lghi	%r13,0
	aghi	%r15,-8
	stg	%r0,0(%r15)
	larl	%r0,proc_regs
	lgr	%r1,%r3
	algr	%r1,%r0
	aghi	%r1,8
	lg	%r0,0(%r15)
	aghi	%r15,8
	st	%r13,0(%r1)
	lg	%r0,0(%r15)
	aghi	%r15,8
L133:
# x86 @0x133: c7 86 00 00 00 00 00 00 00 00
	aghi	%r15,-8
	stg	%r0,0(%r15)
	lghi	%r13,0
	aghi	%r15,-8
	stg	%r0,0(%r15)
	larl	%r0,proc_regs
	lgr	%r1,%r3
	algr	%r1,%r0
	aghi	%r1,12
	lg	%r0,0(%r15)
	aghi	%r15,8
	st	%r13,0(%r1)
	lg	%r0,0(%r15)
	aghi	%r15,8
L13d:
# x86 @0x13d: c7 04 85 00 00 00 00 00 00 00 00
	lgr	%r1,%r0
	sllg	%r1,%r1,2
	aghi	%r15,-8
	stg	%r0,0(%r15)
	lghi	%r13,0
	aghi	%r15,-8
	stg	%r0,0(%r15)
	larl	%r0,proc_ticks
	algr	%r1,%r0
	lg	%r0,0(%r15)
	aghi	%r15,8
	st	%r13,0(%r1)
	lg	%r0,0(%r15)
	aghi	%r15,8
L148:
# x86 @0x148: eb a2
	j	Lec

	.globl	user_fibonacci
	.type	user_fibonacci,@function
user_fibonacci:
L14a:
# x86 @0x14a: f3 0f 1e fa
L14e:
# x86 @0x14e: 83 3d 00 00 00 00 00
	larl	%r1,fib_step
	l	%r1,0(%r1)
	cfi	%r1,0
L155:
# x86 @0x155: 74 11
	je	L168
L157:
# x86 @0x157: 8b 15 00 00 00 00
	larl	%r1,fib_n
	l	%r4,0(%r1)
L15d:
# x86 @0x15d: b8 00 00 00 00
	lghi	%r0,0
L162:
# x86 @0x162: 83 fa 0b
	cfi	%r4,11
L165:
# x86 @0x165: 7e 2f
	jle	L196
L167:
# x86 @0x167: c3
	lgr	%r2,%r0
	br	%r14
L168:
# x86 @0x168: c7 05 00 00 00 00 00 00 00 00
	lghi	%r13,0
	larl	%r1,fib_n
	st	%r13,0(%r1)
L172:
# x86 @0x172: c7 05 00 00 00 00 00 00 00 00
	lghi	%r13,0
	larl	%r1,fib_a
	st	%r13,0(%r1)
L17c:
# x86 @0x17c: c7 05 00 00 00 00 01 00 00 00
	lghi	%r13,1
	larl	%r1,fib_b
	st	%r13,0(%r1)
L186:
# x86 @0x186: c7 05 00 00 00 00 01 00 00 00
	lghi	%r13,1
	larl	%r1,fib_step
	st	%r13,0(%r1)
L190:
# x86 @0x190: b8 01 00 00 00
	lghi	%r0,1
L195:
# x86 @0x195: c3
	lgr	%r2,%r0
	br	%r14
L196:
# x86 @0x196: 8b 05 00 00 00 00
	larl	%r1,fib_a
	l	%r0,0(%r1)
L19c:
# x86 @0x19c: 89 05 00 00 00 00
	larl	%r1,fib_result
	st	%r0,0(%r1)
L1a2:
# x86 @0x1a2: 8b 0d 00 00 00 00
	larl	%r1,fib_b
	l	%r5,0(%r1)
L1a8:
# x86 @0x1a8: 89 0d 00 00 00 00
	larl	%r1,fib_a
	st	%r5,0(%r1)
L1ae:
# x86 @0x1ae: 01 c8
	ar	%r0,%r5
L1b0:
# x86 @0x1b0: 89 05 00 00 00 00
	larl	%r1,fib_b
	st	%r0,0(%r1)
L1b6:
# x86 @0x1b6: 83 c2 01
	ahi	%r4,1
L1b9:
# x86 @0x1b9: 89 15 00 00 00 00
	larl	%r1,fib_n
	st	%r4,0(%r1)
L1bf:
# x86 @0x1bf: b8 01 00 00 00
	lghi	%r0,1
L1c4:
# x86 @0x1c4: c3
	lgr	%r2,%r0
	br	%r14

	.globl	user_prime
	.type	user_prime,@function
user_prime:
L1c5:
# x86 @0x1c5: f3 0f 1e fa
L1c9:
# x86 @0x1c9: 8b 3d 00 00 00 00
	larl	%r1,prime_count
	l	%r2,0(%r1)
L1cf:
# x86 @0x1cf: b8 00 00 00 00
	lghi	%r0,0
L1d4:
# x86 @0x1d4: 83 ff 07
	cfi	%r2,7
L1d7:
# x86 @0x1d7: 7f 4a
	jh	L223
L1d9:
# x86 @0x1d9: 8b 35 00 00 00 00
	larl	%r1,prime_n
	l	%r3,0(%r1)
L1df:
# x86 @0x1df: 83 fe 03
	cfi	%r3,3
L1e2:
# x86 @0x1e2: 7e 22
	jle	L206
L1e4:
# x86 @0x1e4: 40 f6 c6 01
	lgr	%r1,%r3
	nill	%r1,1
	ltr	%r1,%r1
L1e8:
# x86 @0x1e8: 74 2b
	je	L215
L1ea:
# x86 @0x1ea: b9 02 00 00 00
	lghi	%r5,2
L1ef:
# x86 @0x1ef: 83 c1 01
	ahi	%r5,1
L1f2:
# x86 @0x1f2: 89 c8
	lgr	%r0,%r5
L1f4:
# x86 @0x1f4: 0f af c1
	msr	%r0,%r5
L1f7:
# x86 @0x1f7: 39 f0
	cr	%r0,%r3
L1f9:
# x86 @0x1f9: 7f 0b
	jh	L206
L1fb:
# x86 @0x1fb: 89 f0
	lgr	%r0,%r3
L1fd:
# x86 @0x1fd: 99
	lgfr	%r4,%r0
	srag	%r4,%r4,32
L1fe:
# x86 @0x1fe: f7 f9
	sllg	%r4,%r4,32
	sllg	%r1,%r0,32
	srlg	%r1,%r1,32
	lgr	%r0,%r4
	ogr	%r0,%r1
	dsgfr	%r0,%r5
	lgr	%r4,%r0
	lgr	%r0,%r1
L200:
# x86 @0x200: 85 d2
	ltr	%r1,%r4
L202:
# x86 @0x202: 75 eb
	jne	L1ef
L204:
# x86 @0x204: eb 0f
	j	L215
L206:
# x86 @0x206: 89 35 00 00 00 00
	larl	%r1,prime_found
	st	%r3,0(%r1)
L20c:
# x86 @0x20c: 83 c7 01
	ahi	%r2,1
L20f:
# x86 @0x20f: 89 3d 00 00 00 00
	larl	%r1,prime_count
	st	%r2,0(%r1)
L215:
# x86 @0x215: 83 c6 01
	ahi	%r3,1
L218:
# x86 @0x218: 89 35 00 00 00 00
	larl	%r1,prime_n
	st	%r3,0(%r1)
L21e:
# x86 @0x21e: b8 01 00 00 00
	lghi	%r0,1
L223:
# x86 @0x223: c3
	lgr	%r2,%r0
	br	%r14

	.globl	user_sum
	.type	user_sum,@function
user_sum:
L224:
# x86 @0x224: f3 0f 1e fa
L228:
# x86 @0x228: 8b 05 00 00 00 00
	larl	%r1,sum_n
	l	%r0,0(%r1)
L22e:
# x86 @0x22e: ba 00 00 00 00
	lghi	%r4,0
L233:
# x86 @0x233: 83 f8 14
	cfi	%r0,20
L236:
# x86 @0x236: 7f 22
	jh	L25a
L238:
# x86 @0x238: 89 c2
	lgr	%r4,%r0
L23a:
# x86 @0x23a: 03 15 00 00 00 00
	larl	%r1,sum_acc
	l	%r1,0(%r1)
	ar	%r4,%r1
L240:
# x86 @0x240: 89 15 00 00 00 00
	larl	%r1,sum_acc
	st	%r4,0(%r1)
L246:
# x86 @0x246: 89 15 00 00 00 00
	larl	%r1,sum_result
	st	%r4,0(%r1)
L24c:
# x86 @0x24c: 83 c0 01
	ahi	%r0,1
L24f:
# x86 @0x24f: 89 05 00 00 00 00
	larl	%r1,sum_n
	st	%r0,0(%r1)
L255:
# x86 @0x255: ba 01 00 00 00
	lghi	%r4,1
L25a:
# x86 @0x25a: 89 d0
	lgr	%r0,%r4
L25c:
# x86 @0x25c: c3
	lgr	%r2,%r0
	br	%r14

	.globl	kprint_hex
	.type	kprint_hex,@function
kprint_hex:
L25d:
# x86 @0x25d: 48 83 ec 38
	aghi	%r15,-56
L261:
# x86 @0x261: 48 b8 30 31 32 33 34 35 36 37
	llihf	%r0,808530483
	oilf	%r0,875902519
L26b:
# x86 @0x26b: 48 ba 38 39 41 42 43 44 45 46
	llihf	%r4,943276354
	oilf	%r4,1128547654
L275:
# x86 @0x275: 48 89 04 24
	stg	%r0,0(%r15)
L279:
# x86 @0x279: 48 89 54 24 08
	stg	%r4,8(%r15)
L27e:
# x86 @0x27e: c6 44 24 10 00
	lghi	%r13,0
	stc	%r13,16(%r15)
L283:
# x86 @0x283: 48 8d 4c 24 20
	la	%r5,32(%r15)
L288:
# x86 @0x288: 48 8d 44 24 27
	la	%r0,39(%r15)
L28d:
# x86 @0x28d: 89 fa
	lgr	%r4,%r2
L28f:
# x86 @0x28f: 83 e2 0f
	nilf	%r4,15
L292:
# x86 @0x292: 0f b6 14 14
	la	%r1,0(%r15,%r4)
	llgc	%r4,0(%r1)
L296:
# x86 @0x296: 88 10
	lgr	%r1,%r0
	stc	%r4,0(%r1)
L298:
# x86 @0x298: c1 ff 04
	sra	%r2,4
L29b:
# x86 @0x29b: 48 89 c2
	lgr	%r4,%r0
L29e:
# x86 @0x29e: 48 83 e8 01
	aghi	%r0,-1
L2a2:
# x86 @0x2a2: 48 39 ca
	cgr	%r4,%r5
L2a5:
# x86 @0x2a5: 75 e6
	jne	L28d
L2a7:
# x86 @0x2a7: c6 44 24 28 00
	lghi	%r13,0
	stc	%r13,40(%r15)
L2ac:
# x86 @0x2ac: bf 00 00 00 00
	larl	%r2,__sec__rodata_str1_1
L2b1:
# x86 @0x2b1: e8 4a fd ff ff
	aghi	%r15,-160
	stg	%r14,0(%r15)
	brasl	%r14,kprint
	lg	%r14,0(%r15)
	aghi	%r15,160
	lgr	%r0,%r2
L2b6:
# x86 @0x2b6: bf 01 00 00 00
	lghi	%r2,1
L2bb:
# x86 @0x2bb: 48 8d 74 24 20
	la	%r3,32(%r15)
L2c0:
# x86 @0x2c0: ba 08 00 00 00
	lghi	%r4,8
L2c5:
# x86 @0x2c5: b8 01 00 00 00
	lghi	%r0,1
L2ca:
# x86 @0x2ca: 0f 05
# syscall: 映射 x86 系统调用号 (r0) -> s390x (r1)
	chi	%r0,1
	jne	.Lsc1_2ca
	lghi	%r1,4
	j	.Lsc_done_2ca
.Lsc1_2ca:
	chi	%r0,60
	jne	.Lsc2_2ca
	lghi	%r1,1
	j	.Lsc_done_2ca
.Lsc2_2ca:
	chi	%r0,231
	jne	.Lsc3_2ca
	lghi	%r1,1
	j	.Lsc_done_2ca
.Lsc3_2ca:
	chi	%r0,0
	jne	.Lsc4_2ca
	lghi	%r1,3
	j	.Lsc_done_2ca
.Lsc4_2ca:
	chi	%r0,2
	jne	.Lsc5_2ca
	lghi	%r1,5
	j	.Lsc_done_2ca
.Lsc5_2ca:
	chi	%r0,3
	jne	.Lsc6_2ca
	lghi	%r1,6
	j	.Lsc_done_2ca
.Lsc6_2ca:
	chi	%r0,9
	jne	.Lsc7_2ca
	lghi	%r1,90
	j	.Lsc_done_2ca
.Lsc7_2ca:
	chi	%r0,12
	jne	.Lsc8_2ca
	lghi	%r1,45
	j	.Lsc_done_2ca
.Lsc8_2ca:
	chi	%r0,5
	jne	.Lsc9_2ca
	lghi	%r1,8
	j	.Lsc_done_2ca
.Lsc9_2ca:
	chi	%r0,8
	jne	.Lsc10_2ca
	lghi	%r1,19
	j	.Lsc_done_2ca
.Lsc10_2ca:
	chi	%r0,10
	jne	.Lsc11_2ca
	lghi	%r1,125
	j	.Lsc_done_2ca
.Lsc11_2ca:
	chi	%r0,11
	jne	.Lsc12_2ca
	lghi	%r1,91
	j	.Lsc_done_2ca
.Lsc12_2ca:
	lgr	%r1,%r0
.Lsc_done_2ca:
	svc	0
	lgr	%r0,%r2
L2cc:
# x86 @0x2cc: 48 83 c4 38
	aghi	%r15,56
L2d0:
# x86 @0x2d0: c3
	lgr	%r2,%r0
	br	%r14

	.globl	kprint_int
	.type	kprint_int,@function
kprint_int:
L2d1:
# x86 @0x2d1: c6 44 24 f7 00
	lghi	%r13,0
	lay	%r1,-9(%r15)
	stc	%r13,0(%r1)
L2d6:
# x86 @0x2d6: 85 ff
	ltr	%r1,%r2
L2d8:
# x86 @0x2d8: 78 2e
	jl	L308
L2da:
# x86 @0x2da: 75 7f
	jne	L35b
L2dc:
# x86 @0x2dc: c6 44 24 f6 30
	lghi	%r13,48
	lay	%r1,-10(%r15)
	stc	%r13,0(%r1)
L2e1:
# x86 @0x2e1: b9 0d 00 00 00
	lghi	%r5,13
L2e6:
# x86 @0x2e6: ba 0e 00 00 00
	lghi	%r4,14
L2eb:
# x86 @0x2eb: 29 ca
	sr	%r4,%r5
L2ed:
# x86 @0x2ed: 83 c1 01
	ahi	%r5,1
L2f0:
# x86 @0x2f0: 48 63 c9
	lgfr	%r5,%r5
L2f3:
# x86 @0x2f3: 48 8d 74 0c e8
	lay	%r1,-24(%r15,%r5)
	lgr	%r3,%r1
L2f8:
# x86 @0x2f8: bf 01 00 00 00
	lghi	%r2,1
L2fd:
# x86 @0x2fd: 48 63 d2
	lgfr	%r4,%r4
L300:
# x86 @0x300: b8 01 00 00 00
	lghi	%r0,1
L305:
# x86 @0x305: 0f 05
# syscall: 映射 x86 系统调用号 (r0) -> s390x (r1)
	chi	%r0,1
	jne	.Lsc1_305
	lghi	%r1,4
	j	.Lsc_done_305
.Lsc1_305:
	chi	%r0,60
	jne	.Lsc2_305
	lghi	%r1,1
	j	.Lsc_done_305
.Lsc2_305:
	chi	%r0,231
	jne	.Lsc3_305
	lghi	%r1,1
	j	.Lsc_done_305
.Lsc3_305:
	chi	%r0,0
	jne	.Lsc4_305
	lghi	%r1,3
	j	.Lsc_done_305
.Lsc4_305:
	chi	%r0,2
	jne	.Lsc5_305
	lghi	%r1,5
	j	.Lsc_done_305
.Lsc5_305:
	chi	%r0,3
	jne	.Lsc6_305
	lghi	%r1,6
	j	.Lsc_done_305
.Lsc6_305:
	chi	%r0,9
	jne	.Lsc7_305
	lghi	%r1,90
	j	.Lsc_done_305
.Lsc7_305:
	chi	%r0,12
	jne	.Lsc8_305
	lghi	%r1,45
	j	.Lsc_done_305
.Lsc8_305:
	chi	%r0,5
	jne	.Lsc9_305
	lghi	%r1,8
	j	.Lsc_done_305
.Lsc9_305:
	chi	%r0,8
	jne	.Lsc10_305
	lghi	%r1,19
	j	.Lsc_done_305
.Lsc10_305:
	chi	%r0,10
	jne	.Lsc11_305
	lghi	%r1,125
	j	.Lsc_done_305
.Lsc11_305:
	chi	%r0,11
	jne	.Lsc12_305
	lghi	%r1,91
	j	.Lsc_done_305
.Lsc12_305:
	lgr	%r1,%r0
.Lsc_done_305:
	svc	0
	lgr	%r0,%r2
L307:
# x86 @0x307: c3
	lgr	%r2,%r0
	br	%r14
L308:
# x86 @0x308: f7 df
	lcgr	%r2,%r2
L30a:
# x86 @0x30a: 41 b8 01 00 00 00
	lghi	%r6,1
L310:
# x86 @0x310: ba 0d 00 00 00
	lghi	%r4,13
L315:
# x86 @0x315: 48 63 c7
	lgfr	%r0,%r2
L318:
# x86 @0x318: 48 69 c0 67 66 66 66
	lgr	%r0,%r0
	msgfi	%r0,1717986919
L31f:
# x86 @0x31f: 48 c1 f8 22
	srag	%r0,%r0,34
L323:
# x86 @0x323: 89 f9
	lgr	%r5,%r2
L325:
# x86 @0x325: c1 f9 1f
	sra	%r5,31
L328:
# x86 @0x328: 29 c8
	sr	%r0,%r5
L32a:
# x86 @0x32a: 8d 34 80
	lgr	%r1,%r0
	sllg	%r1,%r1,2
	agr	%r1,%r0
	lgr	%r3,%r1
L32d:
# x86 @0x32d: 01 f6
	ar	%r3,%r3
L32f:
# x86 @0x32f: 89 f9
	lgr	%r5,%r2
L331:
# x86 @0x331: 29 f1
	sr	%r5,%r3
L333:
# x86 @0x333: 83 c1 30
	ahi	%r5,48
L336:
# x86 @0x336: 88 4c 14 e9
	lay	%r1,-23(%r15,%r4)
	stc	%r5,0(%r1)
L33a:
# x86 @0x33a: 89 f9
	lgr	%r5,%r2
L33c:
# x86 @0x33c: 89 c7
	lgr	%r2,%r0
L33e:
# x86 @0x33e: 48 89 d0
	lgr	%r0,%r4
L341:
# x86 @0x341: 48 83 ea 01
	aghi	%r4,-1
L345:
# x86 @0x345: 83 f9 09
	cfi	%r5,9
L348:
# x86 @0x348: 7f cb
	jh	L315
L34a:
# x86 @0x34a: 45 85 c0
	ltr	%r1,%r6
L34d:
# x86 @0x34d: 74 14
	je	L363
L34f:
# x86 @0x34f: 8d 48 ff
	lgr	%r1,%r0
	lay	%r5,-1(%r1)
L352:
# x86 @0x352: 48 98
	lgfr	%r0,%r0
L354:
# x86 @0x354: c6 44 04 e8 2d
	lgr	%r1,%r0
	lay	%r1,-24(%r15,%r1)
	lghi	%r13,45
	stc	%r13,0(%r1)
L359:
# x86 @0x359: eb 8b
	j	L2e6
L35b:
# x86 @0x35b: 41 b8 00 00 00 00
	lghi	%r6,0
L361:
# x86 @0x361: eb ad
	j	L310
L363:
# x86 @0x363: 89 c1
	lgr	%r5,%r0
L365:
# x86 @0x365: e9 7c ff ff ff
	j	L2e6

	.globl	main
	.type	main,@function
main:
L36a:
# x86 @0x36a: f3 0f 1e fa
L36e:
# x86 @0x36e: 41 57
	aghi	%r15,-8
	stg	%r14,0(%r15)
L370:
# x86 @0x370: 41 56
	aghi	%r15,-8
	stg	%r12,0(%r15)
L372:
# x86 @0x372: 41 55
	aghi	%r15,-8
	stg	%r11,0(%r15)
L374:
# x86 @0x374: 41 54
	aghi	%r15,-8
	stg	%r10,0(%r15)
L376:
# x86 @0x376: 55
	aghi	%r15,-8
	stg	%r9,0(%r15)
L377:
# x86 @0x377: 53
	aghi	%r15,-8
	stg	%r8,0(%r15)
L378:
# x86 @0x378: 48 83 ec 08
	aghi	%r15,-8
L37c:
# x86 @0x37c: bf 00 00 00 00
	larl	%r2,__sec__rodata_str1_1
	aghi	%r2,3
L381:
# x86 @0x381: e8 7a fc ff ff
	aghi	%r15,-160
	stg	%r14,0(%r15)
	brasl	%r14,kprint
	lg	%r14,0(%r15)
	aghi	%r15,160
	lgr	%r0,%r2
L386:
# x86 @0x386: bf 00 00 00 00
	larl	%r2,__sec__rodata_str1_8
L38b:
# x86 @0x38b: e8 70 fc ff ff
	aghi	%r15,-160
	stg	%r14,0(%r15)
	brasl	%r14,kprint
	lg	%r14,0(%r15)
	aghi	%r15,160
	lgr	%r0,%r2
L390:
# x86 @0x390: bf 00 00 00 00
	larl	%r2,__sec__rodata_str1_8
	aghi	%r2,48
L395:
# x86 @0x395: e8 66 fc ff ff
	aghi	%r15,-160
	stg	%r14,0(%r15)
	brasl	%r14,kprint
	lg	%r14,0(%r15)
	aghi	%r15,160
	lgr	%r0,%r2
L39a:
# x86 @0x39a: bf 00 00 00 00
	larl	%r2,__sec__rodata_str1_8
	aghi	%r2,88
L39f:
# x86 @0x39f: e8 5c fc ff ff
	aghi	%r15,-160
	stg	%r14,0(%r15)
	brasl	%r14,kprint
	lg	%r14,0(%r15)
	aghi	%r15,160
	lgr	%r0,%r2
L3a4:
# x86 @0x3a4: bf 00 00 00 00
	larl	%r2,__sec__rodata_str1_8
	aghi	%r2,128
L3a9:
# x86 @0x3a9: e8 52 fc ff ff
	aghi	%r15,-160
	stg	%r14,0(%r15)
	brasl	%r14,kprint
	lg	%r14,0(%r15)
	aghi	%r15,160
	lgr	%r0,%r2
L3ae:
# x86 @0x3ae: bf 00 00 00 00
	larl	%r2,__sec__rodata_str1_8
	aghi	%r2,176
L3b3:
# x86 @0x3b3: e8 48 fc ff ff
	aghi	%r15,-160
	stg	%r14,0(%r15)
	brasl	%r14,kprint
	lg	%r14,0(%r15)
	aghi	%r15,160
	lgr	%r0,%r2
L3b8:
# x86 @0x3b8: bf 00 00 00 00
	lghi	%r2,0
L3bd:
# x86 @0x3bd: e8 0c fd ff ff
	aghi	%r15,-160
	stg	%r14,0(%r15)
	brasl	%r14,proc_create
	lg	%r14,0(%r15)
	aghi	%r15,160
	lgr	%r0,%r2
L3c2:
# x86 @0x3c2: 41 89 c4
	lgr	%r10,%r0
L3c5:
# x86 @0x3c5: bf 01 00 00 00
	lghi	%r2,1
L3ca:
# x86 @0x3ca: e8 ff fc ff ff
	aghi	%r15,-160
	stg	%r14,0(%r15)
	brasl	%r14,proc_create
	lg	%r14,0(%r15)
	aghi	%r15,160
	lgr	%r0,%r2
L3cf:
# x86 @0x3cf: 89 c5
	lgr	%r9,%r0
L3d1:
# x86 @0x3d1: bf 02 00 00 00
	lghi	%r2,2
L3d6:
# x86 @0x3d6: e8 f3 fc ff ff
	aghi	%r15,-160
	stg	%r14,0(%r15)
	brasl	%r14,proc_create
	lg	%r14,0(%r15)
	aghi	%r15,160
	lgr	%r0,%r2
L3db:
# x86 @0x3db: 89 c3
	lgr	%r8,%r0
L3dd:
# x86 @0x3dd: bf 00 00 00 00
	larl	%r2,__sec__rodata_str1_8
	aghi	%r2,216
L3e2:
# x86 @0x3e2: e8 19 fc ff ff
	aghi	%r15,-160
	stg	%r14,0(%r15)
	brasl	%r14,kprint
	lg	%r14,0(%r15)
	aghi	%r15,160
	lgr	%r0,%r2
L3e7:
# x86 @0x3e7: 44 89 e7
	lgr	%r2,%r10
L3ea:
# x86 @0x3ea: e8 e2 fe ff ff
	aghi	%r15,-160
	stg	%r14,0(%r15)
	brasl	%r14,kprint_int
	lg	%r14,0(%r15)
	aghi	%r15,160
	lgr	%r0,%r2
L3ef:
# x86 @0x3ef: bf 00 00 00 00
	larl	%r2,__sec__rodata_str1_1
	aghi	%r2,5
L3f4:
# x86 @0x3f4: e8 07 fc ff ff
	aghi	%r15,-160
	stg	%r14,0(%r15)
	brasl	%r14,kprint
	lg	%r14,0(%r15)
	aghi	%r15,160
	lgr	%r0,%r2
L3f9:
# x86 @0x3f9: 89 ef
	lgr	%r2,%r9
L3fb:
# x86 @0x3fb: e8 d1 fe ff ff
	aghi	%r15,-160
	stg	%r14,0(%r15)
	brasl	%r14,kprint_int
	lg	%r14,0(%r15)
	aghi	%r15,160
	lgr	%r0,%r2
L400:
# x86 @0x400: bf 00 00 00 00
	larl	%r2,__sec__rodata_str1_1
	aghi	%r2,5
L405:
# x86 @0x405: e8 f6 fb ff ff
	aghi	%r15,-160
	stg	%r14,0(%r15)
	brasl	%r14,kprint
	lg	%r14,0(%r15)
	aghi	%r15,160
	lgr	%r0,%r2
L40a:
# x86 @0x40a: 89 df
	lgr	%r2,%r8
L40c:
# x86 @0x40c: e8 c0 fe ff ff
	aghi	%r15,-160
	stg	%r14,0(%r15)
	brasl	%r14,kprint_int
	lg	%r14,0(%r15)
	aghi	%r15,160
	lgr	%r0,%r2
L411:
# x86 @0x411: bf 00 00 00 00
	larl	%r2,__sec__rodata_str1_1
	aghi	%r2,3
L416:
# x86 @0x416: e8 e5 fb ff ff
	aghi	%r15,-160
	stg	%r14,0(%r15)
	brasl	%r14,kprint
	lg	%r14,0(%r15)
	aghi	%r15,160
	lgr	%r0,%r2
L41b:
# x86 @0x41b: bf 00 00 00 00
	larl	%r2,__sec__rodata_str1_8
	aghi	%r2,248
L420:
# x86 @0x420: e8 db fb ff ff
	aghi	%r15,-160
	stg	%r14,0(%r15)
	brasl	%r14,kprint
	lg	%r14,0(%r15)
	aghi	%r15,160
	lgr	%r0,%r2
L425:
# x86 @0x425: bf 40 00 00 00
	lghi	%r2,64
L42a:
# x86 @0x42a: e8 03 fc ff ff
	aghi	%r15,-160
	stg	%r14,0(%r15)
	brasl	%r14,kalloc
	lg	%r14,0(%r15)
	aghi	%r15,160
	lgr	%r0,%r2
L42f:
# x86 @0x42f: 48 89 c3
	lgr	%r8,%r0
L432:
# x86 @0x432: bf 80 00 00 00
	lghi	%r2,128
L437:
# x86 @0x437: e8 f6 fb ff ff
	aghi	%r15,-160
	stg	%r14,0(%r15)
	brasl	%r14,kalloc
	lg	%r14,0(%r15)
	aghi	%r15,160
	lgr	%r0,%r2
L43c:
# x86 @0x43c: 48 89 c5
	lgr	%r9,%r0
L43f:
# x86 @0x43f: 48 85 db
	ltgr	%r1,%r8
L442:
# x86 @0x442: 0f 84 6f 04 00 00
	je	L8b7
L448:
# x86 @0x448: c7 03 ef be ad de
	llilf	%r13,3735928559
	st	%r13,0(%r8)
L44e:
# x86 @0x44e: 48 85 c0
	ltgr	%r1,%r0
L451:
# x86 @0x451: 0f 84 0a 04 00 00
	je	L861
L457:
# x86 @0x457: c7 45 00 be ba fe ca
	llilf	%r13,3405691582
	st	%r13,0(%r9)
L45e:
# x86 @0x45e: bf 00 00 00 00
	larl	%r2,__sec__rodata_str1_1
	aghi	%r2,12
L463:
# x86 @0x463: e8 98 fb ff ff
	aghi	%r15,-160
	stg	%r14,0(%r15)
	brasl	%r14,kprint
	lg	%r14,0(%r15)
	aghi	%r15,160
	lgr	%r0,%r2
L468:
# x86 @0x468: 89 df
	lgr	%r2,%r8
L46a:
# x86 @0x46a: e8 ee fd ff ff
	aghi	%r15,-160
	stg	%r14,0(%r15)
	brasl	%r14,kprint_hex
	lg	%r14,0(%r15)
	aghi	%r15,160
	lgr	%r0,%r2
L46f:
# x86 @0x46f: bf 00 00 00 00
	larl	%r2,__sec__rodata_str1_1
	aghi	%r2,37
L474:
# x86 @0x474: e8 87 fb ff ff
	aghi	%r15,-160
	stg	%r14,0(%r15)
	brasl	%r14,kprint
	lg	%r14,0(%r15)
	aghi	%r15,160
	lgr	%r0,%r2
L479:
# x86 @0x479: 48 85 db
	ltgr	%r1,%r8
L47c:
# x86 @0x47c: 0f 84 ab 03 00 00
	je	L82d
L482:
# x86 @0x482: 8b 3b
	l	%r2,0(%r8)
L484:
# x86 @0x484: e8 d4 fd ff ff
	aghi	%r15,-160
	stg	%r14,0(%r15)
	brasl	%r14,kprint_hex
	lg	%r14,0(%r15)
	aghi	%r15,160
	lgr	%r0,%r2
L489:
# x86 @0x489: bf 00 00 00 00
	larl	%r2,__sec__rodata_str1_1
	aghi	%r2,3
L48e:
# x86 @0x48e: e8 6d fb ff ff
	aghi	%r15,-160
	stg	%r14,0(%r15)
	brasl	%r14,kprint
	lg	%r14,0(%r15)
	aghi	%r15,160
	lgr	%r0,%r2
L493:
# x86 @0x493: bf 00 00 00 00
	larl	%r2,__sec__rodata_str1_1
	aghi	%r2,371
L498:
# x86 @0x498: e8 63 fb ff ff
	aghi	%r15,-160
	stg	%r14,0(%r15)
	brasl	%r14,kprint
	lg	%r14,0(%r15)
	aghi	%r15,160
	lgr	%r0,%r2
L49d:
# x86 @0x49d: 89 ef
	lgr	%r2,%r9
L49f:
# x86 @0x49f: e8 b9 fd ff ff
	aghi	%r15,-160
	stg	%r14,0(%r15)
	brasl	%r14,kprint_hex
	lg	%r14,0(%r15)
	aghi	%r15,160
	lgr	%r0,%r2
L4a4:
# x86 @0x4a4: bf 00 00 00 00
	larl	%r2,__sec__rodata_str1_1
	aghi	%r2,37
L4a9:
# x86 @0x4a9: e8 52 fb ff ff
	aghi	%r15,-160
	stg	%r14,0(%r15)
	brasl	%r14,kprint
	lg	%r14,0(%r15)
	aghi	%r15,160
	lgr	%r0,%r2
L4ae:
# x86 @0x4ae: 8b 7d 00
	l	%r2,0(%r9)
L4b1:
# x86 @0x4b1: e8 a7 fd ff ff
	aghi	%r15,-160
	stg	%r14,0(%r15)
	brasl	%r14,kprint_hex
	lg	%r14,0(%r15)
	aghi	%r15,160
	lgr	%r0,%r2
L4b6:
# x86 @0x4b6: bf 00 00 00 00
	larl	%r2,__sec__rodata_str1_1
	aghi	%r2,3
L4bb:
# x86 @0x4bb: e8 40 fb ff ff
	aghi	%r15,-160
	stg	%r14,0(%r15)
	brasl	%r14,kprint
	lg	%r14,0(%r15)
	aghi	%r15,160
	lgr	%r0,%r2
L4c0:
# x86 @0x4c0: 48 89 df
	lgr	%r2,%r8
L4c3:
# x86 @0x4c3: e8 eb fb ff ff
	aghi	%r15,-160
	stg	%r14,0(%r15)
	brasl	%r14,kfree
	lg	%r14,0(%r15)
	aghi	%r15,160
	lgr	%r0,%r2
L4c8:
# x86 @0x4c8: bf 00 00 00 00
	larl	%r2,__sec__rodata_str1_1
	aghi	%r2,41
L4cd:
# x86 @0x4cd: e8 2e fb ff ff
	aghi	%r15,-160
	stg	%r14,0(%r15)
	brasl	%r14,kprint
	lg	%r14,0(%r15)
	aghi	%r15,160
	lgr	%r0,%r2
L4d2:
# x86 @0x4d2: bf 20 00 00 00
	lghi	%r2,32
L4d7:
# x86 @0x4d7: e8 56 fb ff ff
	aghi	%r15,-160
	stg	%r14,0(%r15)
	brasl	%r14,kalloc
	lg	%r14,0(%r15)
	aghi	%r15,160
	lgr	%r0,%r2
L4dc:
# x86 @0x4dc: 48 89 c3
	lgr	%r8,%r0
L4df:
# x86 @0x4df: bf 00 00 00 00
	larl	%r2,__sec__rodata_str1_1
	aghi	%r2,65
L4e4:
# x86 @0x4e4: e8 17 fb ff ff
	aghi	%r15,-160
	stg	%r14,0(%r15)
	brasl	%r14,kprint
	lg	%r14,0(%r15)
	aghi	%r15,160
	lgr	%r0,%r2
L4e9:
# x86 @0x4e9: 89 df
	lgr	%r2,%r8
L4eb:
# x86 @0x4eb: e8 6d fd ff ff
	aghi	%r15,-160
	stg	%r14,0(%r15)
	brasl	%r14,kprint_hex
	lg	%r14,0(%r15)
	aghi	%r15,160
	lgr	%r0,%r2
L4f0:
# x86 @0x4f0: bf 00 00 00 00
	larl	%r2,__sec__rodata_str1_1
	aghi	%r2,93
L4f5:
# x86 @0x4f5: e8 06 fb ff ff
	aghi	%r15,-160
	stg	%r14,0(%r15)
	brasl	%r14,kprint
	lg	%r14,0(%r15)
	aghi	%r15,160
	lgr	%r0,%r2
L4fa:
# x86 @0x4fa: 48 89 ef
	lgr	%r2,%r9
L4fd:
# x86 @0x4fd: e8 b1 fb ff ff
	aghi	%r15,-160
	stg	%r14,0(%r15)
	brasl	%r14,kfree
	lg	%r14,0(%r15)
	aghi	%r15,160
	lgr	%r0,%r2
L502:
# x86 @0x502: 48 89 df
	lgr	%r2,%r8
L505:
# x86 @0x505: e8 a9 fb ff ff
	aghi	%r15,-160
	stg	%r14,0(%r15)
	brasl	%r14,kfree
	lg	%r14,0(%r15)
	aghi	%r15,160
	lgr	%r0,%r2
L50a:
# x86 @0x50a: bf 00 00 00 00
	larl	%r2,__sec__rodata_str1_1
	aghi	%r2,3
L50f:
# x86 @0x50f: e8 ec fa ff ff
	aghi	%r15,-160
	stg	%r14,0(%r15)
	brasl	%r14,kprint
	lg	%r14,0(%r15)
	aghi	%r15,160
	lgr	%r0,%r2
L514:
# x86 @0x514: bf 00 00 00 00
	larl	%r2,__sec__rodata_str1_8
	aghi	%r2,288
L519:
# x86 @0x519: e8 e2 fa ff ff
	aghi	%r15,-160
	stg	%r14,0(%r15)
	brasl	%r14,kprint
	lg	%r14,0(%r15)
	aghi	%r15,160
	lgr	%r0,%r2
L51e:
# x86 @0x51e: bd 03 00 00 00
	lghi	%r9,3
L523:
# x86 @0x523: bb 00 00 00 00
	lghi	%r8,0
L528:
# x86 @0x528: e9 8c 00 00 00
	j	L5b9
L52d:
# x86 @0x52d: 45 85 e4
	ltr	%r1,%r10
L530:
# x86 @0x530: 0f 88 c6 00 00 00
	jl	L5fc
L536:
# x86 @0x536: 85 f6
	ltr	%r1,%r3
L538:
# x86 @0x538: 78 11
	jl	L54b
L53a:
# x86 @0x53a: 48 63 c6
	lgfr	%r0,%r3
L53d:
# x86 @0x53d: 83 3c 85 00 00 00 00 02
	lgr	%r1,%r0
	sllg	%r1,%r1,2
	aghi	%r15,-8
	stg	%r0,0(%r15)
	larl	%r0,proc_state
	algr	%r1,%r0
	lg	%r0,0(%r15)
	aghi	%r15,8
	l	%r1,0(%r1)
	cfi	%r1,2
L545:
# x86 @0x545: 0f 84 e3 01 00 00
	je	L72e
L54b:
# x86 @0x54b: 44 89 25 00 00 00 00
	larl	%r1,current_proc
	st	%r10,0(%r1)
L552:
# x86 @0x552: 49 63 c4
	lgfr	%r0,%r10
L555:
# x86 @0x555: c7 04 85 00 00 00 00 02 00 00 00
	lgr	%r1,%r0
	sllg	%r1,%r1,2
	aghi	%r15,-8
	stg	%r0,0(%r15)
	lghi	%r13,2
	aghi	%r15,-8
	stg	%r0,0(%r15)
	larl	%r0,proc_state
	algr	%r1,%r0
	lg	%r0,0(%r15)
	aghi	%r15,8
	st	%r13,0(%r1)
	lg	%r0,0(%r15)
	aghi	%r15,8
L560:
# x86 @0x560: 44 8b 34 85 00 00 00 00
	lgr	%r1,%r0
	sllg	%r1,%r1,2
	aghi	%r15,-8
	stg	%r0,0(%r15)
	larl	%r0,proc_pid
	algr	%r1,%r0
	lg	%r0,0(%r15)
	aghi	%r15,8
	l	%r12,0(%r1)
L568:
# x86 @0x568: 48 89 c2
	lgr	%r4,%r0
L56b:
# x86 @0x56b: 48 c1 e2 04
	sllg	%r4,%r4,4
L56f:
# x86 @0x56f: 44 8b aa 00 00 00 00
	aghi	%r15,-8
	stg	%r0,0(%r15)
	larl	%r0,proc_regs
	lgr	%r1,%r4
	algr	%r1,%r0
	lg	%r0,0(%r15)
	aghi	%r15,8
	l	%r11,0(%r1)
L576:
# x86 @0x576: 83 04 85 00 00 00 00 01
	lgr	%r1,%r0
	sllg	%r1,%r1,2
	aghi	%r15,-8
	stg	%r0,0(%r15)
	larl	%r0,proc_ticks
	algr	%r1,%r0
	lg	%r0,0(%r15)
	aghi	%r15,8
	l	%r13,0(%r1)
	ahi	%r13,1
	lgr	%r1,%r0
	sllg	%r1,%r1,2
	aghi	%r15,-8
	stg	%r0,0(%r15)
	larl	%r0,proc_ticks
	algr	%r1,%r0
	lg	%r0,0(%r15)
	aghi	%r15,8
	st	%r13,0(%r1)
L57e:
# x86 @0x57e: 83 05 00 00 00 00 01
	larl	%r1,total_ticks
	l	%r13,0(%r1)
	ahi	%r13,1
	larl	%r1,total_ticks
	st	%r13,0(%r1)
L585:
# x86 @0x585: 49 63 c5
	lgfr	%r0,%r11
L588:
# x86 @0x588: ff 14 c5 00 00 00 00
	aghi	%r15,-160
	stg	%r14,0(%r15)
	lgr	%r1,%r0
	sllg	%r1,%r1,3
	aghi	%r15,-8
	stg	%r0,0(%r15)
	larl	%r0,user_progs
	algr	%r1,%r0
	lg	%r0,0(%r15)
	aghi	%r15,8
	lg	%r1,0(%r1)
	basr	%r14,%r1
	lg	%r14,0(%r15)
	aghi	%r15,160
	lgr	%r0,%r2
L58f:
# x86 @0x58f: 41 89 c7
	lgr	%r14,%r0
L592:
# x86 @0x592: 85 c0
	ltr	%r1,%r0
L594:
# x86 @0x594: 0f 84 a4 01 00 00
	je	L73e
L59a:
# x86 @0x59a: 4d 63 e4
	lgfr	%r10,%r10
L59d:
# x86 @0x59d: 42 c7 04 a5 00 00 00 00 01 00 00 00
	sllg	%r1,%r10,2
	aghi	%r15,-8
	stg	%r0,0(%r15)
	lghi	%r13,1
	aghi	%r15,-8
	stg	%r0,0(%r15)
	larl	%r0,proc_state
	algr	%r1,%r0
	lg	%r0,0(%r15)
	aghi	%r15,8
	st	%r13,0(%r1)
	lg	%r0,0(%r15)
	aghi	%r15,8
L5a9:
# x86 @0x5a9: 83 c3 01
	ahi	%r8,1
L5ac:
# x86 @0x5ac: 83 fb 04
	cfi	%r8,4
L5af:
# x86 @0x5af: 0f 8f 6e 02 00 00
	jh	L823
L5b5:
# x86 @0x5b5: 85 ed
	ltr	%r1,%r9
L5b7:
# x86 @0x5b7: 7e 43
	jle	L5fc
L5b9:
# x86 @0x5b9: 8b 35 00 00 00 00
	larl	%r1,current_proc
	l	%r3,0(%r1)
L5bf:
# x86 @0x5bf: 8d 4e 01
	la	%r5,1(%r3)
L5c2:
# x86 @0x5c2: 89 c8
	lgr	%r0,%r5
L5c4:
# x86 @0x5c4: c1 f8 1f
	sra	%r0,31
L5c7:
# x86 @0x5c7: c1 e8 1d
	srl	%r0,29
L5ca:
# x86 @0x5ca: 01 c1
	ar	%r5,%r0
L5cc:
# x86 @0x5cc: 83 e1 07
	nilf	%r5,7
L5cf:
# x86 @0x5cf: 29 c1
	sr	%r5,%r0
L5d1:
# x86 @0x5d1: 41 89 cc
	lgr	%r10,%r5
L5d4:
# x86 @0x5d4: 49 63 c4
	lgfr	%r0,%r10
L5d7:
# x86 @0x5d7: 83 3c 85 00 00 00 00 01
	lgr	%r1,%r0
	sllg	%r1,%r1,2
	aghi	%r15,-8
	stg	%r0,0(%r15)
	larl	%r0,proc_state
	algr	%r1,%r0
	lg	%r0,0(%r15)
	aghi	%r15,8
	l	%r1,0(%r1)
	cfi	%r1,1
L5df:
# x86 @0x5df: 0f 84 48 ff ff ff
	je	L52d
L5e5:
# x86 @0x5e5: 41 8d 44 24 01
	la	%r0,1(%r10)
L5ea:
# x86 @0x5ea: 99
	lgfr	%r4,%r0
	srag	%r4,%r4,32
L5eb:
# x86 @0x5eb: c1 ea 1d
	srl	%r4,29
L5ee:
# x86 @0x5ee: 01 d0
	ar	%r0,%r4
L5f0:
# x86 @0x5f0: 83 e0 07
	nilf	%r0,7
L5f3:
# x86 @0x5f3: 29 d0
	sr	%r0,%r4
L5f5:
# x86 @0x5f5: 41 89 c4
	lgr	%r10,%r0
L5f8:
# x86 @0x5f8: 39 c1
	cr	%r5,%r0
L5fa:
# x86 @0x5fa: 75 d8
	jne	L5d4
L5fc:
# x86 @0x5fc: bf 00 00 00 00
	larl	%r2,__sec__rodata_str1_1
	aghi	%r2,3
L601:
# x86 @0x601: e8 fa f9 ff ff
	aghi	%r15,-160
	stg	%r14,0(%r15)
	brasl	%r14,kprint
	lg	%r14,0(%r15)
	aghi	%r15,160
	lgr	%r0,%r2
L606:
# x86 @0x606: bf 00 00 00 00
	larl	%r2,__sec__rodata_str1_8
L60b:
# x86 @0x60b: e8 f0 f9 ff ff
	aghi	%r15,-160
	stg	%r14,0(%r15)
	brasl	%r14,kprint
	lg	%r14,0(%r15)
	aghi	%r15,160
	lgr	%r0,%r2
L610:
# x86 @0x610: bf 00 00 00 00
	larl	%r2,__sec__rodata_str1_1
	aghi	%r2,205
L615:
# x86 @0x615: e8 e6 f9 ff ff
	aghi	%r15,-160
	stg	%r14,0(%r15)
	brasl	%r14,kprint
	lg	%r14,0(%r15)
	aghi	%r15,160
	lgr	%r0,%r2
L61a:
# x86 @0x61a: bf 00 00 00 00
	larl	%r2,__sec__rodata_str1_8
L61f:
# x86 @0x61f: e8 dc f9 ff ff
	aghi	%r15,-160
	stg	%r14,0(%r15)
	brasl	%r14,kprint
	lg	%r14,0(%r15)
	aghi	%r15,160
	lgr	%r0,%r2
L624:
# x86 @0x624: bf 00 00 00 00
	larl	%r2,__sec__rodata_str1_1
	aghi	%r2,230
L629:
# x86 @0x629: e8 d2 f9 ff ff
	aghi	%r15,-160
	stg	%r14,0(%r15)
	brasl	%r14,kprint
	lg	%r14,0(%r15)
	aghi	%r15,160
	lgr	%r0,%r2
L62e:
# x86 @0x62e: 8b 3d 00 00 00 00
	larl	%r1,total_ticks
	l	%r2,0(%r1)
L634:
# x86 @0x634: e8 98 fc ff ff
	aghi	%r15,-160
	stg	%r14,0(%r15)
	brasl	%r14,kprint_int
	lg	%r14,0(%r15)
	aghi	%r15,160
	lgr	%r0,%r2
L639:
# x86 @0x639: bf 00 00 00 00
	larl	%r2,__sec__rodata_str1_1
	aghi	%r2,3
L63e:
# x86 @0x63e: e8 bd f9 ff ff
	aghi	%r15,-160
	stg	%r14,0(%r15)
	brasl	%r14,kprint
	lg	%r14,0(%r15)
	aghi	%r15,160
	lgr	%r0,%r2
L643:
# x86 @0x643: bf 00 00 00 00
	larl	%r2,__sec__rodata_str1_1
	aghi	%r2,250
L648:
# x86 @0x648: e8 b3 f9 ff ff
	aghi	%r15,-160
	stg	%r14,0(%r15)
	brasl	%r14,kprint
	lg	%r14,0(%r15)
	aghi	%r15,160
	lgr	%r0,%r2
L64d:
# x86 @0x64d: 8b 1d 00 00 00 00
	larl	%r1,fib_result
	l	%r8,0(%r1)
L653:
# x86 @0x653: 89 df
	lgr	%r2,%r8
L655:
# x86 @0x655: e8 77 fc ff ff
	aghi	%r15,-160
	stg	%r14,0(%r15)
	brasl	%r14,kprint_int
	lg	%r14,0(%r15)
	aghi	%r15,160
	lgr	%r0,%r2
L65a:
# x86 @0x65a: bf 00 00 00 00
	larl	%r2,__sec__rodata_str1_1
	aghi	%r2,3
L65f:
# x86 @0x65f: e8 9c f9 ff ff
	aghi	%r15,-160
	stg	%r14,0(%r15)
	brasl	%r14,kprint
	lg	%r14,0(%r15)
	aghi	%r15,160
	lgr	%r0,%r2
L664:
# x86 @0x664: bf 00 00 00 00
	larl	%r2,__sec__rodata_str1_1
	aghi	%r2,278
L669:
# x86 @0x669: e8 92 f9 ff ff
	aghi	%r15,-160
	stg	%r14,0(%r15)
	brasl	%r14,kprint
	lg	%r14,0(%r15)
	aghi	%r15,160
	lgr	%r0,%r2
L66e:
# x86 @0x66e: 44 8b 25 00 00 00 00
	larl	%r1,prime_count
	l	%r10,0(%r1)
L675:
# x86 @0x675: 44 89 e7
	lgr	%r2,%r10
L678:
# x86 @0x678: e8 54 fc ff ff
	aghi	%r15,-160
	stg	%r14,0(%r15)
	brasl	%r14,kprint_int
	lg	%r14,0(%r15)
	aghi	%r15,160
	lgr	%r0,%r2
L67d:
# x86 @0x67d: bf 00 00 00 00
	larl	%r2,__sec__rodata_str1_1
	aghi	%r2,298
L682:
# x86 @0x682: e8 79 f9 ff ff
	aghi	%r15,-160
	stg	%r14,0(%r15)
	brasl	%r14,kprint
	lg	%r14,0(%r15)
	aghi	%r15,160
	lgr	%r0,%r2
L687:
# x86 @0x687: 8b 3d 00 00 00 00
	larl	%r1,prime_found
	l	%r2,0(%r1)
L68d:
# x86 @0x68d: e8 3f fc ff ff
	aghi	%r15,-160
	stg	%r14,0(%r15)
	brasl	%r14,kprint_int
	lg	%r14,0(%r15)
	aghi	%r15,160
	lgr	%r0,%r2
L692:
# x86 @0x692: bf 00 00 00 00
	larl	%r2,__sec__rodata_str1_1
	aghi	%r2,3
L697:
# x86 @0x697: e8 64 f9 ff ff
	aghi	%r15,-160
	stg	%r14,0(%r15)
	brasl	%r14,kprint
	lg	%r14,0(%r15)
	aghi	%r15,160
	lgr	%r0,%r2
L69c:
# x86 @0x69c: bf 00 00 00 00
	larl	%r2,__sec__rodata_str1_1
	aghi	%r2,319
L6a1:
# x86 @0x6a1: e8 5a f9 ff ff
	aghi	%r15,-160
	stg	%r14,0(%r15)
	brasl	%r14,kprint
	lg	%r14,0(%r15)
	aghi	%r15,160
	lgr	%r0,%r2
L6a6:
# x86 @0x6a6: 8b 2d 00 00 00 00
	larl	%r1,sum_result
	l	%r9,0(%r1)
L6ac:
# x86 @0x6ac: 89 ef
	lgr	%r2,%r9
L6ae:
# x86 @0x6ae: e8 1e fc ff ff
	aghi	%r15,-160
	stg	%r14,0(%r15)
	brasl	%r14,kprint_int
	lg	%r14,0(%r15)
	aghi	%r15,160
	lgr	%r0,%r2
L6b3:
# x86 @0x6b3: bf 00 00 00 00
	larl	%r2,__sec__rodata_str1_1
	aghi	%r2,3
L6b8:
# x86 @0x6b8: e8 43 f9 ff ff
	aghi	%r15,-160
	stg	%r14,0(%r15)
	brasl	%r14,kprint
	lg	%r14,0(%r15)
	aghi	%r15,160
	lgr	%r0,%r2
L6bd:
# x86 @0x6bd: bf 00 00 00 00
	larl	%r2,__sec__rodata_str1_1
	aghi	%r2,339
L6c2:
# x86 @0x6c2: e8 39 f9 ff ff
	aghi	%r15,-160
	stg	%r14,0(%r15)
	brasl	%r14,kprint
	lg	%r14,0(%r15)
	aghi	%r15,160
	lgr	%r0,%r2
L6c7:
# x86 @0x6c7: 48 8b 3d 00 00 00 00
	larl	%r1,heap_brk
	lg	%r2,0(%r1)
L6ce:
# x86 @0x6ce: 48 81 ef 00 00 00 00
	larl	%r1,kheap
	sgr	%r2,%r1
L6d5:
# x86 @0x6d5: e8 f7 fb ff ff
	aghi	%r15,-160
	stg	%r14,0(%r15)
	brasl	%r14,kprint_int
	lg	%r14,0(%r15)
	aghi	%r15,160
	lgr	%r0,%r2
L6da:
# x86 @0x6da: bf 00 00 00 00
	larl	%r2,__sec__rodata_str1_1
	aghi	%r2,359
L6df:
# x86 @0x6df: e8 1c f9 ff ff
	aghi	%r15,-160
	stg	%r14,0(%r15)
	brasl	%r14,kprint
	lg	%r14,0(%r15)
	aghi	%r15,160
	lgr	%r0,%r2
L6e4:
# x86 @0x6e4: bf 00 10 00 00
	lghi	%r2,4096
L6e9:
# x86 @0x6e9: e8 e3 fb ff ff
	aghi	%r15,-160
	stg	%r14,0(%r15)
	brasl	%r14,kprint_int
	lg	%r14,0(%r15)
	aghi	%r15,160
	lgr	%r0,%r2
L6ee:
# x86 @0x6ee: bf 00 00 00 00
	larl	%r2,__sec__rodata_str1_1
	aghi	%r2,363
L6f3:
# x86 @0x6f3: e8 08 f9 ff ff
	aghi	%r15,-160
	stg	%r14,0(%r15)
	brasl	%r14,kprint
	lg	%r14,0(%r15)
	aghi	%r15,160
	lgr	%r0,%r2
L6f8:
# x86 @0x6f8: bf 00 00 00 00
	larl	%r2,__sec__rodata_str1_8
	aghi	%r2,352
L6fd:
# x86 @0x6fd: e8 fe f8 ff ff
	aghi	%r15,-160
	stg	%r14,0(%r15)
	brasl	%r14,kprint
	lg	%r14,0(%r15)
	aghi	%r15,160
	lgr	%r0,%r2
L702:
# x86 @0x702: bf 00 00 00 00
	larl	%r2,__sec__rodata_str1_8
	aghi	%r2,128
L707:
# x86 @0x707: e8 f4 f8 ff ff
	aghi	%r15,-160
	stg	%r14,0(%r15)
	brasl	%r14,kprint
	lg	%r14,0(%r15)
	aghi	%r15,160
	lgr	%r0,%r2
L70c:
# x86 @0x70c: bf 00 00 00 00
	larl	%r2,__sec__rodata_str1_8
	aghi	%r2,400
L711:
# x86 @0x711: e8 ea f8 ff ff
	aghi	%r15,-160
	stg	%r14,0(%r15)
	brasl	%r14,kprint
	lg	%r14,0(%r15)
	aghi	%r15,160
	lgr	%r0,%r2
L716:
# x86 @0x716: 42 8d 04 23
	la	%r1,0(%r8,%r10)
	lgr	%r0,%r1
L71a:
# x86 @0x71a: 01 e8
	ar	%r0,%r9
L71c:
# x86 @0x71c: 0f b6 c0
	llgcr	%r0,%r0
L71f:
# x86 @0x71f: 48 83 c4 08
	aghi	%r15,8
L723:
# x86 @0x723: 5b
	lg	%r8,0(%r15)
	aghi	%r15,8
L724:
# x86 @0x724: 5d
	lg	%r9,0(%r15)
	aghi	%r15,8
L725:
# x86 @0x725: 41 5c
	lg	%r10,0(%r15)
	aghi	%r15,8
L727:
# x86 @0x727: 41 5d
	lg	%r11,0(%r15)
	aghi	%r15,8
L729:
# x86 @0x729: 41 5e
	lg	%r12,0(%r15)
	aghi	%r15,8
L72b:
# x86 @0x72b: 41 5f
	lg	%r14,0(%r15)
	aghi	%r15,8
L72d:
# x86 @0x72d: c3
	lgr	%r2,%r0
	br	%r14
L72e:
# x86 @0x72e: c7 04 85 00 00 00 00 01 00 00 00
	lgr	%r1,%r0
	sllg	%r1,%r1,2
	aghi	%r15,-8
	stg	%r0,0(%r15)
	lghi	%r13,1
	aghi	%r15,-8
	stg	%r0,0(%r15)
	larl	%r0,proc_state
	algr	%r1,%r0
	lg	%r0,0(%r15)
	aghi	%r15,8
	st	%r13,0(%r1)
	lg	%r0,0(%r15)
	aghi	%r15,8
L739:
# x86 @0x739: e9 0d fe ff ff
	j	L54b
L73e:
# x86 @0x73e: bf 00 00 00 00
	larl	%r2,__sec__rodata_str1_1
	aghi	%r2,122
L743:
# x86 @0x743: e8 b8 f8 ff ff
	aghi	%r15,-160
	stg	%r14,0(%r15)
	brasl	%r14,kprint
	lg	%r14,0(%r15)
	aghi	%r15,160
	lgr	%r0,%r2
L748:
# x86 @0x748: 89 df
	lgr	%r2,%r8
L74a:
# x86 @0x74a: e8 82 fb ff ff
	aghi	%r15,-160
	stg	%r14,0(%r15)
	brasl	%r14,kprint_int
	lg	%r14,0(%r15)
	aghi	%r15,160
	lgr	%r0,%r2
L74f:
# x86 @0x74f: bf 00 00 00 00
	larl	%r2,__sec__rodata_str1_1
	aghi	%r2,129
L754:
# x86 @0x754: e8 a7 f8 ff ff
	aghi	%r15,-160
	stg	%r14,0(%r15)
	brasl	%r14,kprint
	lg	%r14,0(%r15)
	aghi	%r15,160
	lgr	%r0,%r2
L759:
# x86 @0x759: 44 89 f7
	lgr	%r2,%r12
L75c:
# x86 @0x75c: e8 70 fb ff ff
	aghi	%r15,-160
	stg	%r14,0(%r15)
	brasl	%r14,kprint_int
	lg	%r14,0(%r15)
	aghi	%r15,160
	lgr	%r0,%r2
L761:
# x86 @0x761: bf 00 00 00 00
	larl	%r2,__sec__rodata_str1_1
	aghi	%r2,136
L766:
# x86 @0x766: e8 95 f8 ff ff
	aghi	%r15,-160
	stg	%r14,0(%r15)
	brasl	%r14,kprint
	lg	%r14,0(%r15)
	aghi	%r15,160
	lgr	%r0,%r2
L76b:
# x86 @0x76b: 45 85 ed
	ltr	%r1,%r11
L76e:
# x86 @0x76e: 74 5a
	je	L7ca
L770:
# x86 @0x770: 41 83 fd 01
	cfi	%r11,1
L774:
# x86 @0x774: 74 7f
	je	L7f5
L776:
# x86 @0x776: bf 00 00 00 00
	larl	%r2,__sec__rodata_str1_1
	aghi	%r2,189
L77b:
# x86 @0x77b: e8 80 f8 ff ff
	aghi	%r15,-160
	stg	%r14,0(%r15)
	brasl	%r14,kprint
	lg	%r14,0(%r15)
	aghi	%r15,160
	lgr	%r0,%r2
L780:
# x86 @0x780: bf 00 00 00 00
	larl	%r2,__sec__rodata_str1_1
	aghi	%r2,149
L785:
# x86 @0x785: e8 76 f8 ff ff
	aghi	%r15,-160
	stg	%r14,0(%r15)
	brasl	%r14,kprint
	lg	%r14,0(%r15)
	aghi	%r15,160
	lgr	%r0,%r2
L78a:
# x86 @0x78a: bf 00 00 00 00
	larl	%r2,__sec__rodata_str1_1
	aghi	%r2,193
L78f:
# x86 @0x78f: e8 6c f8 ff ff
	aghi	%r15,-160
	stg	%r14,0(%r15)
	brasl	%r14,kprint
	lg	%r14,0(%r15)
	aghi	%r15,160
	lgr	%r0,%r2
L794:
# x86 @0x794: 8b 3d 00 00 00 00
	larl	%r1,sum_result
	l	%r2,0(%r1)
L79a:
# x86 @0x79a: e8 32 fb ff ff
	aghi	%r15,-160
	stg	%r14,0(%r15)
	brasl	%r14,kprint_int
	lg	%r14,0(%r15)
	aghi	%r15,160
	lgr	%r0,%r2
L79f:
# x86 @0x79f: bf 00 00 00 00
	larl	%r2,__sec__rodata_str1_1
	aghi	%r2,3
L7a4:
# x86 @0x7a4: e8 57 f8 ff ff
	aghi	%r15,-160
	stg	%r14,0(%r15)
	brasl	%r14,kprint
	lg	%r14,0(%r15)
	aghi	%r15,160
	lgr	%r0,%r2
L7a9:
# x86 @0x7a9: 83 ed 01
	ahi	%r9,-1
L7ac:
# x86 @0x7ac: 4d 63 e4
	lgfr	%r10,%r10
L7af:
# x86 @0x7af: 42 c7 04 a5 00 00 00 00 00 00 00 00
	sllg	%r1,%r10,2
	aghi	%r15,-8
	stg	%r0,0(%r15)
	lghi	%r13,0
	aghi	%r15,-8
	stg	%r0,0(%r15)
	larl	%r0,proc_state
	algr	%r1,%r0
	lg	%r0,0(%r15)
	aghi	%r15,8
	st	%r13,0(%r1)
	lg	%r0,0(%r15)
	aghi	%r15,8
L7bb:
# x86 @0x7bb: 83 c3 01
	ahi	%r8,1
L7be:
# x86 @0x7be: 83 fb 05
	cfi	%r8,5
L7c1:
# x86 @0x7c1: 41 0f 4d df
	locgr	%r8,%r14,11
L7c5:
# x86 @0x7c5: e9 eb fd ff ff
	j	L5b5
L7ca:
# x86 @0x7ca: bf 00 00 00 00
	larl	%r2,__sec__rodata_str1_1
	aghi	%r2,139
L7cf:
# x86 @0x7cf: e8 2c f8 ff ff
	aghi	%r15,-160
	stg	%r14,0(%r15)
	brasl	%r14,kprint
	lg	%r14,0(%r15)
	aghi	%r15,160
	lgr	%r0,%r2
L7d4:
# x86 @0x7d4: bf 00 00 00 00
	larl	%r2,__sec__rodata_str1_1
	aghi	%r2,149
L7d9:
# x86 @0x7d9: e8 22 f8 ff ff
	aghi	%r15,-160
	stg	%r14,0(%r15)
	brasl	%r14,kprint
	lg	%r14,0(%r15)
	aghi	%r15,160
	lgr	%r0,%r2
L7de:
# x86 @0x7de: bf 00 00 00 00
	larl	%r2,__sec__rodata_str1_1
	aghi	%r2,162
L7e3:
# x86 @0x7e3: e8 18 f8 ff ff
	aghi	%r15,-160
	stg	%r14,0(%r15)
	brasl	%r14,kprint
	lg	%r14,0(%r15)
	aghi	%r15,160
	lgr	%r0,%r2
L7e8:
# x86 @0x7e8: 8b 3d 00 00 00 00
	larl	%r1,fib_result
	l	%r2,0(%r1)
L7ee:
# x86 @0x7ee: e8 de fa ff ff
	aghi	%r15,-160
	stg	%r14,0(%r15)
	brasl	%r14,kprint_int
	lg	%r14,0(%r15)
	aghi	%r15,160
	lgr	%r0,%r2
L7f3:
# x86 @0x7f3: eb aa
	j	L79f
L7f5:
# x86 @0x7f5: bf 00 00 00 00
	larl	%r2,__sec__rodata_str1_1
	aghi	%r2,171
L7fa:
# x86 @0x7fa: e8 01 f8 ff ff
	aghi	%r15,-160
	stg	%r14,0(%r15)
	brasl	%r14,kprint
	lg	%r14,0(%r15)
	aghi	%r15,160
	lgr	%r0,%r2
L7ff:
# x86 @0x7ff: bf 00 00 00 00
	larl	%r2,__sec__rodata_str1_1
	aghi	%r2,149
L804:
# x86 @0x804: e8 f7 f7 ff ff
	aghi	%r15,-160
	stg	%r14,0(%r15)
	brasl	%r14,kprint
	lg	%r14,0(%r15)
	aghi	%r15,160
	lgr	%r0,%r2
L809:
# x86 @0x809: bf 00 00 00 00
	larl	%r2,__sec__rodata_str1_1
	aghi	%r2,177
L80e:
# x86 @0x80e: e8 ed f7 ff ff
	aghi	%r15,-160
	stg	%r14,0(%r15)
	brasl	%r14,kprint
	lg	%r14,0(%r15)
	aghi	%r15,160
	lgr	%r0,%r2
L813:
# x86 @0x813: 8b 3d 00 00 00 00
	larl	%r1,prime_found
	l	%r2,0(%r1)
L819:
# x86 @0x819: e8 b3 fa ff ff
	aghi	%r15,-160
	stg	%r14,0(%r15)
	brasl	%r14,kprint_int
	lg	%r14,0(%r15)
	aghi	%r15,160
	lgr	%r0,%r2
L81e:
# x86 @0x81e: e9 7c ff ff ff
	j	L79f
L823:
# x86 @0x823: bb 00 00 00 00
	lghi	%r8,0
L828:
# x86 @0x828: e9 8c fd ff ff
	j	L5b9
L82d:
# x86 @0x82d: bf 00 00 00 00
	lghi	%r2,0
L832:
# x86 @0x832: e8 26 fa ff ff
	aghi	%r15,-160
	stg	%r14,0(%r15)
	brasl	%r14,kprint_hex
	lg	%r14,0(%r15)
	aghi	%r15,160
	lgr	%r0,%r2
L837:
# x86 @0x837: bf 00 00 00 00
	larl	%r2,__sec__rodata_str1_1
	aghi	%r2,3
L83c:
# x86 @0x83c: e8 bf f7 ff ff
	aghi	%r15,-160
	stg	%r14,0(%r15)
	brasl	%r14,kprint
	lg	%r14,0(%r15)
	aghi	%r15,160
	lgr	%r0,%r2
L841:
# x86 @0x841: bf 00 00 00 00
	larl	%r2,__sec__rodata_str1_1
	aghi	%r2,371
L846:
# x86 @0x846: e8 b5 f7 ff ff
	aghi	%r15,-160
	stg	%r14,0(%r15)
	brasl	%r14,kprint
	lg	%r14,0(%r15)
	aghi	%r15,160
	lgr	%r0,%r2
L84b:
# x86 @0x84b: 89 ef
	lgr	%r2,%r9
L84d:
# x86 @0x84d: e8 0b fa ff ff
	aghi	%r15,-160
	stg	%r14,0(%r15)
	brasl	%r14,kprint_hex
	lg	%r14,0(%r15)
	aghi	%r15,160
	lgr	%r0,%r2
L852:
# x86 @0x852: bf 00 00 00 00
	larl	%r2,__sec__rodata_str1_1
	aghi	%r2,37
L857:
# x86 @0x857: e8 a4 f7 ff ff
	aghi	%r15,-160
	stg	%r14,0(%r15)
	brasl	%r14,kprint
	lg	%r14,0(%r15)
	aghi	%r15,160
	lgr	%r0,%r2
L85c:
# x86 @0x85c: e9 4d fc ff ff
	j	L4ae
L861:
# x86 @0x861: bf 00 00 00 00
	larl	%r2,__sec__rodata_str1_1
	aghi	%r2,12
L866:
# x86 @0x866: e8 95 f7 ff ff
	aghi	%r15,-160
	stg	%r14,0(%r15)
	brasl	%r14,kprint
	lg	%r14,0(%r15)
	aghi	%r15,160
	lgr	%r0,%r2
L86b:
# x86 @0x86b: 89 df
	lgr	%r2,%r8
L86d:
# x86 @0x86d: e8 eb f9 ff ff
	aghi	%r15,-160
	stg	%r14,0(%r15)
	brasl	%r14,kprint_hex
	lg	%r14,0(%r15)
	aghi	%r15,160
	lgr	%r0,%r2
L872:
# x86 @0x872: bf 00 00 00 00
	larl	%r2,__sec__rodata_str1_1
	aghi	%r2,37
L877:
# x86 @0x877: e8 84 f7 ff ff
	aghi	%r15,-160
	stg	%r14,0(%r15)
	brasl	%r14,kprint
	lg	%r14,0(%r15)
	aghi	%r15,160
	lgr	%r0,%r2
L87c:
# x86 @0x87c: 48 85 db
	ltgr	%r1,%r8
L87f:
# x86 @0x87f: 74 5a
	je	L8db
L881:
# x86 @0x881: 8b 3b
	l	%r2,0(%r8)
L883:
# x86 @0x883: e8 d5 f9 ff ff
	aghi	%r15,-160
	stg	%r14,0(%r15)
	brasl	%r14,kprint_hex
	lg	%r14,0(%r15)
	aghi	%r15,160
	lgr	%r0,%r2
L888:
# x86 @0x888: bf 00 00 00 00
	larl	%r2,__sec__rodata_str1_1
	aghi	%r2,3
L88d:
# x86 @0x88d: e8 6e f7 ff ff
	aghi	%r15,-160
	stg	%r14,0(%r15)
	brasl	%r14,kprint
	lg	%r14,0(%r15)
	aghi	%r15,160
	lgr	%r0,%r2
L892:
# x86 @0x892: bf 00 00 00 00
	larl	%r2,__sec__rodata_str1_1
	aghi	%r2,371
L897:
# x86 @0x897: e8 64 f7 ff ff
	aghi	%r15,-160
	stg	%r14,0(%r15)
	brasl	%r14,kprint
	lg	%r14,0(%r15)
	aghi	%r15,160
	lgr	%r0,%r2
L89c:
# x86 @0x89c: 89 ef
	lgr	%r2,%r9
L89e:
# x86 @0x89e: e8 ba f9 ff ff
	aghi	%r15,-160
	stg	%r14,0(%r15)
	brasl	%r14,kprint_hex
	lg	%r14,0(%r15)
	aghi	%r15,160
	lgr	%r0,%r2
L8a3:
# x86 @0x8a3: bf 00 00 00 00
	larl	%r2,__sec__rodata_str1_1
	aghi	%r2,37
L8a8:
# x86 @0x8a8: e8 53 f7 ff ff
	aghi	%r15,-160
	stg	%r14,0(%r15)
	brasl	%r14,kprint
	lg	%r14,0(%r15)
	aghi	%r15,160
	lgr	%r0,%r2
L8ad:
# x86 @0x8ad: bf 00 00 00 00
	lghi	%r2,0
L8b2:
# x86 @0x8b2: e9 fa fb ff ff
	j	L4b1
L8b7:
# x86 @0x8b7: 48 85 c0
	ltgr	%r1,%r0
L8ba:
# x86 @0x8ba: 0f 85 97 fb ff ff
	jne	L457
L8c0:
# x86 @0x8c0: bf 00 00 00 00
	larl	%r2,__sec__rodata_str1_1
	aghi	%r2,12
L8c5:
# x86 @0x8c5: e8 36 f7 ff ff
	aghi	%r15,-160
	stg	%r14,0(%r15)
	brasl	%r14,kprint
	lg	%r14,0(%r15)
	aghi	%r15,160
	lgr	%r0,%r2
L8ca:
# x86 @0x8ca: 89 df
	lgr	%r2,%r8
L8cc:
# x86 @0x8cc: e8 8c f9 ff ff
	aghi	%r15,-160
	stg	%r14,0(%r15)
	brasl	%r14,kprint_hex
	lg	%r14,0(%r15)
	aghi	%r15,160
	lgr	%r0,%r2
L8d1:
# x86 @0x8d1: bf 00 00 00 00
	larl	%r2,__sec__rodata_str1_1
	aghi	%r2,37
L8d6:
# x86 @0x8d6: e8 25 f7 ff ff
	aghi	%r15,-160
	stg	%r14,0(%r15)
	brasl	%r14,kprint
	lg	%r14,0(%r15)
	aghi	%r15,160
	lgr	%r0,%r2
L8db:
# x86 @0x8db: bf 00 00 00 00
	lghi	%r2,0
L8e0:
# x86 @0x8e0: e8 78 f9 ff ff
	aghi	%r15,-160
	stg	%r14,0(%r15)
	brasl	%r14,kprint_hex
	lg	%r14,0(%r15)
	aghi	%r15,160
	lgr	%r0,%r2
L8e5:
# x86 @0x8e5: bf 00 00 00 00
	larl	%r2,__sec__rodata_str1_1
	aghi	%r2,3
L8ea:
# x86 @0x8ea: e8 11 f7 ff ff
	aghi	%r15,-160
	stg	%r14,0(%r15)
	brasl	%r14,kprint
	lg	%r14,0(%r15)
	aghi	%r15,160
	lgr	%r0,%r2
L8ef:
# x86 @0x8ef: bf 00 00 00 00
	larl	%r2,__sec__rodata_str1_1
	aghi	%r2,371
L8f4:
# x86 @0x8f4: e8 07 f7 ff ff
	aghi	%r15,-160
	stg	%r14,0(%r15)
	brasl	%r14,kprint
	lg	%r14,0(%r15)
	aghi	%r15,160
	lgr	%r0,%r2
L8f9:
# x86 @0x8f9: bf 00 00 00 00
	lghi	%r2,0
L8fe:
# x86 @0x8fe: e8 5a f9 ff ff
	aghi	%r15,-160
	stg	%r14,0(%r15)
	brasl	%r14,kprint_hex
	lg	%r14,0(%r15)
	aghi	%r15,160
	lgr	%r0,%r2
L903:
# x86 @0x903: bf 00 00 00 00
	larl	%r2,__sec__rodata_str1_1
	aghi	%r2,37
L908:
# x86 @0x908: e8 f3 f6 ff ff
	aghi	%r15,-160
	stg	%r14,0(%r15)
	brasl	%r14,kprint
	lg	%r14,0(%r15)
	aghi	%r15,160
	lgr	%r0,%r2
L90d:
# x86 @0x90d: bf 00 00 00 00
	lghi	%r2,0
L912:
# x86 @0x912: e9 9a fb ff ff
	j	L4b1


	.data
	.globl __sec__data
__sec__data:
	.globl heap_brk
	.balign 8
heap_brk:
	.quad kheap
	.globl next_pid
	.balign 8
next_pid:
	.byte 0, 0, 0, 1
	.globl fib_b
	.balign 8
fib_b:
	.byte 0, 0, 0, 1
	.globl prime_n
	.balign 8
prime_n:
	.byte 0, 0, 0, 2
	.globl sum_n
	.balign 8
sum_n:
	.byte 0, 0, 0, 1
	.globl current_proc
	.balign 8
current_proc:
	.byte 255, 255, 255, 255
	.globl user_progs
	.balign 8
user_progs:
	.quad user_fibonacci
	.quad user_prime
	.quad user_sum

	.bss
	.globl __sec__bss
__sec__bss:
	.globl free_list
	.balign 8
free_list:
	.space 8
	.globl kheap
	.balign 8
kheap:
	.space 4096
	.globl proc_state
	.balign 8
proc_state:
	.space 32
	.globl proc_pid
	.balign 8
proc_pid:
	.space 32
	.globl proc_regs
	.balign 8
proc_regs:
	.space 128
	.globl proc_ticks
	.balign 8
proc_ticks:
	.space 32
	.globl fib_step
	.balign 8
fib_step:
	.space 4
	.globl fib_n
	.balign 8
fib_n:
	.space 4
	.globl fib_a
	.balign 8
fib_a:
	.space 4
	.globl fib_result
	.balign 8
fib_result:
	.space 4
	.globl prime_count
	.balign 8
prime_count:
	.space 4
	.globl prime_found
	.balign 8
prime_found:
	.space 4
	.globl sum_acc
	.balign 8
sum_acc:
	.space 4
	.globl sum_result
	.balign 8
sum_result:
	.space 4
	.globl total_ticks
	.balign 8
total_ticks:
	.space 4

	.section .rodata
	.globl __sec__rodata_str1_1
	.balign 8
__sec__rodata_str1_1:
	.byte 48, 120, 0, 10, 0, 44, 32, 80, 73, 68, 61, 0, 91, 73, 78, 73, 84, 93, 32, 65, 108, 108, 111, 99, 97, 116, 101, 100, 32, 54, 52, 66, 32, 97, 116, 32, 0, 32, 61, 32, 0, 91, 73, 78, 73, 84, 93, 32, 70, 114, 101, 101, 100, 32, 54, 52, 66, 32, 98, 108, 111, 99, 107, 10, 0, 91, 73, 78, 73, 84, 93, 32, 82, 101, 45, 97, 108, 108, 111, 99, 97, 116, 101, 100, 32, 51, 50, 66, 32, 97, 116, 32, 0, 32, 40, 115, 104, 111, 117, 108, 100, 32, 114, 101, 117, 115, 101, 32, 102, 114, 101, 101, 100, 32, 98, 108, 111, 99, 107, 41, 10, 0, 91, 84, 73, 67, 75, 32, 0, 93, 32, 80, 73, 68, 61, 0, 32, 40, 0, 70, 105, 98, 111, 110, 97, 99, 99, 105, 0, 41, 32, 70, 73, 78, 73, 83, 72, 69, 68, 46, 32, 0, 70, 105, 98, 40, 49, 50, 41, 61, 0, 80, 114, 105, 109, 101, 0, 108, 97, 115, 116, 32, 112, 114, 105, 109, 101, 61, 0, 83, 117, 109, 0, 115, 117, 109, 40, 49, 46, 46, 50, 48, 41, 61, 0, 32, 32, 32, 109, 105, 110, 105, 79, 83, 32, 75, 101, 114, 110, 101, 108, 32, 82, 101, 112, 111, 114, 116, 10, 0, 32, 32, 84, 111, 116, 97, 108, 32, 116, 105, 99, 107, 115, 58, 32, 32, 32, 32, 32, 0, 32, 32, 70, 105, 98, 111, 110, 97, 99, 99, 105, 58, 32, 32, 32, 32, 32, 32, 32, 70, 105, 98, 40, 49, 50, 41, 61, 0, 32, 32, 80, 114, 105, 109, 101, 32, 115, 101, 97, 114, 99, 104, 58, 32, 32, 32, 32, 0, 32, 112, 114, 105, 109, 101, 115, 32, 102, 111, 117, 110, 100, 44, 32, 108, 97, 115, 116, 61, 0, 32, 32, 83, 117, 109, 32, 49, 46, 46, 50, 48, 58, 32, 32, 32, 32, 32, 32, 32, 0, 32, 32, 72, 101, 97, 112, 32, 117, 115, 101, 100, 58, 32, 32, 32, 32, 32, 32, 32, 0, 32, 47, 32, 0, 32, 98, 121, 116, 101, 115, 10, 0, 91, 73, 78, 73, 84, 93, 32, 65, 108, 108, 111, 99, 97, 116, 101, 100, 32, 49, 50, 56, 66, 32, 97, 116, 32, 0


	.section .rodata
	.globl __sec__rodata_str1_8
	.balign 8
__sec__rodata_str1_8:
	.byte 61, 61, 61, 61, 61, 61, 61, 61, 61, 61, 61, 61, 61, 61, 61, 61, 61, 61, 61, 61, 61, 61, 61, 61, 61, 61, 61, 61, 61, 61, 61, 61, 61, 61, 61, 61, 61, 61, 61, 61, 10, 0, 0, 0, 0, 0, 0, 0, 32, 32, 32, 109, 105, 110, 105, 79, 83, 32, 75, 101, 114, 110, 101, 108, 32, 118, 49, 46, 48, 32, 32, 40, 120, 56, 54, 45, 62, 115, 51, 57, 48, 120, 41, 10, 0, 0, 0, 0, 32, 32, 32, 80, 115, 101, 117, 100, 111, 32, 79, 112, 101, 114, 97, 116, 105, 110, 103, 32, 83, 121, 115, 116, 101, 109, 32, 68, 101, 109, 111, 10, 0, 0, 0, 0, 0, 0, 0, 0, 61, 61, 61, 61, 61, 61, 61, 61, 61, 61, 61, 61, 61, 61, 61, 61, 61, 61, 61, 61, 61, 61, 61, 61, 61, 61, 61, 61, 61, 61, 61, 61, 61, 61, 61, 61, 61, 61, 61, 61, 10, 10, 0, 0, 0, 0, 0, 0, 91, 73, 78, 73, 84, 93, 32, 66, 111, 111, 116, 105, 110, 103, 32, 109, 105, 110, 105, 79, 83, 32, 107, 101, 114, 110, 101, 108, 46, 46, 46, 10, 0, 0, 0, 0, 0, 0, 0, 0, 91, 73, 78, 73, 84, 93, 32, 67, 114, 101, 97, 116, 101, 100, 32, 112, 114, 111, 99, 101, 115, 115, 101, 115, 58, 32, 80, 73, 68, 61, 0, 0, 91, 73, 78, 73, 84, 93, 32, 84, 101, 115, 116, 105, 110, 103, 32, 109, 101, 109, 111, 114, 121, 32, 97, 108, 108, 111, 99, 97, 116, 111, 114, 46, 46, 46, 10, 0, 0, 0, 0, 0, 91, 83, 72, 69, 76, 76, 93, 32, 83, 116, 97, 114, 116, 105, 110, 103, 32, 115, 99, 104, 101, 100, 117, 108, 101, 114, 32, 40, 114, 111, 117, 110, 100, 45, 114, 111, 98, 105, 110, 44, 32, 53, 32, 116, 105, 99, 107, 115, 47, 112, 114, 111, 99, 41, 46, 46, 46, 10, 10, 0, 0, 0, 0, 0, 32, 32, 80, 114, 111, 99, 101, 115, 115, 101, 115, 58, 32, 32, 32, 32, 32, 32, 32, 51, 32, 99, 114, 101, 97, 116, 101, 100, 44, 32, 51, 32, 99, 111, 109, 112, 108, 101, 116, 101, 100, 10, 0, 0, 0, 0, 0, 0, 91, 75, 69, 82, 78, 69, 76, 93, 32, 83, 121, 115, 116, 101, 109, 32, 104, 97, 108, 116, 101, 100, 46, 32, 71, 111, 111, 100, 98, 121, 101, 46, 10, 10, 0


	.section .rodata
	.globl __sec__rodata
	.balign 8
__sec__rodata:
	.byte 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0

