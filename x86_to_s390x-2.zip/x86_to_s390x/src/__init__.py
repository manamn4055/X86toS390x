"""x86-64 转 s390x 静态翻译器。"""
from .registers import RegisterMap, X86_TO_S390X, SCRATCH_S390X
from .x86.decoder import decode, decode_one, Instruction, DecodeError
from .s390x import encoder
from .translator import translate, translate_bytes, TranslateError
from . import elf

__all__ = [
    "RegisterMap", "X86_TO_S390X", "SCRATCH_S390X",
    "decode", "decode_one", "Instruction", "DecodeError",
    "encoder", "translate", "translate_bytes", "TranslateError", "elf",
]
