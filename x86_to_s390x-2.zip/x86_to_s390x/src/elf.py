"""x86-64 -> s390x 翻译器的 ELF 处理。

两个职责：

1. **读 x86-64 ``.o``**（gcc -c 产出）：提取 ``.text`` 字节、符号表
   （函数名 + 地址 + 大小）、重定位（用于把 RIP 相对引用解析成符号名）。

2. **生成 s390x 静态可执行文件**：把翻译后的汇编用
   ``s390x-linux-gnu-as`` 汇编，再用一个调用 ``main`` 并 ``svc`` 退出的
   小 ``_start`` 桩链接。

翻译器发出的占位符（``CALL 0x<addr>``、``RIP_ld64 ...``）由本模块改写成
引用正确符号的真实 s390x 指令。
"""

import os
import struct
import subprocess
import tempfile


def _byte_swap_le_to_be(raw, total_size):
    """小端数据转大端。

    标量（1/2/4/8 字节）整体反转。
    大小是 4 的倍数且 > 8 的，按 4 字节 int 元素逐个交换。
    其它（如长度 15 的字符串、字节数组）保持不变——字节数组无字节序。
    """
    if total_size in (1, 2, 4, 8):
        # 标量：整体反转
        return bytes(reversed(raw))
    if total_size > 8 and total_size % 4 == 0:
        # 看起来是 int[]：按 4 字节块交换
        out = bytearray()
        for i in range(0, len(raw), 4):
            chunk = raw[i:i + 4]
            out.extend(reversed(chunk))
        return bytes(out)
    # 字节数组 / 字符串 / 填充结构体：原样
    return bytes(raw)


# ---------------------------------------------------------------------------
# x86-64 .o 解析
# ---------------------------------------------------------------------------

class X86Symbol:
    __slots__ = ("name", "value", "size", "section", "is_func", "is_global")

    def __init__(self, name, value, size, section, is_func, is_global):
        self.name = name
        self.value = value
        self.size = size
        self.section = section
        self.is_func = is_func
        self.is_global = is_global

    def __repr__(self):
        return "<%s value=0x%x size=%d func=%s>" % (
            self.name, self.value, self.size, self.is_func)


class X86Reloc:
    __slots__ = ("offset", "type", "symbol", "addend")

    def __init__(self, offset, rtype, symbol, addend):
        self.offset = offset      # 节内偏移
        self.type = rtype         # R_X86_64_* 类型号
        self.symbol = symbol      # 符号名（字符串）
        self.addend = addend

    def __repr__(self):
        return "<Reloc off=0x%x type=%d sym=%s addend=%d>" % (
            self.offset, self.type, self.symbol, self.addend)


class X86ObjectFile:
    """x86-64 ELF64 可重定位对象的最小解析器。"""

    def __init__(self, path):
        self.path = path
        with open(path, "rb") as f:
            self.data = f.read()
        self.symbols = []        # X86Symbol 列表
        self.text_bytes = b""
        self.text_addr = 0       # .o 里通常为 0
        self.relocs = []         # .text 内的 X86Reloc 列表
        self._parse()

    def _parse(self):
        d = self.data
        if d[:4] != b"\x7fELF":
            raise ValueError("not an ELF file: %s" % self.path)
        if d[4] != 2:
            raise ValueError("only ELF64 supported")
        # 节头表
        e_shoff = struct.unpack_from("<Q", d, 0x28)[0]
        e_shentsize = struct.unpack_from("<H", d, 0x3a)[0]
        e_shnum = struct.unpack_from("<H", d, 0x3c)[0]
        e_shstrndx = struct.unpack_from("<H", d, 0x3e)[0]
        sections = []
        for i in range(e_shnum):
            off = e_shoff + i * e_shentsize
            sh_name = struct.unpack_from("<I", d, off)[0]
            sh_type = struct.unpack_from("<I", d, off + 4)[0]
            sh_flags = struct.unpack_from("<Q", d, off + 8)[0]
            sh_addr = struct.unpack_from("<Q", d, off + 0x10)[0]
            sh_offset = struct.unpack_from("<Q", d, off + 0x18)[0]
            sh_size = struct.unpack_from("<Q", d, off + 0x20)[0]
            sh_link = struct.unpack_from("<I", d, off + 0x28)[0]
            sh_info = struct.unpack_from("<I", d, off + 0x2c)[0]
            sh_entsize = struct.unpack_from("<Q", d, off + 0x38)[0]
            sections.append({
                "name_off": sh_name, "type": sh_type, "flags": sh_flags,
                "addr": sh_addr, "offset": sh_offset, "size": sh_size,
                "link": sh_link, "info": sh_info, "entsize": sh_entsize,
            })
        # 节名字符串表
        shstr = sections[e_shstrndx]
        shstr_data = d[shstr["offset"]:shstr["offset"] + shstr["size"]]
        for s in sections:
            end = shstr_data.index(b"\x00", s["name_off"])
            s["name"] = shstr_data[s["name_off"]:end].decode()
        # 找 .text、.symtab、.strtab、.rela.text
        text_sec = None
        symtab_sec = None
        strtab_sec = None
        rela_text_sec = None
        for s in sections:
            if s["name"] == ".text":
                text_sec = s
            elif s["name"] == ".symtab":
                symtab_sec = s
            elif s["name"] == ".strtab":
                strtab_sec = s
            elif s["name"] == ".rela.text":
                rela_text_sec = s
        if text_sec is None:
            raise ValueError("no .text section")
        self.text_bytes = d[text_sec["offset"]:text_sec["offset"] + text_sec["size"]]
        self.text_addr = text_sec["addr"]
        # 符号
        if symtab_sec and strtab_sec:
            strtab = d[strtab_sec["offset"]:strtab_sec["offset"] + strtab_sec["size"]]
            n = symtab_sec["size"] // 24
            for i in range(n):
                off = symtab_sec["offset"] + i * 24
                st_name = struct.unpack_from("<I", d, off)[0]
                st_info = d[off + 4]
                st_other = d[off + 5]
                st_shndx = struct.unpack_from("<H", d, off + 6)[0]
                st_value = struct.unpack_from("<Q", d, off + 8)[0]
                st_size = struct.unpack_from("<Q", d, off + 16)[0]
                if st_name == 0:
                    name = ""
                else:
                    end = strtab.index(b"\x00", st_name)
                    name = strtab[st_name:end].decode()
                is_func = (st_info & 0xF) == 2  # STT_FUNC
                is_global = (st_info >> 4) == 1  # STB_GLOBAL
                # st_shndx：符号所在节索引。0xfff1 = SHN_ABS
                self.symbols.append(X86Symbol(name, st_value, st_size,
                                              st_shndx, is_func, is_global))
        # .text 的重定位（RELA）
        if rela_text_sec:
            symtab = self.symbols
            n = rela_text_sec["size"] // 24
            for i in range(n):
                off = rela_text_sec["offset"] + i * 24
                r_offset = struct.unpack_from("<Q", d, off)[0]
                r_info = struct.unpack_from("<Q", d, off + 8)[0]
                r_addend = struct.unpack_from("<q", d, off + 16)[0]
                sym_idx = r_info >> 32
                rtype = r_info & 0xFFFFFFFF
                sym_name = symtab[sym_idx].name if sym_idx < len(symtab) else ""
                self.relocs.append(X86Reloc(r_offset, rtype, sym_name, r_addend))

    def functions(self):
        """返回函数符号列表（按地址排序）。"""
        funcs = [s for s in self.symbols if s.is_func and s.size > 0
                 and s.name and not s.name.startswith("_")]
        funcs.sort(key=lambda s: s.value)
        return funcs

    def globals_data(self):
        """返回全局数据的 (name, value, size, is_bss) 元组。

        已初始化全局变量来自 ``.data`` / ``.rodata``（带原始字节）。
        零初始化全局变量在 ``.bss``（无文件字节；我们发 ``.space``）。
        ``is_bss=True`` 标记这类。
        """
        d = self.data
        e_shoff = struct.unpack_from("<Q", d, 0x28)[0]
        e_shentsize = struct.unpack_from("<H", d, 0x3a)[0]
        e_shnum = struct.unpack_from("<H", d, 0x3c)[0]
        e_shstrndx = struct.unpack_from("<H", d, 0x3e)[0]
        sections = []
        for i in range(e_shnum):
            off = e_shoff + i * e_shentsize
            s = {
                "name_off": struct.unpack_from("<I", d, off)[0],
                "type": struct.unpack_from("<I", d, off + 4)[0],
                "offset": struct.unpack_from("<Q", d, off + 0x18)[0],
                "size": struct.unpack_from("<Q", d, off + 0x20)[0],
                "addr": struct.unpack_from("<Q", d, off + 0x10)[0],
            }
            sections.append(s)
        shstr = sections[e_shstrndx]
        shstr_data = d[shstr["offset"]:shstr["offset"] + shstr["size"]]
        for s in sections:
            end = shstr_data.index(b"\x00", s["name_off"])
            s["name"] = shstr_data[s["name_off"]:end].decode()
        out = []
        for sym in self.symbols:
            if not sym.name or sym.size == 0:
                continue
            if sym.section < 0 or sym.section >= len(sections):
                continue
            sec = sections[sym.section]
            if sec["name"] in (".data", ".rodata"):
                data_off = sec["offset"] + sym.value
                out.append((sym.name,
                            d[data_off:data_off + sym.size],
                            sym.size, False))
            elif sec["name"] == ".bss":
                out.append((sym.name, b"", sym.size, True))
        return out


# ---------------------------------------------------------------------------
# s390x ELF 生成
# ---------------------------------------------------------------------------

# RIP 相对 x86 地址（指令末尾 + disp）-> 引用符号 的映射。
# 由调用方用对象文件的重定位构建，传入 rewrite_placeholders()。


def rewrite_placeholders(asm_lines, x86_obj, text_base_addr):
    """把 CALL / RIP_* 占位符行改写成真实 s390x 指令。

    占位符编码包含重定位字段的 .o 文本偏移范围：
      * ``CALL 0x<off>`` -- off 是 call 的 rel32 字段偏移
        （即 call 指令地址 + 1）。
      * ``RIP_<kind>\t<reg>\t0x<insn_addr>\t0x<insn_len>`` -- disp32 字段
        在 ``[insn_addr, insn_addr + insn_len)`` 内某处。

    扫描重定位表找落在此范围的重定位，再发引用该符号的真实 s390x 指令。

    子字加载（RIP_zld8 / RIP_zld16 / RIP_sld8 / RIP_sld16）按**符号真实大小**
    选加载宽度，保证大端字节位置正确：
      * ``char``（size=1）用 ``llgc``（偏移 0 处 1 字节）。
      * ``int``（size=4）当字节读时用 ``l``（4 字节），再用 ``llgcr``
        提取低位（寄存器操作）。
    """
    relocs = x86_obj.relocs

    def _find_sym_in_range(insn_addr, insn_len):
        """找重定位偏移在 [insn_addr, insn_addr + insn_len) 内的符号。"""
        for r in relocs:
            if insn_addr <= r.offset < insn_addr + insn_len:
                return r.symbol
        return None

    def _find_sym_exact(off):
        for r in relocs:
            if r.offset == off:
                return r.symbol
        return None

    def _find_sym_size(sym_name):
        """从符号表查符号大小。"""
        for s in x86_obj.symbols:
            if s.name == sym_name:
                return s.size
        return 0

    out = []
    for line in asm_lines:
        if line.startswith("CALL\t"):
            off = int(line.split("\t")[1], 16)
            sym = _find_sym_exact(off)
            if sym is None:
                raise ValueError("cannot resolve call reloc at .text+0x%x" % off)
            out.append("\tbrasl\t%%r14,%s" % sym)
            continue
        if line.startswith("MOV_IMM32\t"):
            # mov $imm32, %reg，可能带 R_X86_64_32 重定位。
            # 范围内有重定位则发 larl 加载符号地址；否则发立即数值。
            parts = line.split("\t")
            reg_target = parts[1]                  # %rN
            insn_addr = int(parts[2], 16)
            insn_len = int(parts[3], 16)
            imm_val = int(parts[4])
            sym = _find_sym_in_range(insn_addr, insn_len)
            if sym is not None:
                out.append("\tlarl\t%s,%s" % (reg_target, sym))
            else:
                # 无重定位：加载 32 位立即数
                if -0x8000 <= imm_val <= 0x7FFF:
                    out.append("\tlghi\t%s,%d" % (reg_target, imm_val))
                else:
                    out.append("\tlgfi\t%s,%d" % (reg_target, imm_val & 0xFFFFFFFF))
            continue
        if line.startswith("RIP_"):
            parts = line.split("\t")
            kind = parts[0]  # RIP_ld64 / RIP_st64 / ...
            reg_target = parts[1]            # %rN
            insn_addr = int(parts[2], 16)    # 指令起始的 .o 文本偏移
            insn_len = int(parts[3], 16)     # 指令长度
            sym = _find_sym_in_range(insn_addr, insn_len)
            if sym is None:
                raise ValueError("cannot resolve RIP reloc at .text+0x%x (range +0x%x)"
                                 % (insn_addr, insn_len))

            # 子字加载：按符号真实大小选加载指令，保证大端字节位置正确
            if kind in ("RIP_zld8", "RIP_sld8", "RIP_zld16", "RIP_sld16"):
                sz = _find_sym_size(sym)
                out.append("\tlarl\t%%r1,%s" % sym)
                if kind == "RIP_zld8":
                    # 字节零扩展加载（movzbl）
                    if sz <= 1:
                        out.append("\tllgc\t%s,0(%%r1)" % reg_target)
                    elif sz == 2:
                        out.append("\tllgh\t%s,0(%%r1)" % reg_target)
                        out.append("\tllgcr\t%s,%s" % (reg_target, reg_target))
                    elif sz == 4:
                        out.append("\tl\t%s,0(%%r1)" % reg_target)
                        out.append("\tllgcr\t%s,%s" % (reg_target, reg_target))
                    else:  # 8
                        out.append("\tlg\t%s,0(%%r1)" % reg_target)
                        out.append("\tllgcr\t%s,%s" % (reg_target, reg_target))
                elif kind == "RIP_sld8":
                    # 字节符号扩展加载（movsbl）
                    if sz <= 1:
                        out.append("\tllgc\t%s,0(%%r1)" % reg_target)
                    elif sz == 2:
                        out.append("\tllgh\t%s,0(%%r1)" % reg_target)
                    elif sz == 4:
                        out.append("\tl\t%s,0(%%r1)" % reg_target)
                    else:
                        out.append("\tlg\t%s,0(%%r1)" % reg_target)
                    out.append("\tlgbr\t%s,%s" % (reg_target, reg_target))
                elif kind == "RIP_zld16":
                    # 半字零扩展加载（movzwl）
                    if sz <= 2:
                        out.append("\tllgh\t%s,0(%%r1)" % reg_target)
                    elif sz == 4:
                        out.append("\tl\t%s,0(%%r1)" % reg_target)
                        out.append("\tllghr\t%s,%s" % (reg_target, reg_target))
                    else:
                        out.append("\tlg\t%s,0(%%r1)" % reg_target)
                        out.append("\tllghr\t%s,%s" % (reg_target, reg_target))
                elif kind == "RIP_sld16":
                    # 半字符号扩展加载（movswl）
                    if sz <= 2:
                        out.append("\tllgh\t%s,0(%%r1)" % reg_target)
                    elif sz == 4:
                        out.append("\tl\t%s,0(%%r1)" % reg_target)
                    else:
                        out.append("\tlg\t%s,0(%%r1)" % reg_target)
                    out.append("\tlghr\t%s,%s" % (reg_target, reg_target))
                continue

            if kind == "RIP_lea":
                out.append("\tlarl\t%s,%s" % (reg_target, sym))
            elif kind == "RIP_ld64":
                out.append("\tlarl\t%%r1,%s" % sym)
                out.append("\tlg\t%s,0(%%r1)" % reg_target)
            elif kind == "RIP_st64":
                out.append("\tlarl\t%%r1,%s" % sym)
                out.append("\tstg\t%s,0(%%r1)" % reg_target)
            elif kind == "RIP_ld32":
                out.append("\tlarl\t%%r1,%s" % sym)
                out.append("\tl\t%s,0(%%r1)" % reg_target)
            elif kind == "RIP_st32":
                out.append("\tlarl\t%%r1,%s" % sym)
                out.append("\tst\t%s,0(%%r1)" % reg_target)
            elif kind == "RIP_ld8":
                out.append("\tlarl\t%%r1,%s" % sym)
                out.append("\tllgc\t%s,0(%%r1)" % reg_target)
            elif kind == "RIP_st8":
                out.append("\tlarl\t%%r1,%s" % sym)
                out.append("\tstc\t%s,0(%%r1)" % reg_target)
            elif kind == "RIP_ld16":
                out.append("\tlarl\t%%r1,%s" % sym)
                out.append("\tllgh\t%s,0(%%r1)" % reg_target)
            elif kind == "RIP_st16":
                out.append("\tlarl\t%%r1,%s" % sym)
                out.append("\tsth\t%s,0(%%r1)" % reg_target)
            else:
                raise ValueError("unknown RIP kind: %s" % kind)
            continue
        out.append(line)
    return out


def build_executable(asm_text, globals_data, output_path, as_path="s390x-linux-gnu-as",
                     ld_path="s390x-linux-gnu-ld"):
    """汇编 + 链接一个静态 s390x ELF 可执行文件。

    ``asm_text`` 是完整 s390x 汇编源（字符串）。``globals_data`` 是已初始化
    全局变量的 (name, bytes, size) 列表，据此发 ``.data`` 节。
    前置一个 ``_start`` 桩：建栈、调用 ``main``、用 ``svc`` 退出。
    """
    # _start 桩：s390x Linux 上内核设 r2 = argc, r3 = argv。
    # 我们忽略参数，调用 main，再 exit(r2)。
    # s390x 系统调用 ABI：调用号在 r1，参数在 r2-r7，返回值在 r2。
    # SYS_exit = 1。
    stub = """
\t.text
\t.globl _start
_start:
\t# 建栈帧（s390x ABI 要求 r15 对齐 8，且被调用方需 160 字节保存区）
\taghi\t%r15,-160
\t# main() 返回 int 在 r2；掩到 8 位作退出码
\tbrasl\t%r14,main
\tnill\t%r2,255
\t# exit(r2)：调用号 1 放 r1，参数（退出码）留在 r2
\tlghi\t%r1,1
\tsvc\t0
"""
    # 已初始化全局放 .data，零初始化放 BSS。
    # x86-64 小端；s390x 大端。标量全局数据做字节交换。
    # 数组按元素交换（假定 4 字节 int 元素，常见情况）。
    data_section = "\n\t.data\n"
    bss_section = "\n\t.bss\n"
    has_data = False
    has_bss = False
    for entry in globals_data:
        name, raw, size = entry[0], entry[1], entry[2]
        is_bss = entry[3] if len(entry) > 3 else False
        if is_bss:
            bss_section += "\t.globl %s\n" % name
            bss_section += "\t.balign 8\n"
            bss_section += "%s:\n" % name
            bss_section += "\t.space %d\n" % size
            has_bss = True
        else:
            data_section += "\t.globl %s\n" % name
            data_section += "\t.balign 8\n"
            data_section += "%s:\n" % name
            if raw:
                swapped = _byte_swap_le_to_be(raw, size)
                data_section += "\t.byte " + ", ".join(str(b) for b in swapped) + "\n"
            else:
                data_section += "\t.space %d\n" % size
            has_data = True
    sections_text = ""
    if has_data:
        sections_text += data_section
    if has_bss:
        sections_text += bss_section
    full = stub + "\n" + asm_text + sections_text + "\n"

    with tempfile.TemporaryDirectory() as td:
        asm_path = os.path.join(td, "out.s")
        obj_path = os.path.join(td, "out.o")
        with open(asm_path, "w") as f:
            f.write(full)
        # 汇编
        r = subprocess.run([as_path, "-m64", "-o", obj_path, asm_path],
                           capture_output=True, text=True)
        if r.returncode != 0:
            raise RuntimeError("s390x-as failed:\n%s\n--- source ---\n%s"
                               % (r.stderr, full))
        # 链接为静态可执行文件
        ld_args = [ld_path, "-m", "elf64_s390", "-o", output_path, obj_path]
        r = subprocess.run(ld_args, capture_output=True, text=True)
        if r.returncode != 0:
            raise RuntimeError("s390x-ld failed:\n%s" % r.stderr)
    return output_path
