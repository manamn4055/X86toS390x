"""s390x 汇编文本生成器。

翻译器输出 s390x 汇编文本（不是机器码），交给 s390x-linux-gnu-as 汇编。
这里每个函数返回一行汇编。
"""


def _r(i):
    return "%%r%d" % i


def _mem(base, disp=0, index=None):
    if index is not None:
        return "%d(%s,%s)" % (disp, _r(base), _r(index))
    return "%d(%s)" % (disp, _r(base))


# ---------- 加载 / 存储 ----------

def lg(dst, base, disp=0, index=None):
    """64 位加载。"""
    return "lg\t%s,%s" % (_r(dst), _mem(base, disp, index))


def stg(src, base, disp=0, index=None):
    """64 位存储。"""
    return "stg\t%s,%s" % (_r(src), _mem(base, disp, index))


def l(dst, base, disp=0, index=None):
    """32 位加载。"""
    return "l\t%s,%s" % (_r(dst), _mem(base, disp, index))


def st(src, base, disp=0, index=None):
    """32 位存储。"""
    return "st\t%s,%s" % (_r(src), _mem(base, disp, index))


def llgc(dst, base, disp=0, index=None):
    """8 位零扩展加载。"""
    return "llgc\t%s,%s" % (_r(dst), _mem(base, disp, index))


def llgh(dst, base, disp=0, index=None):
    """16 位零扩展加载。"""
    return "llgh\t%s,%s" % (_r(dst), _mem(base, disp, index))


def stc(src, base, disp=0, index=None):
    """8 位存储。"""
    return "stc\t%s,%s" % (_r(src), _mem(base, disp, index))


def sth(src, base, disp=0, index=None):
    """16 位存储。"""
    return "sth\t%s,%s" % (_r(src), _mem(base, disp, index))


def sty(src, base, disp, index=None):
    """32 位存储（20 位位移）。"""
    return "sty\t%s,%s" % (_r(src), _mem(base, disp, index))


def ly(dst, base, disp, index=None):
    """32 位加载（20 位位移）。"""
    return "ly\t%s,%s" % (_r(dst), _mem(base, disp, index))


def la(dst, base, disp=0, index=None):
    """计算地址。"""
    return "la\t%s,%s" % (_r(dst), _mem(base, disp, index))


def lay(dst, base, disp, index=None):
    """计算地址（20 位位移）。"""
    return "lay\t%s,%s" % (_r(dst), _mem(base, disp, index))


# ---------- 寄存器传送 ----------

def lgr(dst, src):
    return "lgr\t%s,%s" % (_r(dst), _r(src))


def lghi(dst, imm):
    return "lghi\t%s,%d" % (_r(dst), imm)


def lgfi(dst, imm):
    return "lgfi\t%s,%d" % (_r(dst), imm & 0xFFFFFFFF)


def llill(dst, imm):
    return "llill\t%s,%d" % (_r(dst), imm & 0xFFFF)


def llilf(dst, imm):
    return "llilf\t%s,%d" % (_r(dst), imm & 0xFFFFFFFF)


def llihf(dst, imm):
    return "llihf\t%s,%d" % (_r(dst), imm & 0xFFFFFFFF)


# ---------- 算术 ----------

def agr(dst, src):
    return "agr\t%s,%s" % (_r(dst), _r(src))


def ar(dst, src):
    """32 位加。"""
    return "ar\t%s,%s" % (_r(dst), _r(src))


def sgr(dst, src):
    return "sgr\t%s,%s" % (_r(dst), _r(src))


def sr(dst, src):
    """32 位减。"""
    return "sr\t%s,%s" % (_r(dst), _r(src))


def msgr(dst, src):
    return "msgr\t%s,%s" % (_r(dst), _r(src))


def msr(dst, src):
    """32 位乘。"""
    return "msr\t%s,%s" % (_r(dst), _r(src))


def aghi(dst, imm):
    return "aghi\t%s,%d" % (_r(dst), imm)


def ahi(dst, imm):
    return "ahi\t%s,%d" % (_r(dst), imm)


def agfi(dst, imm):
    """64 位加立即数。"""
    return "agfi\t%s,%d" % (_r(dst), imm)


def afi(dst, imm):
    """32 位加立即数。"""
    return "afi\t%s,%d" % (_r(dst), imm)


def sgfi(dst, imm):
    """64 位减立即数。"""
    return "sgfi\t%s,%d" % (_r(dst), imm)


def sfi(dst, imm):
    """32 位减立即数。"""
    return "sfi\t%s,%d" % (_r(dst), imm)


def msgfi(dst, imm):
    """64 位乘立即数。"""
    return "msgfi\t%s,%d" % (_r(dst), imm)


def xgr(dst, src):
    return "xgr\t%s,%s" % (_r(dst), _r(src))


def xr(dst, src):
    """32 位异或。"""
    return "xr\t%s,%s" % (_r(dst), _r(src))


def ngr(dst, src):
    return "ngr\t%s,%s" % (_r(dst), _r(src))


def nr(dst, src):
    """32 位与。"""
    return "nr\t%s,%s" % (_r(dst), _r(src))


def ogr(dst, src):
    return "ogr\t%s,%s" % (_r(dst), _r(src))


def or_(dst, src):
    """32 位或（or 是关键字，用 or_）。"""
    return "or\t%s,%s" % (_r(dst), _r(src))


def cgr(dst, src):
    return "cgr\t%s,%s" % (_r(dst), _r(src))


def cr(dst, src):
    return "cr\t%s,%s" % (_r(dst), _r(src))


def cgfi(dst, imm):
    return "cgfi\t%s,%d" % (_r(dst), imm)


def cfi(dst, imm):
    return "cfi\t%s,%d" % (_r(dst), imm)


def lcgr(dst, src):
    return "lcgr\t%s,%s" % (_r(dst), _r(src))


# ---------- 扩展 ----------

def llgcr(dst, src):
    """8 位零扩展（movzbl）。"""
    return "llgcr\t%s,%s" % (_r(dst), _r(src))


def llghr(dst, src):
    """16 位零扩展（movzwl）。"""
    return "llghr\t%s,%s" % (_r(dst), _r(src))


def lgbr(dst, src):
    """8 位符号扩展（movsbl）。"""
    return "lgbr\t%s,%s" % (_r(dst), _r(src))


def lghr(dst, src):
    """16 位符号扩展（movswl）。"""
    return "lghr\t%s,%s" % (_r(dst), _r(src))


def lgfr(dst, src):
    """32 位符号扩展（movslq）。"""
    return "lgfr\t%s,%s" % (_r(dst), _r(src))


# ---------- 移位 ----------

def sllg(dst, src, count):
    """64 位逻辑左移。"""
    return "sllg\t%s,%s,%d" % (_r(dst), _r(src), count)


def sll(dst, count):
    """32 位逻辑左移。"""
    return "sll\t%s,%d" % (_r(dst), count)


def srlg(dst, src, count):
    """64 位逻辑右移。"""
    return "srlg\t%s,%s,%d" % (_r(dst), _r(src), count)


def srl(dst, count):
    """32 位逻辑右移。"""
    return "srl\t%s,%d" % (_r(dst), count)


def srag(dst, src, count):
    """64 位算术右移。"""
    return "srag\t%s,%s,%d" % (_r(dst), _r(src), count)


def sra(dst, count):
    """32 位算术右移。"""
    return "sra\t%s,%d" % (_r(dst), count)


def sllgr(dst, src):
    """64 位寄存器逻辑左移。"""
    return "sllgr\t%s,%s" % (_r(dst), _r(src))


def srlgr(dst, src):
    """64 位寄存器逻辑右移。"""
    return "srlgr\t%s,%s" % (_r(dst), _r(src))


def sragr(dst, src):
    """64 位寄存器算术右移。"""
    return "sragr\t%s,%s" % (_r(dst), _r(src))


# ---------- 比较 / 测试 ----------

def ltgr(dst, src):
    """加载并测试 64 位（类似 TEST）。"""
    return "ltgr\t%s,%s" % (_r(dst), _r(src))


def ltr(dst, src):
    """加载并测试 32 位。"""
    return "ltr\t%s,%s" % (_r(dst), _r(src))


# ---------- 控制流 ----------

def brasl(link, label):
    """相对调用。"""
    return "brasl\t%s,%s" % (_r(link), label)


def basr(link, target_reg):
    """间接调用。"""
    return "basr\t%s,%s" % (_r(link), _r(target_reg))


def br(reg):
    """寄存器跳转（返回）。"""
    return "br\t%s" % _r(reg)


def j(label):
    """无条件跳转。"""
    return "j\t%s" % label


def jg(label):
    """j 的别名。"""
    return "jg\t%s" % label


# 条件跳转掩码 -> s390x 助记符。
_JCC_MASK = {
    0x1: "jo",    # CC3
    0x2: "jh",    # CC2
    0x3: "jnle",  # CC2|CC3
    0x4: "jl",    # CC1
    0x6: "jlh",   # CC1|CC2
    0x7: "jne",   # CC1|CC2|CC3
    0x8: "je",    # CC0
    0xA: "jhe",   # CC0|CC2
    0xB: "jnl",   # CC0|CC2|CC3 (jge)
    0xC: "jle",   # CC0|CC1
    0xD: "jnh",   # CC0|CC1|CC3 (jbe)
    0xE: "jno",   # CC0|CC1|CC2
    0xF: "j",     # 无条件
}


def jcc(mask, label):
    """按掩码条件跳转。"""
    return "%s\t%s" % (_JCC_MASK[mask & 0xF], label)


def nop():
    return "nop\t0"


# ---------- 栈 ----------

def aghi_sp(imm):
    return "aghi\t%%r15,%d" % imm


def la_sp(dst, disp):
    return "la\t%s,%d(%%r15)" % (_r(dst), disp)


# ---------- 标签与指令 ----------

def label(name):
    return "%s:" % name


def global_sym(name):
    return ".globl\t%s" % name


def comment(text):
    return "# %s" % text
