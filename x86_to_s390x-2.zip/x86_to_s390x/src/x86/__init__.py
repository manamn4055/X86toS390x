"""x86-64 解码子包。"""
from .decoder import decode, decode_one, Instruction, DecodeError, REG_NAMES

__all__ = ["decode", "decode_one", "Instruction", "DecodeError", "REG_NAMES"]
