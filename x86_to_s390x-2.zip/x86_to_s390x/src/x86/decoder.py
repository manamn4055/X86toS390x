"""x86-64 指令解码器。

解码 gcc -O1 产生的 x86-64 子集，供翻译器生成 s390x 分支。
支持寄存器操作数和内存操作数，以及 call/jmp/jcc 控制流。

内存操作数是一个 dict：
    {"kind": "mem", "base": <reg or None>, "index": <reg or None>,
     "scale": 1|2|4|8, "disp": <int>, "rip": bool}

rip=True 表示 RIP 相对寻址（访问全局变量），由 ELF 层用重定位解析。
"""

REG_NAMES = [
    "rax", "rcx", "rdx", "rbx", "rsp", "rbp", "rsi", "rdi",
    "r8",  "r9",  "r10", "r11", "r12", "r13", "r14", "r15",
]


class DecodeError(Exception):
    pass


class Instruction:
    __slots__ = ("mnemonic", "dst", "src", "raw", "addr", "operands",
                 "imm", "target")

    def __init__(self, mnemonic, raw, addr, dst=None, src=None,
                 operands=None, imm=None, target=None):
        self.mnemonic = mnemonic
        self.dst = dst
        self.src = src
        self.raw = raw
        self.addr = addr
        # 单操作数指令用（inc/dec/neg/not/jmp）
        self.operands = operands
        # 立即数（mov $imm,reg 等用 dst/src）
        self.imm = imm
        # 跳转目标 x86 地址
        self.target = target

    def __repr__(self):
        return "<x86 %s @0x%x>" % (self.mnemonic, self.addr)


def _reg(idx):
    return {"kind": "reg", "reg": idx}


def _mem(base=None, index=None, scale=1, disp=0, rip=False):
    return {"kind": "mem", "base": base, "index": index,
            "scale": scale, "disp": disp, "rip": rip}


def _imm(value, size):
    return {"kind": "imm", "value": value, "size": size}


def _read_imm(buf, pos, nbytes, signed=True):
    if pos + nbytes > len(buf):
        raise DecodeError("truncated immediate")
    raw = buf[pos:pos + nbytes]
    pos += nbytes
    return int.from_bytes(raw, "little", signed=signed), pos


def _parse_modrm(buf, pos, rex_b, rex_x, rex_r, addr_size=8):
    """解析 ModRM（+可选 SIB + 位移）。

    返回 (reg_field, rm_operand, next_pos)，rm_operand 是寄存器 dict
    （mod==11）或内存 dict。
    """
    if pos >= len(buf):
        raise DecodeError("truncated ModRM")
    modrm = buf[pos]
    pos += 1
    mod = (modrm >> 6) & 0x3
    reg = (modrm >> 3) & 0x7
    rm = modrm & 0x7
    reg |= (rex_r << 3)

    if mod == 0x3:
        rm |= (rex_b << 3)
        return reg, _reg(rm), pos

    # 内存操作数：解析 base/index/disp
    base = None
    index = None
    scale = 1
    disp = 0

    if rm == 4:
        # 跟一个 SIB 字节
        if pos >= len(buf):
            raise DecodeError("truncated SIB")
        sib = buf[pos]
        pos += 1
        ss = (sib >> 6) & 0x3
        idx_field = (sib >> 3) & 0x7
        bse_field = sib & 0x7
        scale = 1 << ss
        if idx_field != 4:  # 4 表示无 index（即便有 REX.X）
            index = idx_field | (rex_x << 3)
        if bse_field == 5 and mod == 0:
            # 特例：mod=0 base=5 -> 只有 disp32，无 base
            disp, pos = _read_imm(buf, pos, 4, signed=True)
        else:
            base = bse_field | (rex_b << 3)
    elif rm == 5 and mod == 0:
        # RIP 相对寻址
        disp, pos = _read_imm(buf, pos, 4, signed=True)
        return reg, _mem(disp=disp, rip=True), pos
    else:
        base = rm | (rex_b << 3)

    if mod == 1:
        d, pos = _read_imm(buf, pos, 1, signed=True)
        disp += d
    elif mod == 2:
        d, pos = _read_imm(buf, pos, 4, signed=True)
        disp += d
    return reg, _mem(base=base, index=index, scale=scale, disp=disp), pos


# ALU reg-reg/reg-mem 助记符（MR 和 RM 两种形式）
_ALU_MR = {0x01: "add", 0x29: "sub", 0x31: "xor", 0x21: "and",
           0x09: "or",  0x39: "cmp"}
_ALU_RM = {0x03: "add", 0x2B: "sub", 0x33: "xor", 0x23: "and",
           0x0B: "or",  0x3B: "cmp"}
# Group-1 立即数子操作码（0x81/0x83）
_GRP1 = {0: "add", 1: "or", 4: "and", 5: "sub", 6: "xor", 7: "cmp"}
# EAX 短形式：op eax, imm32
_EAX_SHORT = {0x05: "add", 0x0D: "or", 0x25: "and",
              0x2D: "sub", 0x35: "xor", 0x3D: "cmp"}
# 条件跳转操作码（短跳 rel8）-> s390x 掩码
_JCC = {
    0x70: 0x1,  # jo   -> CC3 溢出
    0x71: 0xE,  # jno  -> 非 CC3
    0x72: 0x3,  # jb   -> CC3 无符号小于
    0x73: 0xC,  # jae  -> 非 CC3
    0x74: 0x8,  # je   -> CC0
    0x75: 0x7,  # jne  -> CC1|CC2|CC3
    0x76: 0xD,  # jbe  -> CC0|CC1|CC3
    0x77: 0x2,  # ja   -> CC2
    0x78: 0x4,  # js   -> CC1 负数
    0x79: 0xB,  # jns  -> 非 CC1
    0x7C: 0x4,  # jl   -> CC1 有符号小于
    0x7D: 0xB,  # jge  -> 非 CC1
    0x7E: 0xC,  # jle  -> CC0|CC1
    0x7F: 0x2,  # jg   -> CC2 有符号大于
}


def decode_one(buf, pos=0, addr=0):
    start = pos
    rex = 0
    rex_w = rex_r = rex_x = rex_b = 0

    # 旧前缀（只需跳过）
    while pos < len(buf) and buf[pos] in (0xF0, 0xF2, 0xF3, 0x2E, 0x36,
                                          0x3E, 0x26, 0x64, 0x65, 0x66, 0x67):
        pos += 1
    # REX 前缀（只取操作码前最后一个）
    while pos < len(buf) and 0x40 <= buf[pos] <= 0x4F:
        rex = buf[pos]
        pos += 1
    rex_w = (rex >> 3) & 1
    rex_r = (rex >> 2) & 1
    rex_x = (rex >> 1) & 1
    rex_b = rex & 1

    if pos >= len(buf):
        raise DecodeError("unexpected end of input")
    op = buf[pos]
    pos += 1

    # endbr64 : F3 0F 1E FA（F3 前缀已消费）
    if op == 0x0F and pos + 2 < len(buf) and buf[pos] == 0x1E and buf[pos + 1] == 0xFA:
        pos += 2
        return Instruction("endbr64", buf[start:pos], addr), pos

    # 0F 转义：两字节操作码
    if op == 0x0F:
        op2 = buf[pos]
        pos += 1
        # 0F 05 : SYSCALL
        if op2 == 0x05:
            return Instruction("syscall", buf[start:pos], addr), pos
        # 0F AF /r : IMUL r, r/m
        if op2 == 0xAF:
            reg, rm, pos = _parse_modrm(buf, pos, rex_b, rex_x, rex_r)
            if rm["kind"] == "reg":
                return Instruction("imul", buf[start:pos], addr,
                                   dst=_reg(reg), src=rm), pos
            raise DecodeError("imul with memory operand not supported")
        # 0F 1F : 多字节 NOP（带 REX 前缀）
        if op2 == 0x1F:
            # 跳过 ModRM + 可能的 SIB/位移
            _, _, pos = _parse_modrm(buf, pos, rex_b, rex_x, rex_r)
            return Instruction("nop", buf[start:pos], addr), pos
        # 0F B6 : MOVZX r, r/m8
        if op2 == 0xB6:
            reg, rm, pos = _parse_modrm(buf, pos, rex_b, rex_x, rex_r)
            return Instruction("movzbl", buf[start:pos], addr,
                               dst=_reg(reg), src=rm), pos
        # 0F B7 : MOVZX r, r/m16
        if op2 == 0xB7:
            reg, rm, pos = _parse_modrm(buf, pos, rex_b, rex_x, rex_r)
            return Instruction("movzwl", buf[start:pos], addr,
                               dst=_reg(reg), src=rm), pos
        # 0F BE : MOVSX r, r/m8（字节符号扩展到 32/64）
        if op2 == 0xBE:
            reg, rm, pos = _parse_modrm(buf, pos, rex_b, rex_x, rex_r)
            return Instruction("movsbl", buf[start:pos], addr,
                               dst=_reg(reg), src=rm), pos
        # 0F BF : MOVSX r, r/m16（半字符号扩展到 32/64）
        if op2 == 0xBF:
            reg, rm, pos = _parse_modrm(buf, pos, rex_b, rex_x, rex_r)
            return Instruction("movswl", buf[start:pos], addr,
                               dst=_reg(reg), src=rm), pos
        # 0F 8x : Jcc rel32
        if 0x80 <= op2 <= 0x8F:
            short_op = op2 - 0x80 + 0x70
            rel, pos = _read_imm(buf, pos, 4, signed=True)
            target = addr + (pos - start) + rel
            return Instruction("jcc", buf[start:pos], addr,
                               imm=_JCC[short_op], target=target), pos
        # 0F 4x : CMOVcc r, r/m（条件传送）
        # 低 nibble 与 Jcc 低 nibble 相同，复用 _JCC
        if 0x40 <= op2 <= 0x4F:
            reg, rm, pos = _parse_modrm(buf, pos, rex_b, rex_x, rex_r)
            short_op = op2 - 0x40 + 0x70
            return Instruction("cmov", buf[start:pos], addr,
                               dst=_reg(reg), src=rm,
                               imm=_JCC[short_op]), pos
        raise DecodeError("unsupported 0F %02X escape at %d" % (op2, start))

    # 单字节操作码
    if op == 0x90:
        return Instruction("nop", buf[start:pos], addr), pos
    if op == 0xC3:
        return Instruction("ret", buf[start:pos], addr), pos
    if op == 0xCC:
        return Instruction("int3", buf[start:pos], addr), pos

    # E8 rel32 : CALL 近调用（相对）
    if op == 0xE8:
        rel, pos = _read_imm(buf, pos, 4, signed=True)
        target = addr + (pos - start) + rel
        return Instruction("call", buf[start:pos], addr, target=target), pos
    # E9 rel32 : JMP 近跳转（相对）
    if op == 0xE9:
        rel, pos = _read_imm(buf, pos, 4, signed=True)
        target = addr + (pos - start) + rel
        return Instruction("jmp", buf[start:pos], addr, target=target), pos
    # EB rel8 : JMP 短跳转
    if op == 0xEB:
        rel, pos = _read_imm(buf, pos, 1, signed=True)
        target = addr + (pos - start) + rel
        return Instruction("jmp", buf[start:pos], addr, target=target), pos
    # 7x rel8 : Jcc 短跳转
    if 0x70 <= op <= 0x7F:
        rel, pos = _read_imm(buf, pos, 1, signed=True)
        target = addr + (pos - start) + rel
        return Instruction("jcc", buf[start:pos], addr,
                           imm=_JCC[op], target=target), pos

    # 85 /r : TEST r/m, r
    if op == 0x85:
        reg, rm, pos = _parse_modrm(buf, pos, rex_b, rex_x, rex_r)
        return Instruction("test", buf[start:pos], addr, dst=rm, src=_reg(reg)), pos

    # 63 /r : MOVSXD r64, r/m32（64 位模式需 REX.W）
    if op == 0x63:
        reg, rm, pos = _parse_modrm(buf, pos, rex_b, rex_x, rex_r)
        return Instruction("movslq", buf[start:pos], addr,
                           dst=_reg(reg), src=rm), pos

    # 8D /r : LEA r, m
    if op == 0x8D:
        reg, rm, pos = _parse_modrm(buf, pos, rex_b, rex_x, rex_r)
        return Instruction("lea", buf[start:pos], addr,
                           dst=_reg(reg), src=rm), pos

    # B8+rd : mov r, imm（32 或 64，看 REX.W）
    if 0xB8 <= op <= 0xBF:
        reg = (op - 0xB8) | (rex_b << 3)
        if rex_w:
            val, pos = _read_imm(buf, pos, 8, signed=False)
            return Instruction("mov", buf[start:pos], addr,
                               dst=_reg(reg), src=_imm(val, 64)), pos
        val, pos = _read_imm(buf, pos, 4, signed=False)
        return Instruction("mov", buf[start:pos], addr,
                           dst=_reg(reg), src=_imm(val, 32)), pos

    # EAX 短形式：op eax, imm32
    if op in _EAX_SHORT:
        val, pos = _read_imm(buf, pos, 4, signed=True)
        return Instruction(_EAX_SHORT[op], buf[start:pos], addr,
                           dst=_reg(0), src=_imm(val, 32)), pos

    # ALU MR/RM（op r/m, r  或  op r, r/m）
    if op in _ALU_MR or op in _ALU_RM:
        reg, rm, pos = _parse_modrm(buf, pos, rex_b, rex_x, rex_r)
        if op in _ALU_MR:
            mnemonic = _ALU_MR[op]
            dst, src = rm, _reg(reg)
        else:
            mnemonic = _ALU_RM[op]
            dst, src = _reg(reg), rm
        return Instruction(mnemonic, buf[start:pos], addr, dst=dst, src=src), pos

    # MOV r/m, r (89) ; MOV r, r/m (8B)
    if op in (0x89, 0x8B):
        reg, rm, pos = _parse_modrm(buf, pos, rex_b, rex_x, rex_r)
        if op == 0x89:
            dst, src = rm, _reg(reg)
        else:
            dst, src = _reg(reg), rm
        return Instruction("mov", buf[start:pos], addr, dst=dst, src=src), pos

    # 8 位 mov (88/8A)：按 32 位处理
    if op in (0x88, 0x8A):
        reg, rm, pos = _parse_modrm(buf, pos, rex_b, rex_x, rex_r)
        if op == 0x88:
            dst, src = rm, _reg(reg)
        else:
            dst, src = _reg(reg), rm
        return Instruction("mov", buf[start:pos], addr, dst=dst, src=src), pos

    # Group-1: 81 /r id, 83 /r ib
    if op in (0x81, 0x83):
        reg, rm, pos = _parse_modrm(buf, pos, rex_b, rex_x, rex_r)
        sub = reg & 0x7
        if sub not in _GRP1:
            raise DecodeError("unsupported group-1 /%d" % sub)
        mnemonic = _GRP1[sub]
        if op == 0x83:
            val, pos = _read_imm(buf, pos, 1, signed=True)
            imm = _imm(val, 8)
        else:
            val, pos = _read_imm(buf, pos, 4, signed=True)
            imm = _imm(val, 32)
        return Instruction(mnemonic, buf[start:pos], addr, dst=rm, src=imm), pos

    # C7 /0 id : MOV r/m, imm32（REX.W 时符号扩展到 64）
    if op == 0xC7:
        reg, rm, pos = _parse_modrm(buf, pos, rex_b, rex_x, rex_r)
        sub = reg & 0x7
        if sub != 0:
            raise DecodeError("C7 /%d not supported" % sub)
        val, pos = _read_imm(buf, pos, 4, signed=True)
        sz = 64 if rex_w else 32
        return Instruction("mov", buf[start:pos], addr,
                           dst=rm, src=_imm(val, sz)), pos

    # FF /0 INC, /1 DEC, /2 CALL 间接, /4 JMP 间接
    if op == 0xFF:
        reg, rm, pos = _parse_modrm(buf, pos, rex_b, rex_x, rex_r)
        sub = reg & 0x7
        if sub == 0:
            return Instruction("inc", buf[start:pos], addr, operands=[rm]), pos
        if sub == 1:
            return Instruction("dec", buf[start:pos], addr, operands=[rm]), pos
        if sub == 2:
            return Instruction("call_ind", buf[start:pos], addr, operands=[rm]), pos
        if sub == 4:
            return Instruction("jmp_ind", buf[start:pos], addr, operands=[rm]), pos
        raise DecodeError("unsupported FF /%d" % sub)

    # 移位组：D1 /n ib=1（隐含）, D3 /n CL, C1 /n imm8
    # 子操作码：/4=SHL, /5=SHR, /7=SAR, /6=SAL(==SHL)
    if op in (0xD1, 0xD3, 0xC1):
        reg, rm, pos = _parse_modrm(buf, pos, rex_b, rex_x, rex_r)
        sub = reg & 0x7
        mnem = {4: "shl", 5: "shr", 6: "shl", 7: "sar"}.get(sub)
        if mnem is None:
            raise DecodeError("unsupported shift /%d" % sub)
        if op == 0xD1:
            # 移 1 位
            return Instruction(mnem, buf[start:pos], addr,
                               dst=rm, src=_imm(1, 8)), pos
        if op == 0xC1:
            # imm8 移位
            val, pos = _read_imm(buf, pos, 1, signed=False)
            return Instruction(mnem, buf[start:pos], addr,
                               dst=rm, src=_imm(val & 0x1F, 8)), pos
        if op == 0xD3:
            # CL 移位，CL 当寄存器操作数（寄存器号 1）
            return Instruction(mnem, buf[start:pos], addr,
                               dst=rm, src=_reg(1)), pos

    # F7 /2 NOT, /3 NEG, /0 TEST
    if op == 0xF7:
        reg, rm, pos = _parse_modrm(buf, pos, rex_b, rex_x, rex_r)
        sub = reg & 0x7
        if sub == 2:
            return Instruction("not", buf[start:pos], addr, operands=[rm]), pos
        if sub == 3:
            return Instruction("neg", buf[start:pos], addr, operands=[rm]), pos
        if sub == 0:
            val, pos = _read_imm(buf, pos, 4, signed=False)
            return Instruction("test", buf[start:pos], addr,
                               dst=rm, src=_imm(val, 32)), pos
        raise DecodeError("unsupported F7 /%d" % sub)

    # F6 /0 TEST r/m8, imm8（少见）
    if op == 0xF6:
        reg, rm, pos = _parse_modrm(buf, pos, rex_b, rex_x, rex_r)
        sub = reg & 0x7
        if sub == 0:
            val, pos = _read_imm(buf, pos, 1, signed=False)
            return Instruction("test", buf[start:pos], addr,
                               dst=rm, src=_imm(val, 8)), pos
        raise DecodeError("unsupported F6 /%d" % sub)

    raise DecodeError("unsupported opcode 0x%02X at offset %d" % (op, start))


def decode(buf, base_addr=0):
    out = []
    pos = 0
    addr = base_addr
    while pos < len(buf):
        insn, pos = decode_one(buf, pos, addr)
        out.append(insn)
        addr += len(insn.raw)
    return out
