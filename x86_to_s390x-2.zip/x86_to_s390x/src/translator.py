"""x86-64 -> s390x 指令翻译器。

把解码后的 x86-64 指令流翻译成 s390x 汇编文本，
之后由 s390x-linux-gnu-as 汇编、src.elf 链接成静态 ELF。

要点
----
* 每条 x86 指令地址 A 对应一个标签 ``Lhex(A)``，跳转/调用指向这些标签，
  因此前向跳转也能工作（无需手写两遍扫描汇编器）。

* 寄存器操作数经 src.registers 映射（ABI 对齐）。

* 内存操作数 ``[base + index*scale + disp]`` 用一条 ``la``（取地址）
  放到暂存寄存器 r0，再相对 r0 加载/存储。这样翻译只局限在本条指令内，
  不破坏 base/index 寄存器。

* RIP 相对内存操作数（``disp(%rip)``）访问全局变量。翻译器发出占位符
  ``<rip:disp>``，由 ELF 层解析成真实符号。

* ``call rel32`` -> ``brasl %r14, <target>``，目标是一个指向被调用函数
  入口标签的占位符。ELF 层把 x86 调用目标映射到翻译后的 s390x 函数入口。

* ``ret`` -> ``br %r14``（s390x 用链接寄存器返回）。
"""

from .registers import RegisterMap, SCRATCH_S390X
from .s390x import encoder as enc
from .x86 import decoder as x86dec


# 读-改-写 内存操作的第二暂存寄存器。
# r0 映射到 rax，但在 RMW 模式（如 `addl $1, counter(%rip)`）中 rax 通常
# 不活跃，所以占用 r0 对简单程序安全。
# 地址暂存用 r1，两个暂存角色不冲突。
SCRATCH2_S390X = 0


class TranslateError(Exception):
    pass


# 模块级“当前指令”，让 _emit_mem_access / _materialise_mem
# 能拿到指令的 .o 地址范围用于 RIP 重定位查找，不必层层传参。
_CURRENT_INSN = None


class Reloc:
    """翻译器发出的重定位请求。

    kind 取值：
      * ``"rip_load64"`` / ``"rip_store64"`` / ``"rip_load32"`` /
        ``"rip_store32"`` / ``"rip_lea"`` -- RIP 相对内存访问；
        ``target_x86_addr`` 是被引用的绝对 x86 地址
        （本指令末尾 + disp）。
      * ``"call"`` -- ``brasl`` 到入口在 ``target_x86_addr`` 的翻译函数。
      * ``"jmp"`` / ``"jcc"`` -- 跳到翻译后的标签；内部解析（无需
        ELF 重定位），保留只是为了统一。
    """

    def __init__(self, kind, target_x86_addr=None, mask=None):
        self.kind = kind
        self.target_x86_addr = target_x86_addr
        self.mask = mask

    def __repr__(self):
        return "<Reloc %s target=0x%x>" % (self.kind,
                                           self.target_x86_addr or 0)


def _label(addr):
    return "L%x" % addr


def _is_mem(operand):
    return isinstance(operand, dict) and operand.get("kind") == "mem"


def _is_reg(operand):
    return isinstance(operand, dict) and operand.get("kind") == "reg"


def _is_imm(operand):
    return isinstance(operand, dict) and operand.get("kind") == "imm"


def _imm_signed(operand, bits=64):
    """返回符号扩展到 bits 位的立即数。"""
    v = operand["value"]
    sz = operand.get("size", 32)
    # 按立即数自身大小做符号扩展
    if sz < 64:
        sign_bit = 1 << (sz * 8 - 1)
        if v & sign_bit:
            v = v - (1 << (sz * 8))
    return v & ((1 << bits) - 1) if bits == 64 else v


def _imm_unsigned(operand):
    return operand["value"] & 0xFFFFFFFFFFFFFFFF


def _load_imm_to(dst_s390, value, is_64bit):
    """把任意立即数加载到寄存器。"""
    out = []
    v = value & 0xFFFFFFFFFFFFFFFF if is_64bit else value & 0xFFFFFFFF
    # 小的有符号 16 位立即数：在零基础上 aghi，或直接 lghi
    if is_64bit:
        if -0x8000 <= value <= 0x7FFF:
            out.append(enc.lghi(dst_s390, value))
            return out
        if 0 <= v <= 0xFFFFFFFF:
            out.append(enc.lgfi(dst_s390, v))
            return out
        # 64 位且高位置位：拆成 llihf + llill（粗略）
        hi = (v >> 32) & 0xFFFFFFFF
        lo = v & 0xFFFFFFFF
        if hi and not lo:
            out.append(enc.llihf(dst_s390, hi))
            return out
        if lo and not hi:
            out.append(enc.llilf(dst_s390, lo))
            return out
        if hi:
            out.append(enc.llihf(dst_s390, hi))
            out.append(enc.llilf(dst_s390, lo) + "  # low half")
            # oill 更准；llilf 零扩展，所以用 OR 拼低半
            out.append("oill\t%s,%d" % ("%%r%d" % dst_s390, lo & 0xFFFF))
            if lo & 0xFFFF0000:
                out.append("oilf\t%s,%d" % ("%%r%d" % dst_s390, lo))
            return out
        out.append(enc.llilf(dst_s390, lo))
        return out
    else:
        if -0x8000 <= value <= 0x7FFF:
            out.append(enc.lghi(dst_s390, value))
            return out
        out.append(enc.lgfi(dst_s390, v))
        return out


def _materialise_mem(operand, regmap, is_64bit, relocations, cur_addr,
                     insn_end_addr, insn=None):
    """把 x86 内存操作数变成 s390x 有效地址。

    返回一个元组，告诉调用方如何发加载/存储。
    若是 RIP 相对，返回 ``("rip", insn_addr, insn_len, None)``，
    ELF 层据此扫描重定位表，找落在此范围内的重定位。

    **s390x r0 规则**：内存操作数 ``disp(B2, X2)`` 中，B2 或 X2 为 0
    表示“无寄存器”（值就是 0），而非 r0 的内容。
    由于 ``rax`` 映射到 ``r0``，任何以 rax 作 base 或 index 的 x86
    内存操作数（如 ``mov (%rax), %ecx``）必须先把 r0 复制到可用寄存器。
    这里用 ``r1``（SCRATCH_S390X）。
    """
    base = operand["base"]
    index = operand["index"]
    scale = operand["scale"]
    disp = operand["disp"]

    if operand.get("rip"):
        if insn is None:
            return ("rip", insn_end_addr - 4, 4, None)
        return ("rip", insn.addr, len(insn.raw), None)

    out_lines = []
    scratch = SCRATCH_S390X  # r1

    base_s390 = regmap.to_s390x(base) if base is not None else None
    idx_s390 = regmap.to_s390x(index) if index is not None else None

    # s390x r0 不能作 base 或 index，必要时复制到 r1
    if base_s390 == 0:
        out_lines.append("lgr\t%%r%d,%%r0" % scratch)
        base_s390 = scratch
    if idx_s390 == 0:
        if base_s390 == scratch:
            # base 和 index 都是 r0，已复制到 r1
            # 两个都用 r1（少见；la %r1,d(%r1,%r1) = 2*r0 + d）
            idx_s390 = scratch
        else:
            out_lines.append("lgr\t%%r%d,%%r0" % scratch)
            idx_s390 = scratch

    if index is not None and scale != 1:
        log2 = {2: 1, 4: 2, 8: 3}[scale]
        out_lines.append("sllg\t%%r%d,%%r%d,%d" % (scratch, idx_s390, log2))
        if base is not None:
            # la 只收 12 位无符号位移；lay 收 20 位有符号
            la_mnem = "lay" if not (0 <= disp <= 0xFFF) else "la"
            out_lines.append("%s\t%%r%d,%d(%%r%d,%%r%d)"
                             % (la_mnem, scratch, disp, base_s390, scratch))
        else:
            if disp != 0:
                out_lines.append("aghi\t%%r%d,%d" % (scratch, disp))
        return ("reg", out_lines, scratch, 0, None)
    if index is not None and scale == 1:
        if base is not None:
            la_mnem = "lay" if not (0 <= disp <= 0xFFF) else "la"
            out_lines.append("%s\t%%r%d,%d(%%r%d,%%r%d)"
                             % (la_mnem, scratch, disp, base_s390, idx_s390))
        else:
            out_lines.append("lgr\t%%r%d,%%r%d" % (scratch, idx_s390))
            if disp != 0:
                out_lines.append("aghi\t%%r%d,%d" % (scratch, disp))
        return ("reg", out_lines, scratch, 0, None)
    # 无 index
    if base is not None:
        # 20 位有符号位移范围：lg/stg/ly/sty/llgcy/stcy/llghy/sthy/lay 都支持。
        # 短形式 l/st/llgc/llgh/stc/sth 只收 12 位无符号（0..4095）；
        # 由 _emit_mem_access 按位移正负或 >4095 选择长形式。
        if -0x80000 <= disp <= 0x7FFFF:
            # 'direct' 路径：地址直接作 disp(base)。但若有 setup 行
            # （r0->r1 复制），必须先发出，所以一起返回。
            return ("direct", out_lines, base_s390, disp, None)
        # 超出 20 位有符号范围：用 lay（20 位）取址，再用 aghi 补高位
        out_lines.append("lay\t%%r%d,%d(%%r%d)" % (scratch, disp & 0xFFFFF, base_s390))
        if disp & ~0xFFFFF:
            out_lines.append("aghi\t%%r%d,%d" % (scratch, (disp >> 20) << 20))
        return ("reg", out_lines, scratch, 0, None)
    # 绝对地址（只有 disp）：位置无关代码中少见
    out_lines.append("larl\t%%r%d,%d" % (scratch, disp))
    return ("reg", out_lines, scratch, 0, None)


def _emit_mem_access(operand, regmap, is_store, value_s390, is_64bit,
                     insn, size=None):
    """为内存操作数发加载/存储。

    ``is_store=True`` 表示把 ``value_s390`` 存入内存；
    ``is_store=False`` 表示把内存加载到 ``value_s390``。

    ``size`` (1/2/4/8) 覆盖由 ``is_64bit`` 推断的访问宽度。
    子字访问（movzbl、movzwl、stc、sth）在**大端** s390x 上必须如此：
    从 byte 变量做 64/32 位加载会读到错字节。用 ``llgc``/``llgh``
    正好读到对的字节/半字并零扩展。

    RIP 相对访问返回特殊占位符行 ``RIP_<kind>\t<reg>\t<addr>\t<len>``，
    由 ELF 层改写成带符号的真实指令。``addr`` 和 ``len`` 编码指令的
    完整 ``[addr, addr+len)`` 范围，ELF 层据此扫描重定位表找 disp32
    字段（无论它在指令内哪个位置）。

    **位移范围**：短形式 32 位 ``l``/``st`` 和子字
    ``llgc``/``llgh``/``stc``/``sth`` 只收 12 位*无符号*位移（0..4095）。
    当有效地址位移为负（栈槽如 ``-36(%r15)`` 常见），改用长位移变体
    ``ly``/``sty``/``llgcy``/``llghy``/``stcy``/``sthy``，它们收 20 位
    *有符号*位移（-524288..524287）。64 位 ``lg``/``stg`` 本就用
    20 位有符号位移，不受影响。
    """
    if size is None:
        size = 8 if is_64bit else 4

    kind, *rest = _materialise_mem(operand, regmap, is_64bit, None,
                                    cur_addr=insn.addr,
                                    insn_end_addr=insn.addr + len(insn.raw),
                                    insn=insn)
    out = []

    if kind == "rip":
        insn_addr, insn_len, _ = rest
        size_tag = {1: "8", 2: "16", 4: "32", 8: "64"}[size]
        access = ("st" if is_store else "ld") + size_tag
        out.append("RIP_%s\t%%r%d\t0x%x\t0x%x" % (access, value_s390,
                                                  insn_addr, insn_len))
        return out

    # 按访问宽度和位移范围选加载/存储指令。
    # 短形式只收无符号 12 位位移（0..4095）；长形式收有符号 20 位。
    def _pick_load_store(size, disp):
        """返回 (助记符, 是否支持有符号位移)。"""
        # 64 位：lg/stg 已是 20 位有符号
        if size == 8:
            return ("lg" if not is_store else "stg", True)
        # 32 位：l/st 12 位无符号；ly/sty 20 位有符号
        if size == 4:
            if 0 <= disp <= 0xFFF:
                return ("l" if not is_store else "st", False)
            return ("ly" if not is_store else "sty", True)
        # 16 位：llgh/sth 12 位无符号；llghy/sthy 20 位有符号
        if size == 2:
            if 0 <= disp <= 0xFFF:
                return ("llgh" if not is_store else "sth", False)
            return ("llghy" if not is_store else "sthy", True)
        # 8 位：llgc/stc 12 位无符号；llgcy/stcy 20 位有符号
        if 0 <= disp <= 0xFFF:
            return ("llgc" if not is_store else "stc", False)
        return ("llgcy" if not is_store else "stcy", True)

    if kind == "direct":
        _, setup_lines, base_s390, disp, _ = (kind,) + tuple(rest)
        out.extend(setup_lines or [])
        mnem, _ = _pick_load_store(size, disp)
        out.append("%s\t%%r%d,%d(%%r%d)" % (mnem, value_s390, disp, base_s390))
        return out
    if kind == "reg":
        _, setup_lines, scratch, _, _ = (kind,) + tuple(rest)
        out.extend(setup_lines)
        mnem, _ = _pick_load_store(size, 0)
        out.append("%s\t%%r%d,0(%%r%d)" % (mnem, value_s390, scratch))
        return out
    raise TranslateError("unknown mem materialisation kind: %r" % kind)


def translate(insns, regmap=None, base_addr=0):
    """把解码后的 x86 指令列表翻译成 s390x 汇编文本。

    返回汇编行列表。RIP 相对访问和 ``call`` 目标以占位符行发出，
    由 ELF 层改写。
    """
    regmap = regmap or RegisterMap()
    out = []

    # 预扫描：给每个指令地址分配标签，跳转可指向（含前向跳转）
    addr_to_label = {}
    for insn in insns:
        addr_to_label[insn.addr] = _label(insn.addr)

    for insn in insns:
        # 发本指令的标签（第一条除外，函数入口标签已用）
        out.append("%s:" % addr_to_label[insn.addr])
        out.append("# x86 @0x%x: %s" % (insn.addr,
                                        _hex(insn.raw)))
        out.extend(_translate_one(insn, regmap, base_addr))
    return out


def _hex(b):
    return " ".join("%02x" % x for x in b)


def _translate_one(insn, regmap, base_addr):
    m = insn.mnemonic
    out = []

    if m == "endbr64" or m == "nop":
        return out  # 翻译为空

    if m == "syscall":
        # x86-64 syscall: rax=系统调用号, rdi/rsi/rdx/r10/r8/r9=参数, rax=返回值
        # s390x svc:     r1=系统调用号, r2/r3/r4/r5/r6/r7=参数,    r2=返回值
        # 寄存器映射已把 rdi->r2, rsi->r3, rdx->r4，所以前 3 个参数已就位。
        # 需要做的：
        #   1. 把 x86 系统调用号（r0/rax）映射到 s390x 的 r1
        #   2. 执行 svc 0
        #   3. 把返回值 r2 -> r0（rax）
        # 系统调用号是运行时值（syscall 前加载），所以用一连串比较来映射。
        # 每个 syscall 位置用 x86 指令地址作后缀的独立标签，避免一个函数内
        # 多个 syscall 在汇编器里冲突。
        s = "_%x" % insn.addr
        out.append("# syscall: 映射 x86 系统调用号 (r0) -> s390x (r1)")
        # x86 SYS_write=1 -> s390x SYS_write=4
        out.append("chi\t%r0,1")
        out.append("jne\t.Lsc1" + s)
        out.append("lghi\t%r1,4")
        out.append("j\t.Lsc_done" + s)
        # x86 SYS_exit=60 -> s390x SYS_exit=1
        out.append(".Lsc1" + s + ":")
        out.append("chi\t%r0,60")
        out.append("jne\t.Lsc2" + s)
        out.append("lghi\t%r1,1")
        out.append("j\t.Lsc_done" + s)
        # x86 SYS_exit_group=231 -> s390x SYS_exit=1
        out.append(".Lsc2" + s + ":")
        out.append("chi\t%r0,231")
        out.append("jne\t.Lsc3" + s)
        out.append("lghi\t%r1,1")
        out.append("j\t.Lsc_done" + s)
        # 未知：原样透传（尽力而为）
        out.append(".Lsc3" + s + ":")
        out.append("lgr\t%r1,%r0")
        out.append(".Lsc_done" + s + ":")
        out.append("svc\t0")
        out.append("lgr\t%r0,%r2")
        return out

    if m == "ret":
        # rax 映射到 r0，但 s390x ABI 用 r2 返回。跳回前先搬返回值。
        # 这里不动 r15：x86 epilogue（``add $N, %rsp`` / ``pop %rbp``）
        # 被当作普通指令翻译，已经把栈指针恢复到函数入口时的值。
        # 这里再 ``aghi %r15,160`` 会让 r15 越过调用方保存的 r14 槽，
        # 破坏返回路径。
        out.append("lgr\t%r2,%r0")
        out.append(enc.br(14))
        return out

    # ---------- 控制流 ----------
    if m == "jmp":
        out.append(enc.j(_label(insn.target)))
        return out
    if m == "jcc":
        out.append(enc.jcc(insn.imm, _label(insn.target)))
        return out
    if m == "call":
        # brasl %r14, <target>。目标是翻译后的函数入口。
        # 发一个占位符记录 call 指令在 .o 中的偏移，ELF 层据此查重定位
        # （.o 里 rel32 是占位；真目标来自 R_X86_64_PLT32/PC32 重定位）。
        # rel32 字段在 insn.addr + 1。
        #
        # 必须在调用周围保存 r14（返回地址），因为 ``brasl`` 会用被调用方
        # 的返回地址覆盖 r14。关键：每次调用都分配**新的** 160 字节栈帧
        # （``aghi %r15,-160`` ... ``aghi %r15,160``）。否则嵌套调用
        # （如 main -> inc -> foo）会在外层用过的同一个槽 ``stg %r14``，
        # 覆盖调用方保存的链接寄存器，破坏返回路径。
        out.append("aghi\t%r15,-160")
        out.append("stg\t%r14,0(%r15)")
        out.append("CALL\t0x%x" % (insn.addr + 1))
        out.append("lg\t%r14,0(%r15)")
        out.append("aghi\t%r15,160")
        # 返回值从 r2（s390x ABI）搬到 r0（rax）
        out.append("lgr\t%r0,%r2")
        return out

    # ---------- 栈帧 ----------
    if m in ("add", "sub") and _is_reg(insn.dst) and insn.dst["reg"] == 4:
        # add/sub $imm, %rsp  -> aghi %r15, ±imm
        if _is_imm(insn.src):
            v = _imm_signed(insn.src)
            v = v if m == "add" else -v
            out.append(enc.aghi_sp(v))
            return out

    # ---------- LEA ----------
    if m == "lea":
        if not _is_mem(insn.src):
            raise TranslateError("lea expects memory operand")
        dst_s390 = regmap.to_s390x(insn.dst["reg"])
        # LEA 计算地址，复用内存物化器
        kind, *rest = _materialise_mem(insn.src, regmap, True, None,
                                       cur_addr=insn.addr,
                                       insn_end_addr=insn.addr + len(insn.raw),
                                       insn=insn)
        if kind == "rip":
            insn_addr, insn_len, _ = rest
            out.append("RIP_lea\t%%r%d\t0x%x\t0x%x" % (dst_s390,
                                                        insn_addr, insn_len))
            return out
        if kind == "direct":
            _, setup_lines, base_s390, disp, _ = (kind,) + tuple(rest)
            out.extend(setup_lines or [])
            # la 只收 12 位无符号位移；lay 收 20 位有符号
            if 0 <= disp <= 0xFFF:
                out.append(enc.la(dst_s390, base_s390, disp))
            else:
                out.append(enc.lay(dst_s390, base_s390, disp))
            return out
        if kind == "reg":
            _, setup_lines, scratch, _, _ = (kind,) + tuple(rest)
            out.extend(setup_lines)
            out.append(enc.lgr(dst_s390, scratch))
            return out

    # ---------- CMOV（条件传送）----------
    # x86 CMOVcc r, r/m：若条件成立（由前一条 cmp/test 设的 CC），
    # dst = src。s390x 有 LOCGR（按条件加载寄存器），用 4 位掩码完成。
    if m == "cmov":
        dst_s390 = regmap.to_s390x(insn.dst["reg"])
        mask = insn.imm
        if _is_reg(insn.src):
            src_s390 = regmap.to_s390x(insn.src["reg"])
            # s390x r0 某些形式不能作 locgr 源；若是 r0（映射自 rax）先复制到 r1
            if src_s390 == 0:
                out.append("lgr\t%r1,%r0")
                src_s390 = 1
            out.append("locgr\t%%r%d,%%r%d,%d" % (dst_s390, src_s390, mask))
            return out
        if _is_mem(insn.src):
            # 内存读到暂存，再 locgr
            is64 = _is_rex_w(insn.raw)
            out.extend(_emit_mem_access(insn.src, regmap, is_store=False,
                                        value_s390=SCRATCH2_S390X,
                                        is_64bit=is64, insn=insn))
            out.append("locgr\t%%r%d,%%r%d,%d"
                       % (dst_s390, SCRATCH2_S390X, mask))
            return out
        raise TranslateError("unsupported cmov operand combination")

    # ---------- MOVZX / MOVSXD ----------
    # 大端注意：从多字节变量做子字加载（llgc/llgh）在 s390x 上会读到**错**字节。
    # 比如 ``movzbl counter(%rip)`` 在 x86 上读低位（偏移 0，小端）。
    # 在 s390x 上 32 位 int 的低位在偏移 3（大端）。所以先加载完整 32 位
    # （或 64 位）值，再用 llgcr/llghr 提取低字节/半字——后者操作寄存器，
    # 与内存字节序无关。
    if m == "movzbl":
        dst_s390 = regmap.to_s390x(insn.dst["reg"])
        if _is_reg(insn.src):
            out.append(enc.llgcr(dst_s390, regmap.to_s390x(insn.src["reg"])))
            return out
        # 内存：正确加载宽度取决于变量的真实大小，只有 ELF 层知道（符号表）。
        # 真 char（size=1）用 llgc 读对字节。把 int 当字节读（如
        # ``counter & 0xff``）必须加载完整 32 位值，再用 llgcr 提取低位
        # （llgcr 操作寄存器，不受内存字节序影响，能拿到正确的 LSB）。
        # 发特殊 RIP 占位符，ELF 层选加载方式。
        if _is_mem(insn.src) and insn.src.get("rip"):
            out.append("RIP_zld8\t%%r%d\t0x%x\t0x%x"
                       % (dst_s390, insn.addr, len(insn.raw)))
            return out
        # 非 RIP 内存（栈）：假定是真字节槽
        out.extend(_emit_mem_access(insn.src, regmap, is_store=False,
                                    value_s390=dst_s390, is_64bit=False,
                                    insn=insn, size=1))
        return out
    if m == "movzwl":
        dst_s390 = regmap.to_s390x(insn.dst["reg"])
        if _is_reg(insn.src):
            out.append(enc.llghr(dst_s390, regmap.to_s390x(insn.src["reg"])))
            return out
        if _is_mem(insn.src) and insn.src.get("rip"):
            out.append("RIP_zld16\t%%r%d\t0x%x\t0x%x"
                       % (dst_s390, insn.addr, len(insn.raw)))
            return out
        out.extend(_emit_mem_access(insn.src, regmap, is_store=False,
                                    value_s390=dst_s390, is_64bit=False,
                                    insn=insn, size=2))
        return out
    if m == "movsbl":
        # MOVSX r, r/m8 -- 字节符号扩展
        dst_s390 = regmap.to_s390x(insn.dst["reg"])
        if _is_reg(insn.src):
            out.append(enc.lgbr(dst_s390, regmap.to_s390x(insn.src["reg"])))
            return out
        if _is_mem(insn.src) and insn.src.get("rip"):
            out.append("RIP_sld8\t%%r%d\t0x%x\t0x%x"
                       % (dst_s390, insn.addr, len(insn.raw)))
            return out
        out.extend(_emit_mem_access(insn.src, regmap, is_store=False,
                                    value_s390=dst_s390, is_64bit=False,
                                    insn=insn, size=1))
        out.append(enc.lgbr(dst_s390, dst_s390))
        return out
    if m == "movswl":
        # MOVSX r, r/m16 -- 半字符号扩展
        dst_s390 = regmap.to_s390x(insn.dst["reg"])
        if _is_reg(insn.src):
            out.append(enc.lghr(dst_s390, regmap.to_s390x(insn.src["reg"])))
            return out
        if _is_mem(insn.src) and insn.src.get("rip"):
            out.append("RIP_sld16\t%%r%d\t0x%x\t0x%x"
                       % (dst_s390, insn.addr, len(insn.raw)))
            return out
        out.extend(_emit_mem_access(insn.src, regmap, is_store=False,
                                    value_s390=dst_s390, is_64bit=False,
                                    insn=insn, size=2))
        out.append(enc.lghr(dst_s390, dst_s390))
        return out
    if m == "movslq":
        dst_s390 = regmap.to_s390x(insn.dst["reg"])
        if _is_reg(insn.src):
            out.append(enc.lgfr(dst_s390, regmap.to_s390x(insn.src["reg"])))
            return out
        # 加载 32 位再符号扩展
        out.extend(_emit_mem_access(insn.src, regmap, is_store=False,
                                    value_s390=dst_s390, is_64bit=False,
                                    insn=insn))
        out.append(enc.lgfr(dst_s390, dst_s390))
        return out

    # ---------- MOV ----------
    if m == "mov":
        dst, src = insn.dst, insn.src
        # reg <- reg
        if _is_reg(dst) and _is_reg(src):
            out.append(enc.lgr(regmap.to_s390x(dst["reg"]),
                               regmap.to_s390x(src["reg"])))
            return out
        # reg <- imm
        if _is_reg(dst) and _is_imm(src):
            is64 = src.get("size", 32) == 64
            # B8+rd 的 32 位立即数可能带 R_X86_64_32 重定位
            # （如 ``mov $msg, %esi``）。ELF 层在指令范围内查重定位，
            # 有则发 ``larl`` 加载符号地址；无则用立即数值。
            if not is64:
                out.append("MOV_IMM32\t%%r%d\t0x%x\t0x%x\t%d"
                           % (regmap.to_s390x(dst["reg"]),
                              insn.addr, len(insn.raw),
                              src["value"] & 0xFFFFFFFF))
                return out
            out.extend(_load_imm_to(regmap.to_s390x(dst["reg"]),
                                    _imm_signed(src) if is64 else
                                    (src["value"] & 0xFFFFFFFF), is64))
            return out
        # reg <- mem
        if _is_reg(dst) and _is_mem(src):
            # 由 REX.W 前缀判断操作数大小
            is64 = _is_rex_w(insn.raw)
            out.extend(_emit_mem_access(src, regmap, is_store=False,
                                        value_s390=regmap.to_s390x(dst["reg"]),
                                        is_64bit=is64,
                                        insn=insn))
            return out
        # mem <- reg
        if _is_mem(dst) and _is_reg(src):
            is64 = _is_rex_w(insn.raw)
            out.extend(_emit_mem_access(dst, regmap, is_store=True,
                                        value_s390=regmap.to_s390x(src["reg"]),
                                        is_64bit=is64,
                                        insn=insn))
            return out
        # mem <- imm  (C7 /0 或 C6 /0)
        if _is_mem(dst) and _is_imm(src):
            is64 = _is_rex_w(insn.raw)
            # 立即数加载到 SCRATCH2（r0），不是 SCRATCH（r1）。
            # RIP 相对存储时 ELF 层发 ``larl %r1,sym; stg <val>,0(%r1)``，
            # 地址在 r1，所以值必须在**另一个**寄存器。
            # 值和地址都用 r1 会让 ``larl`` 冲掉值。
            out.extend(_load_imm_to(SCRATCH2_S390X,
                                    _imm_signed(src) if is64 else
                                    (src["value"] & 0xFFFFFFFF), is64))
            out.extend(_emit_mem_access(dst, regmap, is_store=True,
                                        value_s390=SCRATCH2_S390X,
                                        is_64bit=is64,
                                        insn=insn))
            return out
        raise TranslateError("unsupported mov operand combination")

    # ---------- 移位 (shl/shr/sar) ----------
    if m in ("shl", "shr", "sar"):
        return _translate_shift(insn, regmap, out)

    # ---------- ALU reg/reg, reg/imm ----------
    if m in ("add", "sub", "xor", "and", "or", "cmp", "imul"):
        return _translate_alu(insn, regmap, out)

    # ---------- 单目 ----------
    if m in ("inc", "dec", "neg", "not"):
        op = insn.operands[0]
        if _is_reg(op):
            r = regmap.to_s390x(op["reg"])
            if m == "inc":
                out.append(enc.aghi(r, 1))
            elif m == "dec":
                out.append(enc.aghi(r, -1))
            elif m == "neg":
                out.append(enc.lcgr(r, r))
            elif m == "not":
                out.append("lcgr\t%%r%d,%%r%d" % (r, r))
                out.append("aghi\t%%r%d,-1" % r)
            return out
        if _is_mem(op):
            is64 = _is_rex_w(insn.raw)
            out.extend(_emit_mem_access(op, regmap, is_store=False,
                                        value_s390=SCRATCH2_S390X,
                                        is_64bit=is64, insn=insn))
            if m == "inc":
                out.append((enc.aghi if is64 else enc.ahi)(SCRATCH2_S390X, 1))
            elif m == "dec":
                out.append((enc.aghi if is64 else enc.ahi)(SCRATCH2_S390X, -1))
            elif m == "neg":
                if is64:
                    out.append(enc.lcgr(SCRATCH2_S390X, SCRATCH2_S390X))
                else:
                    out.append("lcr\t%%r%d,%%r%d" % (SCRATCH2_S390X, SCRATCH2_S390X))
            elif m == "not":
                if is64:
                    out.append(enc.lcgr(SCRATCH2_S390X, SCRATCH2_S390X))
                else:
                    out.append("lcr\t%%r%d,%%r%d" % (SCRATCH2_S390X, SCRATCH2_S390X))
                out.append("aghi\t%%r%d,-1" % SCRATCH2_S390X)
            out.extend(_emit_mem_access(op, regmap, is_store=True,
                                        value_s390=SCRATCH2_S390X,
                                        is_64bit=is64, insn=insn))
            return out
        raise TranslateError("%s with unsupported operand" % m)

    # ---------- TEST ----------
    if m == "test":
        dst, src = insn.dst, insn.src
        is64 = _is_rex_w(insn.raw)
        if _is_reg(dst) and _is_reg(src):
            a = regmap.to_s390x(dst["reg"])
            b = regmap.to_s390x(src["reg"])
            # x86 TEST 按 AND 结果设 ZF/SF；有符号跳转（jle/jg）需知道
            # 结果是零、负还是正。s390x 逻辑运算（ngr）只给 CC=0（零）/CC=1
            # （非零），不够做有符号比较。
            # 修正：AND 到暂存，再用 ltr/ltgr 取算术 CC。
            if a == b:
                # test %reg, %reg：直接加载并测试
                out.append(("ltgr" if is64 else "ltr") +
                           "\t%%r%d,%%r%d" % (SCRATCH_S390X, a))
            else:
                out.append("lgr\t%%r%d,%%r%d" % (SCRATCH_S390X, a))
                out.append(("ngr" if is64 else "nr") +
                           "\t%%r%d,%%r%d" % (SCRATCH_S390X, b))
                out.append(("ltgr" if is64 else "ltr") +
                           "\t%%r%d,%%r%d" % (SCRATCH_S390X, SCRATCH_S390X))
            return out
        if _is_reg(dst) and _is_imm(src):
            a = regmap.to_s390x(dst["reg"])
            out.append("lgr\t%%r%d,%%r%d" % (SCRATCH_S390X, a))
            v = _imm_signed(src)
            if -0x8000 <= v <= 0x7FFF:
                out.append("nill\t%%r%d,%d" % (SCRATCH_S390X, v & 0xFFFF))
            else:
                out.append("nilf\t%%r%d,%d" % (SCRATCH_S390X,
                                               v & 0xFFFFFFFF))
            out.append(("ltgr" if is64 else "ltr") +
                       "\t%%r%d,%%r%d" % (SCRATCH_S390X, SCRATCH_S390X))
            return out
        raise TranslateError("unsupported test operand combination")

    raise TranslateError("unsupported instruction: %s" % m)


def _is_rex_w(raw):
    """指令的 REX 前缀是否置了 W 位。"""
    i = 0
    while i < len(raw) and raw[i] in (0xF0, 0xF2, 0xF3, 0x2E, 0x36,
                                      0x3E, 0x26, 0x64, 0x65, 0x66, 0x67):
        i += 1
    while i < len(raw) and 0x40 <= raw[i] <= 0x4F:
        return bool(raw[i] & 0x08)
    return False


def _translate_alu(insn, regmap, out):
    m = insn.mnemonic
    dst, src = insn.dst, insn.src
    is64 = _is_rex_w(insn.raw)

    # reg <- reg
    if _is_reg(dst) and _is_reg(src):
        a = regmap.to_s390x(dst["reg"])
        b = regmap.to_s390x(src["reg"])
        if m == "add":
            out.append((enc.agr if is64 else enc.ar)(a, b))
        elif m == "sub":
            out.append((enc.sgr if is64 else enc.sr)(a, b))
        elif m == "xor":
            out.append((enc.xgr if is64 else enc.xr)(a, b))
        elif m == "and":
            out.append((enc.ngr if is64 else enc.nr)(a, b))
        elif m == "or":
            out.append((enc.ogr if is64 else enc.or_)(a, b)) if hasattr(enc, "or_") else out.append(enc.ogr(a, b))
        elif m == "cmp":
            out.append((enc.cgr if is64 else enc.cr)(a, b))
        elif m == "imul":
            out.append((enc.msgr if is64 else enc.msr)(a, b))
        return out

    # reg <- imm
    if _is_reg(dst) and _is_imm(src):
        a = regmap.to_s390x(dst["reg"])
        v = _imm_signed(src)
        if m == "add":
            out.append((enc.aghi if is64 else enc.ahi)(a, v)
                       if -0x8000 <= v <= 0x7FFF else
                       (enc.agfi if is64 else enc.afi)(a, v))
        elif m == "sub":
            out.append((enc.aghi if is64 else enc.ahi)(a, -v)
                       if -0x8000 <= -v <= 0x7FFF else
                       (enc.sgfi if is64 else enc.sfi)(a, v))
        elif m == "cmp":
            out.append((enc.cgfi if is64 else enc.cfi)(a, v))
        elif m == "xor":
            out.append(_imm_alu_logical(a, v, "x", is64))
        elif m == "and":
            out.append(_imm_alu_logical(a, v, "n", is64))
        elif m == "or":
            out.append(_imm_alu_logical(a, v, "o", is64))
        elif m == "imul":
            # mghi 给 16 位，msgfi 给 32 位
            if -0x8000 <= v <= 0x7FFF:
                out.append("mghi\t%%r%d,%d" % (a, v))
            else:
                out.append("msgfi\t%%r%d,%d" % (a, v))
        return out

    # reg <- mem（先加载再 ALU）
    if _is_reg(dst) and _is_mem(src):
        a = regmap.to_s390x(dst["reg"])
        out.extend(_emit_mem_access(src, regmap, is_store=False,
                                    value_s390=SCRATCH_S390X,
                                    is_64bit=is64,
                                    insn=insn))
        # 再算 dst OP scratch
        if m == "add":
            out.append((enc.agr if is64 else enc.ar)(a, SCRATCH_S390X))
        elif m == "sub":
            out.append((enc.sgr if is64 else enc.sr)(a, SCRATCH_S390X))
        elif m == "imul":
            out.append((enc.msgr if is64 else enc.msr)(a, SCRATCH_S390X))
        elif m == "cmp":
            out.append((enc.cgr if is64 else enc.cr)(a, SCRATCH_S390X))
        else:
            out.append(_alu_reg_scratch(a, m, is64))
        return out

    # mem <- reg（二元操作：把内存读到 scratch2，算，再存回）
    # 值放 SCRATCH2（r1），这样 RIP 相对的 larl 可用 r0 取地址而不冲掉值
    if _is_mem(dst) and _is_reg(src):
        a = regmap.to_s390x(src["reg"])
        out.extend(_emit_mem_access(dst, regmap, is_store=False,
                                    value_s390=SCRATCH2_S390X,
                                    is_64bit=is64,
                                    insn=insn))
        if m == "add":
            out.append((enc.agr if is64 else enc.ar)(SCRATCH2_S390X, a))
        elif m == "sub":
            out.append((enc.sgr if is64 else enc.sr)(SCRATCH2_S390X, a))
        elif m == "imul":
            out.append((enc.msgr if is64 else enc.msr)(SCRATCH2_S390X, a))
        elif m == "cmp":
            out.append((enc.cgr if is64 else enc.cr)(SCRATCH2_S390X, a))
            return out  # cmp 不写回
        else:
            out.append(_alu_scratch_reg(a, m, is64))
        out.extend(_emit_mem_access(dst, regmap, is_store=True,
                                    value_s390=SCRATCH2_S390X,
                                    is_64bit=is64,
                                    insn=insn))
        return out

    # mem <- imm（如 addl $1, counter(%rip)）
    # 把内存读到 SCRATCH2，与立即数算，再存回
    if _is_mem(dst) and _is_imm(src):
        v = _imm_signed(src)
        out.extend(_emit_mem_access(dst, regmap, is_store=False,
                                    value_s390=SCRATCH2_S390X,
                                    is_64bit=is64,
                                    insn=insn))
        if m == "add":
            out.append((enc.aghi if is64 else enc.ahi)(SCRATCH2_S390X, v)
                       if -0x8000 <= v <= 0x7FFF else
                       (enc.agfi if is64 else enc.afi)(SCRATCH2_S390X, v))
        elif m == "sub":
            nv = -v
            out.append((enc.aghi if is64 else enc.ahi)(SCRATCH2_S390X, nv)
                       if -0x8000 <= nv <= 0x7FFF else
                       (enc.sgfi if is64 else enc.sfi)(SCRATCH2_S390X, v))
        elif m == "cmp":
            out.append((enc.cgfi if is64 else enc.cfi)(SCRATCH2_S390X, v))
            return out  # cmp 不写回
        elif m == "xor":
            out.append(_imm_alu_logical(SCRATCH2_S390X, v, "x", is64))
        elif m == "and":
            out.append(_imm_alu_logical(SCRATCH2_S390X, v, "n", is64))
        elif m == "or":
            out.append(_imm_alu_logical(SCRATCH2_S390X, v, "o", is64))
        out.extend(_emit_mem_access(dst, regmap, is_store=True,
                                    value_s390=SCRATCH2_S390X,
                                    is_64bit=is64,
                                    insn=insn))
        return out

    raise TranslateError("unsupported %s operand combination" % m)


def _imm_alu_logical(reg, value, op, is64):
    """发立即数逻辑运算（xor/and/or），按范围选指令。"""
    if -0x8000 <= value <= 0x7FFF:
        suffix = {"x": "xi", "n": "ni", "o": "oi"}[op]
        return "%s\t%%r%d,%d" % (suffix + ("h" if is64 else ""), reg, value)
    full = {"x": "xilf", "n": "nilf", "o": "oilf"}[op]
    return "%s\t%%r%d,%d" % (full, reg, value & 0xFFFFFFFF)


def _alu_reg_scratch(reg, m, is64):
    table = {
        "xor": (enc.xgr, enc.xr),
        "and": (enc.ngr, enc.nr),
        "or":  (enc.ogr, enc.or_) if hasattr(enc, "or_") else (enc.ogr, enc.ogr),
    }
    f = table[m][0 if is64 else 1]
    return f(reg, SCRATCH_S390X)


def _alu_scratch_reg(reg, m, is64):
    """计算 SCRATCH2 OP reg（mem<-reg ALU，值在 SCRATCH2）。"""
    table = {
        "xor": (enc.xgr, enc.xr),
        "and": (enc.ngr, enc.nr),
        "or":  (enc.ogr, enc.or_) if hasattr(enc, "or_") else (enc.ogr, enc.ogr),
        "cmp": (enc.cgr, enc.cr),
    }
    f = table[m][0 if is64 else 1]
    return f(SCRATCH2_S390X, reg)


def _translate_shift(insn, regmap, out):
    """把 x86 shl/shr/sar 翻译成 s390x sll/srl/sra（64 位用 *g）。

    x86 移位语义：
      * dst 是 r/m（支持 reg dst；内存 dst 少见，不支持）。
      * src 是移位量：1（D1）、imm8（C1）或 CL（D3）。
      * 移位量 32 位操作掩到 5 位，64 位操作掩到 6 位。
    s390x 移位指令：
      * 立即数形式：sll/srl/sra r,c（32 位），sllg/srlg/srag r,r,c（64 位）。
      * 寄存器形式：sll/srl/sra r,r（32 位），sllgr/srlgr/sragr r,r（64 位）。
      * s390x 把移位量掩到 6 位（64 位）或 5 位（非 g），与 x86 32 位语义一致。
    """
    m = insn.mnemonic
    dst, src = insn.dst, insn.src
    is64 = _is_rex_w(insn.raw)

    if not _is_reg(dst):
        # 内存目标移位：加载 -> 移位 -> 存储。-O1 输出里少见但可能。
        # 值放 SCRATCH2
        if not _is_mem(dst):
            raise TranslateError("unsupported %s operand" % m)
        out.extend(_emit_mem_access(dst, regmap, is_store=False,
                                    value_s390=SCRATCH2_S390X,
                                    is_64bit=is64, insn=insn))
        # 对 SCRATCH2 移位
        if _is_imm(src):
            c = src["value"] & 0x3F
            if m == "shl":
                out.append(enc.sllg(SCRATCH2_S390X, SCRATCH2_S390X, c)
                           if is64 else enc.sll(SCRATCH2_S390X, c))
            elif m == "shr":
                out.append(enc.srlg(SCRATCH2_S390X, SCRATCH2_S390X, c)
                           if is64 else enc.srl(SCRATCH2_S390X, c))
            else:  # sar
                out.append(enc.srag(SCRATCH2_S390X, SCRATCH2_S390X, c)
                           if is64 else enc.sra(SCRATCH2_S390X, c))
        elif _is_reg(src):
            # CL（寄存器号 1）-> 映射后的 s390x 寄存器
            cnt_s390 = regmap.to_s390x(src["reg"])
            if m == "shl":
                out.append(enc.sllgr(SCRATCH2_S390X, cnt_s390) if is64
                           else "sll\t%%r%d,%%r%d" % (SCRATCH2_S390X, cnt_s390))
            elif m == "shr":
                out.append(enc.srlgr(SCRATCH2_S390X, cnt_s390) if is64
                           else "srl\t%%r%d,%%r%d" % (SCRATCH2_S390X, cnt_s390))
            else:
                out.append(enc.sragr(SCRATCH2_S390X, cnt_s390) if is64
                           else "sra\t%%r%d,%%r%d" % (SCRATCH2_S390X, cnt_s390))
        out.extend(_emit_mem_access(dst, regmap, is_store=True,
                                    value_s390=SCRATCH2_S390X,
                                    is_64bit=is64, insn=insn))
        return out

    # 寄存器目标
    r = regmap.to_s390x(dst["reg"])
    if _is_imm(src):
        c = src["value"] & 0x3F
        if m == "shl":
            if is64:
                out.append(enc.sllg(r, r, c))
            else:
                out.append(enc.sll(r, c))
        elif m == "shr":
            if is64:
                out.append(enc.srlg(r, r, c))
            else:
                out.append(enc.srl(r, c))
        else:  # sar
            if is64:
                out.append(enc.srag(r, r, c))
            else:
                out.append(enc.sra(r, c))
        return out
    if _is_reg(src):
        cnt_s390 = regmap.to_s390x(src["reg"])
        if m == "shl":
            if is64:
                out.append(enc.sllgr(r, cnt_s390))
            else:
                out.append("sll\t%%r%d,%%r%d" % (r, cnt_s390))
        elif m == "shr":
            if is64:
                out.append(enc.srlgr(r, cnt_s390))
            else:
                out.append("srl\t%%r%d,%%r%d" % (r, cnt_s390))
        else:
            if is64:
                out.append(enc.sragr(r, cnt_s390))
            else:
                out.append("sra\t%%r%d,%%r%d" % (r, cnt_s390))
        return out
    raise TranslateError("unsupported %s operand combination" % m)


# 给 CLI 重导出
def translate_bytes(x86_bytes, base_addr=0):
    insns = x86dec.decode(x86_bytes, base_addr)
    return translate(insns, base_addr=base_addr), insns
