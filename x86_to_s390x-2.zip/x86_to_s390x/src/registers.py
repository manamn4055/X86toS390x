"""x86-64 与 s390x 寄存器映射（ABI 对齐）。

x86-64 System V 整数参数寄存器：rdi, rsi, rdx, rcx, r8, r9
s390x ELF  整数参数寄存器：r2,  r3,  r4,  r5,  r6, r7

按顺序对应，调用方和被调用方就一致，无需搬移参数。

返回值：rax -> r2。
被调用方保存寄存器（rbx, rbp, r12-r15）映射到 s390x 同类寄存器（r6-r13）。
rsp -> r15（栈指针）。

r0 当临时暂存（单条指令内用，不保存 x86 状态）。
"""

# x86-64 寄存器号 (0..15) -> s390x 寄存器号 (0..15)。
X86_TO_S390X = {
    # 参数寄存器
    7:  2,   # rdi -> r2
    6:  3,   # rsi -> r3
    2:  4,   # rdx -> r4
    1:  5,   # rcx -> r5
    8:  6,   # r8  -> r6
    9:  7,   # r9  -> r7
    # rax 映射到 r0（非参数寄存器），避免和 rdi/r2 冲突
    0:  0,   # rax -> r0
    # 被调用方保存寄存器
    3:  8,   # rbx -> r8
    5:  9,   # rbp -> r9
    12: 10,  # r12 -> r10
    13: 11,  # r13 -> r11
    14: 12,  # r14 -> r12（s390x r14 是链接寄存器，专用于 call/ret）
    4:  15,  # rsp -> r15
    10: 13,  # r10 -> r13
    # r11、r15 没有干净映射（r1 是地址暂存，r14 是链接寄存器），不支持。
    # gcc -O1 编出的测试程序不会用到。
}

X86_REG_NAMES = [
    "rax", "rcx", "rdx", "rbx", "rsp", "rbp", "rsi", "rdi",
    "r8",  "r9",  "r10", "r11", "r12", "r13", "r14", "r15",
]
S390X_REG_NAMES = ["r%d" % i for i in range(16)]
# r1 是地址计算暂存；r0 映射到 rax。
SCRATCH_S390X = 1


class RegisterMap:
    def __init__(self, mapping=None):
        self.mapping = dict(mapping) if mapping else dict(X86_TO_S390X)

    def to_s390x(self, x86_index):
        if x86_index not in self.mapping:
            raise ValueError("x86 register %s (r%d) is not mapped"
                             % (X86_REG_NAMES[x86_index], x86_index))
        return self.mapping[x86_index]

    def x86_name(self, index):
        return X86_REG_NAMES[index]

    def s390x_name(self, index):
        return S390X_REG_NAMES[index]
