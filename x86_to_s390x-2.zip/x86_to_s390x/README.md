# x86tos390x — x86-64 → s390x static binary translator

A small, **portable** (pure Python, no dependencies) tool that statically
translates a subset of **x86-64** machine code into equivalent **s390x**
(z/Architecture) machine code.  It also emits a minimal, self-contained
**s390x ELF** that can be executed directly under `qemu-s390x`, so translation
correctness is verified by **running the output** and comparing exit codes
against native x86-64 execution.

The s390x instruction encoder is checked **byte-for-byte** against
`s390x-linux-gnu-as` / `objdump`, and the full pipeline is exercised by an
end-to-end test suite (24 x86 programs → s390x → QEMU).

---

## What it does

```
 x86-64 bytes  ──►  x86 decoder  ──►  translator  ──►  s390x bytes  ──►  ELF writer  ──►  qemu-s390x
   (raw)         (ModRM/REX)      (reg map)        (RRE/RI/RIL)       (static ELF64)
```

* **Decodes** x86-64 instructions (REX.W prefixes, ModRM, r8–r15 extensions).
* **Maps** x86-64 general-purpose registers to s390x registers (see
  [registers.py](src/registers.py)).
* **Encodes** semantically equivalent s390x instructions (big-endian).
* **Wraps** the result in a static ELF64 whose prologue sets up the link
  register and whose epilogue performs `exit(result)` via `SVC 0`.

### Supported x86-64 instructions

| Group        | Forms                                                          | → s390x                |
|--------------|----------------------------------------------------------------|------------------------|
| `MOV`        | `mov r64,r64` (89/8B), `mov r64,imm32` (C7 /0, B8+), `mov r64,imm64` (B8+ REX.W) | `LGR` / `LGFI` / `LLILF+LLIHF` |
| `ADD`        | `01/03`, `83 /0`, `81 /0`, `05` (EAX short)                    | `AGR` / `AGHI`         |
| `SUB`        | `29/2B`, `83 /5`, `81 /5`, `2D`                                | `SGR` / `AGHI(-imm)`   |
| `XOR/AND/OR` | `31/33`, `21/23`, `09/0B` (reg); `35/25/0D` and `81` (imm)     | `XGR/NGR/OGR` (+scratch) |
| `CMP`        | `39/3B`, `83 /7`, `3D`                                         | `CGR`                  |
| `IMUL`       | `0F AF /r`                                                     | `MSGR`                 |
| `INC/DEC`    | `FF /0`, `FF /1`                                               | `AGHI ±1`              |
| `NEG/NOT`    | `F7 /3`, `F7 /2`                                               | `LCGR` / `XGR`         |
| `RET`        | `C3`                                                           | `BR R14`               |
| `NOP`        | `90`                                                           | `BCR 0,0`              |

### Documented limitations

This is a **static, instruction-level** translator for a focused subset — it
is *not* a full dynamic binary translator like QEMU TCG.

* **No memory operands.** Only register-direct (`mod == 11`) forms are
  supported; any instruction referencing memory is rejected with a clear error.
  (Translating x86 addressing modes / endianness to s390x is a much larger
  problem.)
* **No control flow** other than `RET`. Jumps, calls, conditional branches and
  loops are not translated.
* **Register map has 15 s390x GPRs available** (R0 is reserved as a transient
  scratch). x86 **R15** is therefore unmapped and raises an error if used;
  x86 **R14** maps to s390x R14 (the s390x link register), so test programs
  that rely on the ELF exit-epilogue must not clobber x86 R14.
* **No-REX.W (32-bit) ALU ops are translated as 64-bit.** The low 32 bits
  (and hence observable exit codes) match; the upper 32 bits may differ from
  a true 32-bit zero-extending result on overflow.
* **Flags / condition codes** are not preserved across instructions (each ALU
  op still sets the s390x condition code, but x86 flag semantics are not
  modelled).

---

## Requirements

* **Python 3.7+** (no third-party packages).

Optional, for running the test suite / producing runnable ELFs:
* `qemu-user` (`qemu-s390x`)
* `binutils-s390x-linux-gnu` (`s390x-linux-gnu-as`, `s390x-linux-gnu-objdump`)
* `gcc`, `objcopy` (native, for the reference x86-64 execution in tests)

```bash
apt-get install -y qemu-user binutils-s390x-linux-gnu gcc-s390x-linux-gnu
```

---

## Usage

### CLI

```bash
# Translate a hex blob and print the s390x bytes + side-by-side listing
./x86tos390x.py --hex "b8 05 00 00 00 c3" --list

# Translate raw x86-64 bytes from a file into a QEMU-runnable s390x ELF
./x86tos390x.py --in-file prog.x86.bin --elf prog.s390x.elf --list

# Also disassemble the produced s390x bytes with the system objdump
./x86tos390x.py --hex "48 0f af c1 c3" --objdump
```

Run `./x86tos390x.py --help` for all flags.

### Library

```python
from src import Translator, elf

x86 = bytes.fromhex("48c7c00a0000000048 83c020c3".replace(" ", ""))
s390x = Translator().translate(x86)          # -> bytes
elf.write_elf("out.elf", s390x)             # runnable under qemu-s390x
```

See [examples/demo.py](examples/demo.py) for a complete runnable example.

---

## Testing

```bash
bash tests/run_tests.sh          # encoding check + live QEMU run + objdump
python3 tests/test_translator.py # unittest: encoder, decoder, end-to-end
```

The end-to-end test, for each of 24 x86-64 programs:

1. assembles & runs the program **natively** on x86-64 (reference exit code),
2. translates it to s390x, wraps it in an ELF, and runs it under `qemu-s390x`,
3. asserts the two exit codes match (mod 256).

All s390x instruction encodings are cross-checked against the GNU assembler.

---

## Project layout

```
x86_to_s390x/
├── x86tos390x.py            # CLI entry point
├── src/
│   ├── __init__.py
│   ├── registers.py         # x86-64 <-> s390x register map (R0 = scratch)
│   ├── translator.py        # instruction mapping engine + listing
│   ├── elf.py               # minimal static s390x ELF64 writer
│   ├── x86/
│   │   ├── __init__.py
│   │   └── decoder.py       # x86-64 decoder (REX/ModRM, reg & imm forms)
│   └── s390x/
│       ├── __init__.py
│       └── encoder.py       # s390x encoder (RRE/RI/RIL formats)
├── examples/
│   └── demo.py              # programmatic end-to-end demo
└── tests/
    ├── test_translator.py   # encoding + end-to-end (QEMU) test suite
    ├── run_tests.sh         # convenience runner
    └── verify_encodings.s   # s390x encoding reference (human-readable)
```

---

## How correctness is verified

* **Encoder**: every s390x instruction the translator can emit is assembled
  with `s390x-linux-gnu-as` and the resulting bytes are compared to the
  encoder's output (`tests/test_translator.py::EncodingTests`). This caught
  real opcode mistakes during development (e.g. `LCGR` vs `LCR`, the `LLIHF`
  opcode extension, `MSGR`/`AGHI`/`LGFI` opcodes).
* **Execution**: the 24 end-to-end programs are run both natively (x86-64)
  and translated (s390x under QEMU); exit codes must match. This caught the
  `sub_imm64` double-negation bug.
