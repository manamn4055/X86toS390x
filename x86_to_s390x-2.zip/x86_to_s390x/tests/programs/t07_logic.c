// t07_logic.c — 位运算 + 逻辑比较
// Tests: AND, OR, XOR, shifts, signed/unsigned comparisons
int logic_test(int a, int b) {
    int x = a & b;       // AND
    int y = a | b;       // OR
    int z = a ^ b;       // XOR
    int s = (a << 2) + (b >> 1);  // shifts
    int cmp = (a > b) ? 100 : 200;  // signed comparison
    return (x + y + z + s + cmp) & 0xff;
}
int main(void) {
    // a=0xF0=240, b=0x0F=15
    // x=240&15=0, y=240|15=255, z=240^15=255
    // s=(240<<2)+(15>>1)=960+7=967
    // cmp: 240>15 -> 100
    // total=0+255+255+967+100=1577, &0xff=1577%256=73
    return logic_test(0xF0, 0x0F);  // expected: 73
}
