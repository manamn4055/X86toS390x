// t10_print.c — 通过 write 系统调用打印字符串
// Tests: syscall instruction translation (x86 write -> s390x write)
// The translator maps x86 SYS_write(1) to s390x SYS_write(4).

static long sys_write(int fd, const char *buf, unsigned long len) {
    long ret;
    register long rdi __asm__("rdi") = fd;
    register long rsi __asm__("rsi") = (long)buf;
    register long rdx __asm__("rdx") = (long)len;
    __asm__ volatile("syscall"
                     : "=a"(ret)
                     : "0"(1L), "r"(rdi), "r"(rsi), "r"(rdx)
                     : "rcx", "r11", "memory");
    return ret;
}

static long sys_exit(int code) {
    long ret;
    __asm__ volatile("syscall"
                     : "=a"(ret)
                     : "0"(60L), "D"((long)code)
                     : "rcx", "r11", "memory");
    return ret;
}

const char msg[] = "Hello, s390x!\n";

int main(void) {
    sys_write(1, msg, sizeof(msg) - 1);
    sys_exit(42);
    return 0;  // unreachable
}
