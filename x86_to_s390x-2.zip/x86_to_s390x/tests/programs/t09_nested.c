// t09_nested.c — 嵌套循环 + 指针运算
// Tests: nested for loops, pointer increment, 2D-like array access
int main(void) {
    int grid[3][4];
    int *p = &grid[0][0];
    // Fill: grid[i][j] = i*10 + j
    for (int i = 0; i < 3; i++) {
        for (int j = 0; j < 4; j++) {
            *p++ = i * 10 + j;
        }
    }
    // Sum diagonal-ish: grid[0][0] + grid[1][1] + grid[2][2]
    // = 0 + 11 + 22 = 33
    int sum = grid[0][0] + grid[1][1] + grid[2][2];
    return sum & 0xff;  // expected: 33
}
