// t08_types.c — 各种变量类型声明与运算
// Tests: char, short, int, long arithmetic and conversions
volatile char gc = 10;
volatile short gs = 20;
volatile int gi = 30;
volatile long gl = 40;

int main(void) {
    char c = gc;       // load char
    short s = gs;      // load short
    int i = gi;        // load int
    long l = gl;       // load long
    // Mix types: char+short -> int, int+long -> long
    long result = (long)c + (long)s + (long)i + l;
    // 10 + 20 + 30 + 40 = 100
    return (int)(result & 0xff);  // expected: 100
}
