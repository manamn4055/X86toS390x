#!/usr/bin/env bash
# 完整的端到端验证：C 代码 -> x86-64 机器码 -> s390x 机器码 -> QEMU 运行
#
# 验证逻辑：gauss(10) = 10*(10+1) + 100 - 50 = 160
set -uo pipefail

cd "$(dirname "$0")/.."
DEMO=/workspace/demo_c
mkdir -p "$DEMO"

echo "================================================================"
echo " 步骤 1: 写 C 代码 (gauss 函数，纯算术)"
echo "================================================================"
cat > "$DEMO/compute.c" <<'EOF'
#include <stdio.h>
int gauss(int n) {
    int result;
    __asm__ volatile (
        "mov %1, %0\n\t"
        "add $1, %0\n\t"
        "imul %1, %0\n\t"
        "add $100, %0\n\t"
        "sub $50, %0\n\t"
        : "=a"(result)
        : "D"(n)
    );
    return result;
}
int main(void) {
    int r = gauss(10);
    printf("gauss(10) = %d\n", r);
    return r & 0xff;
}
EOF
echo "compute.c 已生成"

echo
echo "================================================================"
echo " 步骤 2: 在本机 x86-64 上编译并运行（建立参考答案）"
echo "================================================================"
gcc -O2 -fno-stack-protector "$DEMO/compute.c" -o "$DEMO/compute_native"
"$DEMO/compute_native"
NATIVE_EC=$?
echo "本机退出码 = $NATIVE_EC  (期望 160)"

echo
echo "================================================================"
echo " 步骤 3: 抽取 gauss 的 inline asm 字节，构造可翻译的 64 位字节流"
echo "        (加 mov \$10,%rdi 作为入参，全部 REX.W 64 位形式)"
echo "================================================================"
python3 - "$DEMO/gauss_x86.bin" <<'PYEOF'
import sys
prog = bytes.fromhex(
    '48 bf 0a 00 00 00 00 00 00 00'  # mov $10, rdi
    '48 89 f8'                        # mov rdi, rax
    '48 83 c0 01'                     # add $1, rax
    '48 0f af c7'                     # imul rdi, rax
    '48 83 c0 64'                     # add $100, rax
    '48 83 e8 32'                     # sub $50, rax
    'c3'                              # ret
)
open(sys.argv[1],'wb').write(prog)
print('x86-64 字节 (%d bytes): %s' % (len(prog), prog.hex(' ')))
PYEOF
echo "反汇编确认："
objdump -D -b binary -m i386:x86-64 "$DEMO/gauss_x86.bin" | grep -E "^\s+[0-9a-f]+:"

echo
echo "================================================================"
echo " 步骤 4: 用我的翻译器 x86-64 -> s390x，并生成 ELF"
echo "================================================================"
cd /workspace/x86_to_s390x
python3 x86tos390x.py --in-file "$DEMO/gauss_x86.bin" --elf "$DEMO/gauss.s390x.elf" --list

echo
echo "================================================================"
echo " 步骤 5: 用 s390x objdump 反汇编，确认生成的 s390x 指令合法"
echo "================================================================"
s390x-linux-gnu-objdump -D -b binary -m s390:64-bit --adjust-vma=0x400078 \
    "$DEMO/gauss.s390x.elf" | sed -n '/400078/,/svc/p'

echo
echo "================================================================"
echo " 步骤 6: 在 QEMU 上运行翻译后的 s390x 程序"
echo "================================================================"
set +e
qemu-s390x "$DEMO/gauss.s390x.elf"
S390X_EC=$?
set -e
echo "qemu-s390x 退出码 = $S390X_EC"

echo
echo "================================================================"
echo " 结论"
echo "================================================================"
echo "本机 x86-64 退出码 = $NATIVE_EC"
echo "s390x (QEMU)  退出码 = $S390X_EC"
if [ "$NATIVE_EC" = "$S390X_EC" ]; then
    echo "✓ 完全一致 —— C 代码经翻译后在 s390x 上运行结果正确"
else
    echo "✗ 不一致"
    exit 1
fi
