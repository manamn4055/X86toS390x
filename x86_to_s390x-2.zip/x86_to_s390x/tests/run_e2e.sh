#!/usr/bin/env bash
# 端到端测试：gcc 编译 C -> 翻译 .o -> qemu-s390x 运行
# 验证退出码与 x86-64 原生执行一致。
set -uo pipefail

cd "$(dirname "$0")/.."
PROBE=/workspace/probe
mkdir -p "$PROBE"

# 测试程序：(名称, 期望退出码)
declare -a TESTS=(
    "t01_arith|129"
    "t02_global|3"
    "t03_array|150"
    "t04_loop|55"
    "t05_ptr_io|42"
    "t06_callchain|52"
)

PASS=0
FAIL=0

for entry in "${TESTS[@]}"; do
    name="${entry%%|*}"
    expected="${entry##*|}"

    echo "================================================================"
    echo "TEST $name  (expected exit code = $expected)"
    echo "================================================================"

    src="$PROBE/$name.c"
    if [ ! -f "$src" ]; then
        echo "  SKIP: $src not found"
        continue
    fi

    # 步骤1：编译 C -> x86-64 .o
    if ! gcc -O1 -fno-stack-protector -fno-pie -c "$src" -o "$PROBE/$name.o" 2>/dev/null; then
        echo "  FAIL: gcc compile failed"
        FAIL=$((FAIL + 1))
        continue
    fi

    # 步骤2：翻译 .o -> s390x ELF
    if ! python3 x86tos390x.py --obj "$PROBE/$name.o" --elf "$PROBE/$name.s390x" >/dev/null 2>"$PROBE/$name.err"; then
        echo "  FAIL: translation failed"
        cat "$PROBE/$name.err"
        FAIL=$((FAIL + 1))
        continue
    fi

    # 步骤3：qemu-s390x 运行
    qemu-s390x "$PROBE/$name.s390x" >/dev/null 2>&1
    ec=$?

    if [ "$ec" = "$expected" ]; then
        echo "  PASS: exit code = $ec"
        PASS=$((PASS + 1))
    else
        echo "  FAIL: exit code = $ec (expected $expected)"
        FAIL=$((FAIL + 1))
        echo "  --- s390x 汇编（前 40 行） ---"
        python3 x86tos390x.py --obj "$PROBE/$name.o" --out "$PROBE/$name.s" 2>/dev/null
        head -40 "$PROBE/$name.s"
    fi
done

echo
echo "================================================================"
echo "RESULTS: $PASS passed, $FAIL failed (out of ${#TESTS[@]})"
echo "================================================================"
[ "$FAIL" = 0 ]
