#!/usr/bin/env bash
# 运行完整的 x86-64 -> s390x 翻译器测试套件。
#
# 依赖：python3, gcc, objcopy, qemu-s390x, s390x-linux-gnu-as,
#       s390x-linux-gnu-objdump  (apt-get install qemu-user
#       binutils-s390x-linux-gnu gcc-s390x-linux-gnu)。
set -euo pipefail
cd "$(dirname "$0")/.."

echo "=== [1/3] s390x 编码器编码核对（对照 gcc/objdump） ==="
echo
python3 tests/test_translator.py -v 2>&1 | sed -n '1,40p'

echo
echo "=== [2/3] 实时端到端：翻译一小段 x86 程序，在 qemu-s390x 上跑 ==="
echo
# x86-64 程序：(10 + 32) * ... -> 结果放 rax，再 ret。
#   mov rax, 10
#   add rax, 32        ; rax = 42
#   mov rcx, 3
#   imul rax, rcx      ; rax = 126
#   sub rax, 100       ; rax = 26
#   ret
python3 x86tos390x.py --hex "48 c7 c0 0a 00 00 00 48 83 c0 20 48 c7 c1 03 00 00 00 48 0f af c1 48 83 e8 64 c3" \
    --elf /tmp/demo.elf --list

echo
echo "running under qemu-s390x (expect exit code 26)..."
set +e
qemu-s390x /tmp/demo.elf
ec=$?
set -e
echo "exit=$ec"
[ "$ec" = "26" ] || { echo "MISMATCH: expected 26"; exit 1; }

echo
echo "=== [3/3] 用系统 objdump 反汇编生成的 s390x 字节 ==="
echo
python3 x86tos390x.py --hex "48 c7 c0 0a 00 00 00 48 83 c0 20 48 c7 c1 03 00 00 00 48 0f af c1 48 83 e8 64 c3" --objdump

echo
echo "ALL CHECKS PASSED"
