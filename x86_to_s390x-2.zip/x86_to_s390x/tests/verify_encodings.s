.text
.globl _start
_start:
    lgr   %r2,%r3          # b9 04 00 23
    lcr   %r2,%r3          # b9 03 00 23
    agr   %r2,%r3          # b9 08 00 23
    sgr   %r2,%r3          # b9 09 00 23
    xgr   %r2,%r3          # b9 82 00 23
    ngr   %r2,%r3          # b9 80 00 23
    ogr   %r2,%r3          # b9 81 00 23
    cgr   %r2,%r3          # b9 20 00 23
    msgr  %r2,%r3          # b9 0c 00 23
    lghi  %r2,1            # a7 29 00 01
    aghi  %r2,5            # a7 2b 00 05
    lgfi  %r2,0x12345678   # c0 21 12 34 56 78
    llill %r2,0x5678       # a5 2f 56 78
    llilf %r2,0x12345678   # c0 2f 12 34 56 78
    llihf %r2,0x12345678   # c0 20 12 34 56 78
    svc   0                # 0a 00
    br    %r14             # 07 fe
