"""冒烟测试：解码并翻译每个 probe 程序，打印汇编。"""
import sys, os
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from src.x86 import decoder as x86dec
from src.translator import translate, TranslateError


def extract_text(path):
    """从 x86-64 ELF 中提取 .text 字节与符号地址。"""
    import struct
    with open(path, "rb") as f:
        data = f.read()
    assert data[:4] == b"\x7fELF", "not an ELF"
    e_shoff = struct.unpack_from("<Q", data, 0x28)[0]
    e_shentsize = struct.unpack_from("<H", data, 0x3a)[0]
    e_shnum = struct.unpack_from("<H", data, 0x3c)[0]
    e_shstrndx = struct.unpack_from("<H", data, 0x3e)[0]
    # 节头字符串表
    shstr_off = struct.unpack_from("<Q", data, e_shoff + e_shstrndx * e_shentsize + 0x18)[0]
    text_bytes = b""
    text_addr = 0
    for i in range(e_shnum):
        sh = e_shoff + i * e_shentsize
        sh_name = struct.unpack_from("<I", data, sh)[0]
        sh_type = struct.unpack_from("<I", data, sh + 4)[0]
        sh_addr = struct.unpack_from("<Q", data, sh + 0x10)[0]
        sh_off = struct.unpack_from("<Q", data, sh + 0x18)[0]
        sh_size = struct.unpack_from("<Q", data, sh + 0x20)[0]
        name_end = data.index(b"\x00", shstr_off + sh_name)
        name = data[shstr_off + sh_name: name_end].decode()
        if name == ".text":
            text_bytes = data[sh_off:sh_off + sh_size]
            text_addr = sh_addr
    return text_bytes, text_addr


def main():
    probes = [
        "/workspace/probe/t01_arith",
        "/workspace/probe/t02_global",
        "/workspace/probe/t03_array",
        "/workspace/probe/t04_loop",
        "/workspace/probe/t05_ptr_io",
        "/workspace/probe/t06_callchain",
    ]
    for p in probes:
        if not os.path.exists(p):
            print("SKIP %s (not built)" % p)
            continue
        print("=" * 70)
        print("PROBE %s" % p)
        print("=" * 70)
        text, base = extract_text(p)
        try:
            insns = x86dec.decode(text, base)
            print("decoded %d instructions" % len(insns))
            asm = translate(insns, base_addr=base)
            for line in asm[:80]:
                print(line)
            if len(asm) > 80:
                print("... (%d more lines)" % (len(asm) - 80))
        except (TranslateError, x86dec.DecodeError) as e:
            print("ERROR: %s" % e)
        print()


if __name__ == "__main__":
    main()
