#!/usr/bin/env python3
"""x86-64 -> s390x 翻译器测试套件。

两类测试
--------
1. *编码测试* -- 把 ``src.s390x.encoder`` 产出的 s390x 字节与
   ``s390x-linux-gnu-as`` / ``objdump`` 对 ``verify_encodings.s`` 里每条
   指令的输出逐字节比对，防止编码器写错操作码。

2. *端到端执行测试* -- 每段 x86-64 函数体（见 ``TESTS``）：
     * 本机汇编、链接进一个极小 C 框架并运行，得到*参考*退出码；
     * 再翻译到 s390x、包成 ELF、在 ``qemu-s390x`` 下运行。
   两个退出码必须一致（mod 256）。

PATH 依赖：``gcc``、``as``、``objcopy``、``qemu-s390x``、
``s390x-linux-gnu-as``、``s390x-linux-gnu-objdump``。
"""
import os
import re
import sys
import subprocess
import tempfile
import unittest

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from src import Translator, DecodeError, TranslationError
from src.s390x import encoder as enc
from src import elf as elfmod


HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(HERE)
WORK = tempfile.mkdtemp(prefix="x86tos390x_test_")


def have(*tools):
    for t in tools:
        if subprocess.run(["which", t], capture_output=True).returncode != 0:
            return False
    return True


# ---------------------------------------------------------------------------
# 编码参考：把 verify_encodings.s 解析成 (助记符, 操作数, hex)。
# .s 里 _start: 之后每行一条指令，期望字节由汇编器重新推导。
# ---------------------------------------------------------------------------
def _run(cmd):
    """运行 ``cmd`` 并捕获输出；失败时抛出带输出的 CalledProcessError。"""
    r = subprocess.run(cmd, capture_output=True, text=True)
    if r.returncode != 0:
        raise subprocess.CalledProcessError(
            r.returncode, cmd, output=r.stdout, stderr=r.stderr)
    return r


def _as_disasm(s390x_asm):
    """汇编 ``s390x_asm``，返回 (字节hex, 助记文本) 列表。"""
    src = os.path.join(WORK, "enc.s")
    obj = os.path.join(WORK, "enc.o")
    with open(src, "w") as f:
        f.write(".text\n.globl _start\n_start:\n")
        for line in s390x_asm:
            f.write("    " + line + "\n")
    _run(["s390x-linux-gnu-as", "-o", obj, src])
    out = _run(["s390x-linux-gnu-objdump", "-d", obj]).stdout
    rows = []
    for line in out.splitlines():
        # 例如 "   4:   b9 03 00 23             lcgr    %r2,%r3"
        m = re.match(r"^\s+[0-9a-f]+:\s+((?:[0-9a-f]{2}\s)+)\s*(\S.*)$", line)
        if m:
            b = m.group(1).replace(" ", "")
            mn = m.group(2).split()[0]
            # 汇编器会给 .text 末尾补一个 "nopr"，跳过
            if mn in ("nopr", "nop"):
                continue
            rows.append((b, m.group(2).strip()))
    return rows


# (汇编源行, 期望产出相同字节的 encoder 调用)
ENCODING_CASES = [
    ("lgr   %r2,%r3",        lambda: enc.rre("lgr", 2, 3)),
    ("lcgr  %r2,%r3",        lambda: enc.rre("lcgr", 2, 3)),
    ("agr   %r2,%r3",        lambda: enc.rre("agr", 2, 3)),
    ("sgr   %r2,%r3",        lambda: enc.rre("sgr", 2, 3)),
    ("xgr   %r2,%r3",        lambda: enc.rre("xgr", 2, 3)),
    ("ngr   %r2,%r3",        lambda: enc.rre("ngr", 2, 3)),
    ("ogr   %r2,%r3",        lambda: enc.rre("ogr", 2, 3)),
    ("cgr   %r2,%r3",        lambda: enc.rre("cgr", 2, 3)),
    ("msgr  %r2,%r3",        lambda: enc.rre("msgr", 2, 3)),
    ("lghi  %r2,1",          lambda: enc.ri("lghi", 2, 1)),
    ("aghi  %r2,5",          lambda: enc.ri("aghi", 2, 5)),
    ("lgfi  %r2,0x12345678", lambda: enc.ril("lgfi", 2, 0x12345678)),
    ("llill %r2,0x5678",     lambda: enc.ri("llill", 2, 0x5678)),
    ("llilf %r2,0x12345678", lambda: enc.ril("llilf", 2, 0x12345678)),
    ("llihf %r2,0x12345678", lambda: enc.ril("llihf", 2, 0x12345678)),
    ("br    %r14",           lambda: enc.br(14)),
    ("svc   0",              lambda: enc.svc(0)),
]


class EncodingTests(unittest.TestCase):
    @unittest.skipUnless(have("s390x-linux-gnu-as", "s390x-linux-gnu-objdump"),
                         "s390x binutils not available")
    def test_encoder_matches_assembler(self):
        asm_lines = [c[0] for c in ENCODING_CASES]
        rows = _as_disasm(asm_lines)
        self.assertEqual(len(rows), len(ENCODING_CASES),
                         "objdump produced %d rows for %d instructions"
                         % (len(rows), len(ENCODING_CASES)))
        for (asm_line, produce), (expected_hex, _txt) in zip(ENCODING_CASES, rows):
            got = produce().hex()
            self.assertEqual(got, expected_hex,
                             "encoder mismatch for '%s'\n  expected: %s\n  got:      %s"
                             % (asm_line, expected_hex, got))


# ---------------------------------------------------------------------------
# 端到端执行测试。
# 每项：(名称, x86-64 汇编体, 硬编码期望低字节或 None)。
# 函数体只用调用方保存寄存器（rax,rcx,rdx,rsi,rdi,r8-r11），不破坏原生 C 框架，
# 并避开 r14（s390x 链接寄存器）。
# ---------------------------------------------------------------------------
TESTS = [
    ("const5",          "mov $5, %rax\nret",                                      5),
    ("add_imm",         "mov $10, %rax\nadd $32, %rax\nret",                     42),
    ("sub_imm",         "mov $100, %rax\nsub $30, %rax\nret",                    70),
    ("add_reg",         "mov $7, %rax\nmov $35, %rcx\nadd %rcx, %rax\nret",      42),
    ("sub_reg",         "mov $90, %rax\nmov $48, %rcx\nsub %rcx, %rax\nret",     42),
    ("imul_reg",        "mov $6, %rax\nmov $7, %rcx\nimul %rcx, %rax\nret",      42),
    ("xor_imm",         "mov $0xff, %rax\nxor $0x0f, %rax\nret",               240),
    ("and_imm",         "mov $0xf0, %rax\nand $0x3c, %rax\nret",                48),
    ("or_imm",          "mov $0x30, %rax\nor $0x0c, %rax\nret",                 60),
    ("inc",             "mov $41, %rax\ninc %rax\nret",                         42),
    ("dec",             "mov $43, %rax\ndec %rax\nret",                         42),
    ("neg",             "mov $42, %rax\nneg %rax\nret",               (256-42) & 0xff),
    ("not_zero",        "mov $0, %rax\nnot %rax\nret",                          255),
    ("mov_imm32",       "mov $0x12345678, %rax\nret",               0x78),       # 低字节
    ("add_overflow",    "mov $200, %rax\nadd $200, %rax\nret",       144),       # 400&0xff
    ("add_big_imm",     "mov $5, %rax\nadd $100000, %rax\nret",      165),       # 100005&0xff=0xa5
    ("three_regs",      "mov $1, %rax\nmov $2, %rcx\nmov $3, %rdx\n"
                        "add %rcx, %rax\nadd %rdx, %rax\nret",        6),
    ("r8_r9",           "mov $100, %r8\nmov $50, %r9\nsub %r9, %r8\n"
                        "mov %r8, %rax\nret",                       50),
    ("mov_reg_dir",     "mov $99, %rcx\nmov %rcx, %rax\nret",        99),
    ("and_mask",        "mov $0xabcd, %rax\nand $0xff, %rax\nret",  0xcd),       # 205
    ("neg_then_add",    "mov $10, %rax\nneg %rax\nadd $52, %rax\nret", 42),      # -10+52
    ("big_sub",         "mov $0x7fffffff, %rax\nsub $0x7ffffff0, %rax\nret", 0x0f),
    ("xor_swap",        "mov $0xaa, %rax\nxor $0xff, %rax\nret",    0x55),       # 85
    ("multi_logic",     "mov $0xf0, %rax\nor $0x0c, %rax\nand $0x3e, %rax\nret", 0x3c),  # 0xfc&0x3e=0x3c=60
    ("imul_big",        "mov $123, %rax\nmov $4, %rcx\nimul %rcx, %rax\nret", 492 & 0xff),  # 492&0xff=236
]


def _native_ref(body_asm):
    """本机构建并运行 x86-64 函数体；返回退出码 (0-255)。"""
    src = os.path.join(WORK, "native.s")
    with open(src, "w") as f:
        f.write(".text\n.globl test_fn\ntest_fn:\n")
        f.write(body_asm + "\n")
    obj = os.path.join(WORK, "native.o")
    _run(["gcc", "-c", "-o", obj, src])
    binpath = os.path.join(WORK, "native.bin")
    _run(["objcopy", "-O", "binary", "-j", ".text", obj, binpath])
    with open(binpath, "rb") as f:
        x86_bytes = f.read()
    harness = os.path.join(WORK, "harness.c")
    with open(harness, "w") as f:
        f.write("long test_fn(void);\n"
                "int main(void){ return (int)(test_fn() & 0xff); }\n")
    exe = os.path.join(WORK, "native_exe")
    _run(["gcc", "-O0", "-o", exe, harness, obj])
    r = subprocess.run([exe])
    return r.returncode & 0xff, x86_bytes


def _translated_run(x86_bytes):
    """把 x86_bytes 翻译到 s390x、构建 ELF、在 qemu-s390x 下运行。"""
    t = Translator()
    s390x_bytes = t.translate(x86_bytes)
    elfpath = os.path.join(WORK, "trans.elf")
    elfmod.write_elf(elfpath, s390x_bytes, add_exit_epilogue=True)
    r = subprocess.run(["qemu-s390x", elfpath])
    return r.returncode & 0xff


class EndToEndTests(unittest.TestCase):
    @unittest.skipUnless(have("gcc", "objcopy", "qemu-s390x"),
                         "native toolchain / qemu not available")
    def test_end_to_end(self):
        failures = []
        for name, body, expected in TESTS:
            with self.subTest(name=name):
                try:
                    ref, x86_bytes = _native_ref(body)
                except subprocess.CalledProcessError as e:
                    failures.append("%s: native build failed: %s"
                                    % (name, (e.output or e.stderr or str(e))))
                    continue
                try:
                    got = _translated_run(x86_bytes)
                except (DecodeError, TranslationError) as e:
                    failures.append("%s: translation failed: %s" % (name, e))
                    continue
                if ref != got:
                    failures.append(
                        "%s: exit-code mismatch (native=%d, translated=%d)"
                        % (name, ref, got))
                elif expected is not None and got != expected:
                    failures.append(
                        "%s: exit-code %d != hardcoded expected %d"
                        % (name, got, expected))
        if failures:
            self.fail("end-to-end failures:\n  " + "\n  ".join(failures))


class DecoderUnitTests(unittest.TestCase):
    def test_mov_rax_imm32(self):
        # b8 05 00 00 00 -> mov eax, 5（零扩展）
        from src.x86.decoder import decode
        insns = decode(bytes([0xb8, 0x05, 0x00, 0x00, 0x00]))
        self.assertEqual(len(insns), 1)
        self.assertEqual(insns[0].mnemonic, "mov")
        self.assertEqual(insns[0].dst, {"kind": "reg", "reg": 0})
        self.assertEqual(insns[0].src, {"kind": "imm", "value": 5, "size": 32})

    def test_rex_w_add_reg_reg(self):
        # 48 01 c8 -> add rax, rcx（REX.W，01 /r：op r/m, r；modrm c8 = mod11 reg1(rcx) rm0(rax)）
        from src.x86.decoder import decode
        insns = decode(bytes([0x48, 0x01, 0xc8]))
        self.assertEqual(insns[0].mnemonic, "add")
        self.assertEqual(insns[0].dst["reg"], 0)   # rax
        self.assertEqual(insns[0].src["reg"], 1)   # rcx

    def test_memory_operand_rejected(self):
        from src.x86.decoder import decode, DecodeError
        # 48 89 00 -> mov [rax], rax（mod=00，内存）-> 必须抛异常
        with self.assertRaises(DecodeError):
            decode(bytes([0x48, 0x89, 0x00]))


if __name__ == "__main__":
    print("workdir:", WORK)
    unittest.main(verbosity=2)
