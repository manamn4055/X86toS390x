#!/usr/bin/env bash
# 答案驱动测试：x86 上跑出答案，再翻译到 s390x 比对结果。
set -uo pipefail
cd "$(dirname "$0")/.."
PROBE=/workspace/probe
PROGS=tests/programs
mkdir -p "$PROBE"

# 测试列表：名称|源码路径|类型
# exit：只比退出码；stdout：连标准输出一起比
declare -a TESTS=(
    "t01_arith|$PROBE/t01_arith.c|exit"
    "t02_global|$PROBE/t02_global.c|exit"
    "t03_array|$PROBE/t03_array.c|exit"
    "t04_loop|$PROBE/t04_loop.c|exit"
    "t05_ptr_io|$PROBE/t05_ptr_io.c|exit"
    "t06_callchain|$PROBE/t06_callchain.c|exit"
    "t07_logic|$PROGS/t07_logic.c|exit"
    "t08_types|$PROGS/t08_types.c|exit"
    "t09_nested|$PROGS/t09_nested.c|exit"
    "t10_print|$PROGS/t10_print.c|stdout"
)

PASS=0; FAIL=0

for entry in "${TESTS[@]}"; do
    IFS='|' read -r name src typ <<< "$entry"
    echo "================================================================"
    echo "TEST $name  ($typ)"
    echo "================================================================"

    # 步骤1：编译 C -> x86 .o
    if ! gcc -O1 -fno-stack-protector -fno-pie -c "$src" -o "$PROBE/$name.o" 2>/dev/null; then
        echo "  FAIL: gcc compile failed"; FAIL=$((FAIL+1)); continue
    fi

    # 步骤2：链接 x86 可执行程序，跑出参考答案
    if ! gcc -no-pie -o "$PROBE/$name.x86" "$PROBE/$name.o" 2>/dev/null; then
        echo "  FAIL: gcc link failed"; FAIL=$((FAIL+1)); continue
    fi
    
    x86_stdout=$("$PROBE/$name.x86" 2>/dev/null)
    x86_exit=$?
    x86_exit=$((x86_exit & 0xff))

    # 步骤3：翻译 .o -> s390x ELF
    if ! python3 x86tos390x.py --obj "$PROBE/$name.o" --elf "$PROBE/$name.s390x" >/dev/null 2>"$PROBE/$name.err"; then
        echo "  FAIL: translation failed"; cat "$PROBE/$name.err"; FAIL=$((FAIL+1)); continue
    fi

    # 步骤4：qemu-s390x 运行
    s390x_stdout=$(qemu-s390x "$PROBE/$name.s390x" 2>/dev/null)
    s390x_exit=$?
    s390x_exit=$((s390x_exit & 0xff))

    # 步骤5：比对
    ok=1
    if [ "$s390x_exit" != "$x86_exit" ]; then
        echo "  FAIL: exit code s390x=$s390x_exit vs x86=$x86_exit"
        ok=0
    fi
    if [ "$typ" = "stdout" ]; then
        if [ "$s390x_stdout" != "$x86_stdout" ]; then
            echo "  FAIL: stdout mismatch"
            echo "    x86:   '$x86_stdout'"
            echo "    s390x: '$s390x_stdout'"
            ok=0
        fi
    fi
    
    if [ "$ok" = 1 ]; then
        echo "  PASS: exit=$s390x_exit${s390x_stdout:+, stdout='$s390x_stdout'}"
        PASS=$((PASS+1))
    else
        FAIL=$((FAIL+1))
    fi
done

echo
echo "================================================================"
echo "RESULTS: $PASS passed, $FAIL failed (out of ${#TESTS[@]})"
echo "================================================================"
[ "$FAIL" = 0 ]
