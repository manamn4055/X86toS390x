#!/usr/bin/env python3
"""编程式演示：把一段 x86-64 函数翻译成 s390x 并在 QEMU 上运行。

和 CLI 流程一样，但用 Python 驱动，方便看清库 API 如何串联::

    解码 x86-64 字节  ->  翻译到 s390x  ->  包成 ELF  ->  运行

示例程序计算  ((10 + 32) * 3) - 100  =  26  存入 RAX 后返回。
"""
import os
import subprocess
import sys

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from src import Translator, elf as elfmod

# x86-64 机器码：
#   mov rax, 10          ; 48 c7 c0 0a 00 00 00
#   add rax, 32          ; 48 83 c0 20
#   mov rcx, 3           ; 48 c7 c1 03 00 00 00
#   imul rax, rcx        ; 48 0f af c1
#   sub rax, 100         ; 48 83 e8 64
#   ret                  ; c3
X86_BYTES = bytes.fromhex(
    "48 c7 c0 0a 00 00 00  48 83 c0 20  48 c7 c1 03 00 00 00"
    "48 0f af c1  48 83 e8 64  c3".replace(" ", ""))

EXPECTED = 26


def main():
    t = Translator()
    s390x_bytes = t.translate(X86_BYTES)

    print("x86-64  :", X86_BYTES.hex(" "))
    print("s390x   :", s390x_bytes.hex(" "))
    print()
    print("%-26s | %s" % ("x86-64", "s390x"))
    print("-" * 26 + "-+-" + "-" * 30)
    for x86_text, s390x_text, b in t.listing:
        print("%-26s | %-22s [%s]" % (x86_text, s390x_text, b.hex(" ")))

    elf_path = os.path.join(os.path.dirname(__file__), "demo.s390x.elf")
    elfmod.write_elf(elf_path, s390x_bytes, add_exit_epilogue=True)
    print("\nwrote ELF:", elf_path)

    if subprocess.run(["which", "qemu-s390x"], capture_output=True).returncode == 0:
        r = subprocess.run(["qemu-s390x", elf_path])
        print("qemu exit code = %d (expected %d) -> %s" % (
            r.returncode, EXPECTED,
            "OK" if r.returncode == EXPECTED else "MISMATCH"))
    else:
        print("(qemu-s390x not installed; skipping execution)")


if __name__ == "__main__":
    main()
